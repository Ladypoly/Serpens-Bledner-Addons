# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.
#
# This addon was created with the Serpens - Visual Scripting Addon.
# This code is generated from nodes and is not intended for manual editing.
# You can find out more about Serpens at <https://blendermarket.com/products/serpens>.


bl_info = {
    "name": "PhysicsDropper",
    "description": "",
    "author": "Elin",
    "version": (1, 0, 1),
    "blender": (2, 93, 5),
    "location": "Tool",
    "warning": "",
    "wiki_url": "",
    "tracker_url": "",
    "category": "3D View"
}


###############   IMPORTS
import bpy
from bpy.utils import previews
import os
import math


###############   INITALIZE VARIABLES
physicsdropper = {
    "active": [], 
    "passive": [], 
    }


###############   SERPENS FUNCTIONS
def exec_line(line):
    exec(line)

def sn_print(tree_name, *args):
    if tree_name in bpy.data.node_groups:
        item = bpy.data.node_groups[tree_name].sn_graphs[0].prints.add()
        for arg in args:
            item.value += str(arg) + ";;;"
        if bpy.context and bpy.context.screen:
            for area in bpy.context.screen.areas:
                area.tag_redraw()
    print(*args)

def sn_cast_string(value):
    return str(value)

def sn_cast_boolean(value):
    if type(value) == tuple:
        for data in value:
            if bool(data):
                return True
        return False
    return bool(value)

def sn_cast_float(value):
    if type(value) == str:
        try:
            value = float(value)
            return value
        except:
            return float(bool(value))
    elif type(value) == tuple:
        return float(value[0])
    elif type(value) == list:
        return float(len(value))
    elif not type(value) in [float, int, bool]:
        try:
            value = len(value)
            return float(value)
        except:
            return float(bool(value))
    return float(value)

def sn_cast_int(value):
    return int(sn_cast_float(value))

def sn_cast_boolean_vector(value, size):
    if type(value) in [str, bool, int, float]:
        return_value = []
        for i in range(size):
            return_value.append(bool(value))
        return tuple(return_value)
    elif type(value) == tuple:
        return_value = []
        for i in range(size):
            return_value.append(bool(value[i]) if len(value) > i else bool(value[0]))
        return tuple(return_value)
    elif type(value) == list:
        return sn_cast_boolean_vector(tuple(value), size)
    else:
        try:
            value = tuple(value)
            return sn_cast_boolean_vector(value, size)
        except:
            return sn_cast_boolean_vector(bool(value), size)

def sn_cast_float_vector(value, size):
    if type(value) in [str, bool, int, float]:
        return_value = []
        for i in range(size):
            return_value.append(sn_cast_float(value))
        return tuple(return_value)
    elif type(value) == tuple:
        return_value = []
        for i in range(size):
            return_value.append(sn_cast_float(value[i]) if len(value) > i else sn_cast_float(value[0]))
        return tuple(return_value)
    elif type(value) == list:
        return sn_cast_float_vector(tuple(value), size)
    else:
        try:
            value = tuple(value)
            return sn_cast_float_vector(value, size)
        except:
            return sn_cast_float_vector(sn_cast_float(value), size)

def sn_cast_int_vector(value, size):
    return tuple(map(int, sn_cast_float_vector(value, size)))

def sn_cast_color(value, use_alpha):
    length = 4 if use_alpha else 3
    value = sn_cast_float_vector(value, length)
    tuple_list = []
    for data in range(length):
        data = value[data] if len(value) > data else value[0]
        tuple_list.append(sn_cast_float(min(1, max(0, data))))
    return tuple(tuple_list)

def sn_cast_list(value):
    if type(value) in [str, tuple, list]:
        return list(value)
    elif type(value) in [int, float, bool]:
        return [value]
    else:
        try:
            value = list(value)
            return value
        except:
            return [value]

def sn_cast_blend_data(value):
    if hasattr(value, "bl_rna"):
        return value
    elif type(value) in [tuple, bool, int, float, list]:
        return None
    elif type(value) == str:
        try:
            value = eval(value)
            return value
        except:
            return None
    else:
        return None

def sn_cast_enum(string, enum_values):
    for item in enum_values:
        if item[1] == string:
            return item[0]
        elif item[0] == string.upper():
            return item[0]
    return string


###############   IMPERATIVE CODE
#######   PhysicsDropper
def sn_handle_script_line_exception(exc, line):
    print("# # # # # # # # SCRIPT LINE ERROR # # # # # # # #")
    print("Line:", line)
    raise exc


###############   EVALUATED CODE
#######   PhysicsDropper
class SNA_MT_Active_Settings_3F812(bpy.types.Menu):
    bl_idname = "SNA_MT_Active_Settings_3F812"
    bl_label = "Active_Settings"


    @classmethod
    def poll(cls, context):
        return True

    def draw(self, context):
        try:
            layout = self.layout
        except Exception as exc:
            print(str(exc) + " | Error in Active_Settings menu")


class SNA_OT_Apply(bpy.types.Operator):
    bl_idname = "sna.apply"
    bl_label = "Apply"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in execute function of Apply")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            bpy.ops.object.select_all('INVOKE_DEFAULT' if True else 'EXEC_DEFAULT',action=sn_cast_enum(r"DESELECT", [("TOGGLE","Toggle","Toggle selection for all elements"),("SELECT","Select","Select all elements"),("DESELECT","Deselect","Deselect all elements"),("INVERT","Invert","Invert selection of all elements"),]),)
            for_node_80937 = 0
            for_node_index_80937 = 0
            for for_node_index_80937, for_node_80937 in enumerate(physicsdropper["active"]):
                run_function_on_5F235 = sn_cast_blend_data(for_node_80937).select_set(state=True, view_layer=None, )
            bpy.ops.object.visual_transform_apply('INVOKE_DEFAULT' if True else 'EXEC_DEFAULT',)
            bpy.ops.object.select_all('INVOKE_DEFAULT' if True else 'EXEC_DEFAULT',action=sn_cast_enum(r"SELECT", [("TOGGLE","Toggle","Toggle selection for all elements"),("SELECT","Select","Select all elements"),("DESELECT","Deselect","Deselect all elements"),("INVERT","Invert","Invert selection of all elements"),]),)
            bpy.ops.rigidbody.objects_remove('INVOKE_DEFAULT' if True else 'EXEC_DEFAULT',)
            bpy.ops.object.select_all('INVOKE_DEFAULT' if True else 'EXEC_DEFAULT',action=sn_cast_enum(r"DESELECT", [("TOGGLE","Toggle","Toggle selection for all elements"),("SELECT","Select","Select all elements"),("DESELECT","Deselect","Deselect all elements"),("INVERT","Invert","Invert selection of all elements"),]),)
            for_node_5C101 = 0
            for_node_index_5C101 = 0
            for for_node_index_5C101, for_node_5C101 in enumerate(physicsdropper["active"]):
                run_function_on_2C174 = sn_cast_blend_data(for_node_5C101).select_set(state=True, view_layer=None, )
            try: exec(r"bpy.context.scene.frame_current = 1")
            except Exception as exc: sn_handle_script_line_exception(exc, r"bpy.context.scene.frame_current = 1")
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of Apply")
        return self.execute(context)


class SNA_PT_Physics_Dropper_4B116(bpy.types.Panel):
    bl_label = "Physics Dropper"
    bl_idname = "SNA_PT_Physics_Dropper_4B116"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = 'Tool'
    bl_order = 0


    @classmethod
    def poll(cls, context):
        return True

    def draw_header(self, context):
        try:
            layout = self.layout
            layout.label(text=r"",icon_value=438)
        except Exception as exc:
            print(str(exc) + " | Error in Physics Dropper panel header")

    def draw(self, context):
        try:
            layout = self.layout
            col = layout.column(align=False)
            col.enabled = True
            col.alert = False
            col.scale_x = 1.0
            col.scale_y = 2.0
            op = col.operator("sna.drop",text=r"Drop",emboss=True,depress=False,icon_value=0)
            op = col.operator("sna.apply",text=r"Apply",emboss=True,depress=False,icon_value=0)
            box = layout.box()
            box.enabled = True
            box.alert = False
            box.scale_x = 1.0
            box.scale_y = 1.0
            box.label(text=r"Active Settings:",icon_value=37)
            col = box.column(align=True)
            col.enabled = True
            col.alert = False
            col.scale_x = 1.0
            col.scale_y = 1.0
            col.prop(bpy.context.scene,'a_shape',icon_value=0,text=r"Shape",emboss=True,expand=False,)
            col.prop(bpy.context.scene,'a_friction',text=r"Friction",emboss=True,slider=True,)
            col.prop(bpy.context.scene,'a_bunciness',text=r"Bunciness",emboss=True,slider=True,)
            col.prop(bpy.context.scene,'a_margin',text=r"Margin",emboss=True,slider=True,)
            col.prop(bpy.context.scene,'a_tra_damp',text=r"Damping Translation",emboss=True,slider=True,)
            col.prop(bpy.context.scene,'a_rot_damp',text=r"Damping  Rotation",emboss=True,slider=True,)
            box = layout.box()
            box.enabled = True
            box.alert = False
            box.scale_x = 1.0
            box.scale_y = 1.0
            box.label(text=r"Passive Settings:",icon_value=66)
            col = box.column(align=True)
            col.enabled = True
            col.alert = False
            col.scale_x = 1.0
            col.scale_y = 1.0
            col.prop(bpy.context.scene,'p_shape',icon_value=0,text=r"Shape",emboss=True,expand=False,)
            col.prop(bpy.context.scene,'p_friction',text=r"Friction",emboss=True,slider=True,)
            col.prop(bpy.context.scene,'p_bunciness',text=r"Bunciness",emboss=True,slider=True,)
            col.prop(bpy.context.scene,'p_margin',text=r"Margin",emboss=True,slider=True,)
        except Exception as exc:
            print(str(exc) + " | Error in Physics Dropper panel")


class SNA_OT_Drop(bpy.types.Operator):
    bl_idname = "sna.drop"
    bl_label = "Drop"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in execute function of Drop")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            physicsdropper["active"] = []
            physicsdropper["passive"] = []
            for_node_26609 = 0
            for_node_index_26609 = 0
            for for_node_index_26609, for_node_26609 in enumerate(bpy.context.selected_objects):
                if for_node_26609.type=="MESH":
                    physicsdropper["active"].append(for_node_26609)
                else:
                    pass
            bpy.ops.object.select_all('INVOKE_DEFAULT' if True else 'EXEC_DEFAULT',action=sn_cast_enum(r"INVERT", [("TOGGLE","Toggle","Toggle selection for all elements"),("SELECT","Select","Select all elements"),("DESELECT","Deselect","Deselect all elements"),("INVERT","Invert","Invert selection of all elements"),]),)
            for_node_9F021 = 0
            for_node_index_9F021 = 0
            for for_node_index_9F021, for_node_9F021 in enumerate(bpy.context.selected_objects):
                if for_node_9F021.type=="MESH":
                    physicsdropper["passive"].append(for_node_9F021)
                else:
                    pass
            bpy.ops.object.select_all('INVOKE_DEFAULT' if True else 'EXEC_DEFAULT',action=sn_cast_enum(r"DESELECT", [("TOGGLE","Toggle","Toggle selection for all elements"),("SELECT","Select","Select all elements"),("DESELECT","Deselect","Deselect all elements"),("INVERT","Invert","Invert selection of all elements"),]),)
            for_node_34A0A = 0
            for_node_index_34A0A = 0
            for for_node_index_34A0A, for_node_34A0A in enumerate(physicsdropper["passive"]):
                run_function_on_56CA5 = sn_cast_blend_data(for_node_34A0A).select_set(state=True, view_layer=None, )
            bpy.ops.rigidbody.objects_add('INVOKE_DEFAULT' if True else 'EXEC_DEFAULT',type=sn_cast_enum(r"PASSIVE", [("ACTIVE","Active","Object is directly controlled by simulation results"),("PASSIVE","Passive","Object is directly controlled by animation system"),]),)
            for_node_6637B = 0
            for_node_index_6637B = 0
            for for_node_index_6637B, for_node_6637B in enumerate(physicsdropper["passive"]):
                sn_cast_blend_data(for_node_6637B).rigid_body.collision_shape = bpy.context.scene.p_shape
                sn_cast_blend_data(for_node_6637B).rigid_body.friction = sn_cast_float(bpy.context.scene.p_friction)
                sn_cast_blend_data(for_node_6637B).rigid_body.restitution = sn_cast_float(bpy.context.scene.p_bunciness)
                sn_cast_blend_data(for_node_6637B).rigid_body.use_margin = True
                sn_cast_blend_data(for_node_6637B).rigid_body.collision_margin = bpy.context.scene.p_margin
            bpy.ops.object.select_all('INVOKE_DEFAULT' if True else 'EXEC_DEFAULT',action=sn_cast_enum(r"DESELECT", [("TOGGLE","Toggle","Toggle selection for all elements"),("SELECT","Select","Select all elements"),("DESELECT","Deselect","Deselect all elements"),("INVERT","Invert","Invert selection of all elements"),]),)
            for_node_FD1BF = 0
            for_node_index_FD1BF = 0
            for for_node_index_FD1BF, for_node_FD1BF in enumerate(physicsdropper["active"]):
                run_function_on_79D76 = sn_cast_blend_data(for_node_FD1BF).select_set(state=True, view_layer=None, )
            bpy.ops.object.origin_set('INVOKE_DEFAULT' if True else 'EXEC_DEFAULT',type=sn_cast_enum(r"ORIGIN_CENTER_OF_VOLUME", [("GEOMETRY_ORIGIN","Geometry to Origin","Move object geometry to object origin"),("ORIGIN_GEOMETRY","Origin to Geometry","Calculate the center of geometry based on the current pivot point (median, otherwise bounding box)"),("ORIGIN_CURSOR","Origin to 3D Cursor","Move object origin to position of the 3D cursor"),("ORIGIN_CENTER_OF_MASS","Origin to Center of Mass (Surface)","Calculate the center of mass from the surface area"),("ORIGIN_CENTER_OF_VOLUME","Origin to Center of Mass (Volume)","Calculate the center of mass from the volume (must be manifold geometry with consistent normals)"),]),center=sn_cast_enum(r"MEDIAN", [("MEDIAN","Median Center",""),("BOUNDS","Bounds Center",""),]),)
            bpy.ops.rigidbody.objects_add('INVOKE_DEFAULT' if True else 'EXEC_DEFAULT',type=sn_cast_enum(r"ACTIVE", [("ACTIVE","Active","Object is directly controlled by simulation results"),("PASSIVE","Passive","Object is directly controlled by animation system"),]),)
            for_node_BC30A = 0
            for_node_index_BC30A = 0
            for for_node_index_BC30A, for_node_BC30A in enumerate(physicsdropper["active"]):
                sn_cast_blend_data(for_node_BC30A).rigid_body.collision_shape = bpy.context.scene.a_shape
                sn_cast_blend_data(for_node_BC30A).rigid_body.friction = sn_cast_float(bpy.context.scene.a_friction)
                sn_cast_blend_data(for_node_BC30A).rigid_body.restitution = sn_cast_float(bpy.context.scene.a_bunciness)
                sn_cast_blend_data(for_node_BC30A).rigid_body.use_margin = True
                sn_cast_blend_data(for_node_BC30A).rigid_body.collision_margin = bpy.context.scene.a_margin
                sn_cast_blend_data(for_node_BC30A).rigid_body.linear_damping = sn_cast_float(bpy.context.scene.a_tra_damp)
                sn_cast_blend_data(for_node_BC30A).rigid_body.angular_damping = sn_cast_float(bpy.context.scene.a_rot_damp)
            bpy.ops.screen.animation_play('INVOKE_DEFAULT' if True else 'EXEC_DEFAULT',reverse=False,sync=False,)
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of Drop")
        return self.execute(context)


###############   REGISTER ICONS
def sn_register_icons():
    icons = []
    bpy.types.Scene.physicsdropper_icons = bpy.utils.previews.new()
    icons_dir = os.path.join( os.path.dirname( __file__ ), "icons" )
    for icon in icons:
        bpy.types.Scene.physicsdropper_icons.load( icon, os.path.join( icons_dir, icon + ".png" ), 'IMAGE' )

def sn_unregister_icons():
    bpy.utils.previews.remove( bpy.types.Scene.physicsdropper_icons )


###############   REGISTER PROPERTIES
def sn_register_properties():
    bpy.types.Scene.a_shape = bpy.props.EnumProperty(name='A_Shape',description='',options=set(),items=[('CONVEX_HULL', 'CONVEX_HULL', 'This is my enum item'), ('MESH', 'MESH', 'This is my enum item'), ('BOX', 'BOX', 'This is my enum item'), ('SPHERE', 'SPHERE', 'This is my enum item'), ('CAPSULE', 'CAPSULE', 'This is my enum item'), ('CYLINDER', 'CYLINDER', 'This is my enum item'), ('CONE', 'CONE', 'This is my enum item'), ('COMPOUND', 'COMPOUND', 'This is my enum item')])
    bpy.types.Scene.a_friction = bpy.props.FloatProperty(name='A_Friction',description='',subtype='NONE',unit='NONE',options=set(),precision=2, default=1.0,min=0.0,max=1.0)
    bpy.types.Scene.a_bunciness = bpy.props.FloatProperty(name='A_Bunciness',description='',subtype='NONE',unit='NONE',options=set(),precision=2, default=0.0,min=0.0,max=1.0)
    bpy.types.Scene.a_margin = bpy.props.FloatProperty(name='A_Margin',description='',subtype='NONE',unit='NONE',options=set(),precision=3, default=0.0010000000474974513,min=0.0010000000474974513,max=0.10000000149011612)
    bpy.types.Scene.a_tra_damp = bpy.props.FloatProperty(name='A_Tra_Damp',description='',subtype='NONE',unit='NONE',options=set(),precision=3, default=0.03999999910593033,min=0.0010000000474974513,max=1.0)
    bpy.types.Scene.a_rot_damp = bpy.props.FloatProperty(name='A_Rot_Damp',description='',subtype='NONE',unit='NONE',options=set(),precision=3, default=0.10000000149011612,min=0.009999999776482582,max=1.0)
    bpy.types.Scene.p_shape = bpy.props.EnumProperty(name='P_Shape',description='',options=set(),items=[('MESH', 'MESH', 'This is my enum item'), ('CONVEX_HULL', 'CONVEX_HULL', 'This is my enum item'), ('BOX', 'BOX', 'This is my enum item'), ('SPHERE', 'SPHERE', 'This is my enum item'), ('CAPSULE', 'CAPSULE', 'This is my enum item'), ('CYLINDER', 'CYLINDER', 'This is my enum item'), ('CONE', 'CONE', 'This is my enum item'), ('COMPOUND', 'COMPOUND', 'This is my enum item')])
    bpy.types.Scene.p_friction = bpy.props.FloatProperty(name='P_Friction',description='',subtype='NONE',unit='NONE',options=set(),precision=2, default=1.0,min=0.0,max=1.0)
    bpy.types.Scene.p_bunciness = bpy.props.FloatProperty(name='P_Bunciness',description='',subtype='NONE',unit='NONE',options=set(),precision=2, default=0.0,min=0.0,max=1.0)
    bpy.types.Scene.p_margin = bpy.props.FloatProperty(name='P_Margin',description='',subtype='NONE',unit='NONE',options=set(),precision=3, default=0.0010000000474974513,min=0.0010000000474974513,max=0.10000000149011612)

def sn_unregister_properties():
    del bpy.types.Scene.a_shape
    del bpy.types.Scene.a_friction
    del bpy.types.Scene.a_bunciness
    del bpy.types.Scene.a_margin
    del bpy.types.Scene.a_tra_damp
    del bpy.types.Scene.a_rot_damp
    del bpy.types.Scene.p_shape
    del bpy.types.Scene.p_friction
    del bpy.types.Scene.p_bunciness
    del bpy.types.Scene.p_margin


###############   REGISTER ADDON
def register():
    sn_register_icons()
    sn_register_properties()
    bpy.utils.register_class(SNA_MT_Active_Settings_3F812)
    bpy.utils.register_class(SNA_OT_Apply)
    bpy.utils.register_class(SNA_PT_Physics_Dropper_4B116)
    bpy.utils.register_class(SNA_OT_Drop)


###############   UNREGISTER ADDON
def unregister():
    sn_unregister_icons()
    sn_unregister_properties()
    bpy.utils.unregister_class(SNA_OT_Drop)
    bpy.utils.unregister_class(SNA_PT_Physics_Dropper_4B116)
    bpy.utils.unregister_class(SNA_OT_Apply)
    bpy.utils.unregister_class(SNA_MT_Active_Settings_3F812)