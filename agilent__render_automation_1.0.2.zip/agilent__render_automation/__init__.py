# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.
#
# This addon was created with the Serpens - Visual Scripting Addon.
# This code is generated from nodes and is not intended for manual editing.
# You can find out more about Serpens at <https://blendermarket.com/products/serpens>.


bl_info = {
    "name": "Agilent - Render Automation",
    "description": "",
    "author": "Creapolis",
    "version": (1, 0, 2),
    "blender": (2, 93, 0),
    "location": "Properties Panel -> Agilent",
    "warning": "",
    "wiki_url": "",
    "tracker_url": "",
    "category": "3D View"
}


###############   IMPORTS
import bpy
from bpy.utils import previews
import os
import math
from bpy.app.handlers import persistent


###############   INITALIZE VARIABLES
agilent__render_automation = {
    "scriptrunning": True, 
    }


###############   SERPENS FUNCTIONS
def exec_line(line):
    exec(line)

def sn_print(tree_name, *args):
    if tree_name in bpy.data.node_groups:
        item = bpy.data.node_groups[tree_name].sn_graphs[0].prints.add()
        for arg in args:
            item.value += str(arg) + ";;;"
        if bpy.context and bpy.context.screen:
            for area in bpy.context.screen.areas:
                area.tag_redraw()
    print(*args)

def sn_cast_string(value):
    return str(value)

def sn_cast_boolean(value):
    if type(value) == tuple:
        for data in value:
            if bool(data):
                return True
        return False
    return bool(value)

def sn_cast_float(value):
    if type(value) == str:
        try:
            value = float(value)
            return value
        except:
            return float(bool(value))
    elif type(value) == tuple:
        return float(value[0])
    elif type(value) == list:
        return float(len(value))
    elif not type(value) in [float, int, bool]:
        try:
            value = len(value)
            return float(value)
        except:
            return float(bool(value))
    return float(value)

def sn_cast_int(value):
    return int(sn_cast_float(value))

def sn_cast_boolean_vector(value, size):
    if type(value) in [str, bool, int, float]:
        return_value = []
        for i in range(size):
            return_value.append(bool(value))
        return tuple(return_value)
    elif type(value) == tuple:
        return_value = []
        for i in range(size):
            return_value.append(bool(value[i]) if len(value) > i else bool(value[0]))
        return tuple(return_value)
    elif type(value) == list:
        return sn_cast_boolean_vector(tuple(value), size)
    else:
        try:
            value = tuple(value)
            return sn_cast_boolean_vector(value, size)
        except:
            return sn_cast_boolean_vector(bool(value), size)

def sn_cast_float_vector(value, size):
    if type(value) in [str, bool, int, float]:
        return_value = []
        for i in range(size):
            return_value.append(sn_cast_float(value))
        return tuple(return_value)
    elif type(value) == tuple:
        return_value = []
        for i in range(size):
            return_value.append(sn_cast_float(value[i]) if len(value) > i else sn_cast_float(value[0]))
        return tuple(return_value)
    elif type(value) == list:
        return sn_cast_float_vector(tuple(value), size)
    else:
        try:
            value = tuple(value)
            return sn_cast_float_vector(value, size)
        except:
            return sn_cast_float_vector(sn_cast_float(value), size)

def sn_cast_int_vector(value, size):
    return tuple(map(int, sn_cast_float_vector(value, size)))

def sn_cast_color(value, use_alpha):
    length = 4 if use_alpha else 3
    value = sn_cast_float_vector(value, length)
    tuple_list = []
    for data in range(length):
        data = value[data] if len(value) > data else value[0]
        tuple_list.append(sn_cast_float(min(1, max(0, data))))
    return tuple(tuple_list)

def sn_cast_list(value):
    if type(value) in [str, tuple, list]:
        return list(value)
    elif type(value) in [int, float, bool]:
        return [value]
    else:
        try:
            value = list(value)
            return value
        except:
            return [value]

def sn_cast_blend_data(value):
    if hasattr(value, "bl_rna"):
        return value
    elif type(value) in [tuple, bool, int, float, list]:
        return None
    elif type(value) == str:
        try:
            value = eval(value)
            return value
        except:
            return None
    else:
        return None

def sn_cast_enum(string, enum_values):
    for item in enum_values:
        if item[1] == string:
            return item[0]
        elif item[0] == string.upper():
            return item[0]
    return string


###############   IMPERATIVE CODE
#######   Agilent - Render Automation
def sn_handle_script_line_exception(exc, line):
    print("# # # # # # # # SCRIPT LINE ERROR # # # # # # # #")
    print("Line:", line)
    raise exc

def loadrenderscene():
    try:
        try: exec(r"bpy.ops.outliner.orphans_purge(do_local_ids=True, do_linked_ids=True, do_recursive=True)")
        except Exception as exc: sn_handle_script_line_exception(exc, r"bpy.ops.outliner.orphans_purge(do_local_ids=True, do_linked_ids=True, do_recursive=True)")
        bpy.ops.wm.append(directory=os.path.join(os.path.dirname(__file__),'assets','RenderScene.blend') + r"\World", filename=r"Agilent_World", link=False)
        bpy.ops.wm.append(directory=os.path.join(os.path.dirname(__file__),'assets','RenderScene.blend') + r"\Collection", filename=r"RenderScene", link=False)
        bpy.ops.wm.append(directory=os.path.join(os.path.dirname(__file__),'assets','RenderScene.blend') + r"\NodeTree", filename=r"AgilentCompositing", link=False)
    except Exception as exc:
        print(str(exc) + " | Error in function LoadRenderScene")

def removecurrentrednerscene():
    try:
        if bpy.context.view_layer.layer_collection.children.find(r"RenderScene") != -1:
            pass # DeleteOldRenderScene Script Start
            collection = bpy.data.collections.get('RenderScene')
            for obj in collection.objects:
                bpy.data.objects.remove(obj, do_unlink=True)
            bpy.data.collections.remove(collection)
            pass # DeleteOldRenderScene Script End
        else:
            pass
        pass # RemoveWorld Script Start
        #import bpy
        #currentWorld = bpy.data.worlds['Agilent_World']
        currentWorld = bpy.context.scene.world
        if not currentWorld is None:
            bpy.data.worlds.remove(currentWorld)
        #bpy.data.worlds.remove(currentWorld)
        pass # RemoveWorld Script End
    except Exception as exc:
        print(str(exc) + " | Error in function RemoveCurrentRednerScene")

def setrednersettings():
    try:
        try: exec(r"bpy.context.scene.render.film_transparent = True")
        except Exception as exc: sn_handle_script_line_exception(exc, r"bpy.context.scene.render.film_transparent = True")
        try: exec(r"bpy.context.scene.view_settings.view_transform = 'Standard'")
        except Exception as exc: sn_handle_script_line_exception(exc, r"bpy.context.scene.view_settings.view_transform = 'Standard'")
        try: exec(r"bpy.context.scene.view_layers['View Layer'].use_pass_z = False")
        except Exception as exc: sn_handle_script_line_exception(exc, r"bpy.context.scene.view_layers['View Layer'].use_pass_z = False")
        try: exec(r"bpy.context.scene.view_layers['View Layer'].use_pass_environment = True")
        except Exception as exc: sn_handle_script_line_exception(exc, r"bpy.context.scene.view_layers['View Layer'].use_pass_environment = True")
        try: exec(r"bpy.context.scene.view_layers['View Layer'].use_pass_environment = True")
        except Exception as exc: sn_handle_script_line_exception(exc, r"bpy.context.scene.view_layers['View Layer'].use_pass_environment = True")
        try: exec(r"bpy.context.scene.view_layers['View Layer'].use_pass_shadow = True")
        except Exception as exc: sn_handle_script_line_exception(exc, r"bpy.context.scene.view_layers['View Layer'].use_pass_shadow = True")
        try: exec(r"bpy.context.scene.view_layers['View Layer'].use_pass_ambient_occlusion = True")
        except Exception as exc: sn_handle_script_line_exception(exc, r"bpy.context.scene.view_layers['View Layer'].use_pass_ambient_occlusion = True")
        try: exec(r"bpy.context.scene.view_layers['View Layer'].use_pass_cryptomatte_object = True")
        except Exception as exc: sn_handle_script_line_exception(exc, r"bpy.context.scene.view_layers['View Layer'].use_pass_cryptomatte_object = True")
        try: exec(r"bpy.context.scene.cycles.use_denoising = True")
        except Exception as exc: sn_handle_script_line_exception(exc, r"bpy.context.scene.cycles.use_denoising = True")
        if sn_cast_blend_data(bpy.context.scene).previewrend:
            sn_cast_blend_data(bpy.context.scene).cycles["samples"] = 24
            sn_cast_blend_data(bpy.context.scene).render.resolution_percentage = 10
        else:
            sn_cast_blend_data(bpy.context.scene).cycles["samples"] = 300
            sn_cast_blend_data(bpy.context.scene).render.resolution_percentage = 100
        sn_cast_blend_data(bpy.context.scene).frame_current = 0
        try: exec(r"bpy.context.scene.world = bpy.data.worlds['Agilent_World']")
        except Exception as exc: sn_handle_script_line_exception(exc, r"bpy.context.scene.world = bpy.data.worlds['Agilent_World']")
    except Exception as exc:
        print(str(exc) + " | Error in function SetRednerSettings")

def setoutputpath():
    try:
        if sn_cast_blend_data(bpy.context.scene).outputpath == r"":
            sn_cast_blend_data(bpy.context.scene).outputpath = sn_cast_blend_data(bpy.context.scene).render.filepath
        else:
            sn_cast_blend_data(bpy.context.scene).render.filepath = sn_cast_blend_data(bpy.context.scene).render.filepath
    except Exception as exc:
        print(str(exc) + " | Error in function SetOutputPath")


@persistent
def render_complete_handler_E646F(dummy):
    if agilent__render_automation["scriptrunning"]:
        bpy.app.timers.register(removecurrentrednerscene, first_interval=1.0)
        bpy.ops.view3d.clear_render_border('INVOKE_DEFAULT' if True else 'EXEC_DEFAULT',)
        bpy.ops.wm.console_toggle('INVOKE_DEFAULT' if True else 'EXEC_DEFAULT',)
        agilent__render_automation["scriptrunning"] = False
    else:
        pass

def update_cameratorender(self, context):
    if self.cameratorender == r"Left":
        sn_cast_blend_data(bpy.context.scene).left = True
        sn_cast_blend_data(bpy.context.scene).front = False
        sn_cast_blend_data(bpy.context.scene).right = False
    else:
        pass
    if self.cameratorender == r"Front":
        sn_cast_blend_data(bpy.context.scene).front = True
        sn_cast_blend_data(bpy.context.scene).left = False
        sn_cast_blend_data(bpy.context.scene).right = False
    else:
        pass
    if self.cameratorender == r"Right":
        sn_cast_blend_data(bpy.context.scene).right = True
        sn_cast_blend_data(bpy.context.scene).left = False
        sn_cast_blend_data(bpy.context.scene).front = False
    else:
        pass

def externamefilename():
    try:
        if sn_cast_boolean(bpy.context.scene.systemname):
            pass
        else:
            for_node_D25D6 = 0
            for_node_index_D25D6 = 0
            for for_node_index_D25D6, for_node_D25D6 in enumerate(bpy.data.objects):
                if r"_Main" in for_node_D25D6.name:
                    bpy.context.scene.systemname = for_node_D25D6.name.replace(r"Dummy_", r"").replace(r"_Main", r"")
                else:
                    pass
    except Exception as exc:
        print(str(exc) + " | Error in function externameFileName")

def update_rendsystemfile(self, context):
    sn_cast_blend_data(bpy.context.scene).systemname = sn_cast_string(self.rendsystemfile.split(r"/")[int((sn_cast_float(len(self.rendsystemfile.split(r"/"))) - 1.0))])
    print(sn_cast_string(self.rendsystemfile.split(r"/")))


###############   EVALUATED CODE
#######   Agilent - Render Automation
class SNA_OT_Clear(bpy.types.Operator):
    bl_idname = "sna.clear"
    bl_label = "Clear"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in execute function of Clear")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            function_return_39EBD = removecurrentrednerscene()
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of Clear")
        return self.execute(context)


class SNA_OT_Render(bpy.types.Operator):
    bl_idname = "sna.render"
    bl_label = "Render"
    bl_description = "Start the render process"
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in execute function of Render")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            agilent__render_automation["scriptrunning"] = True
            if sn_cast_blend_data(bpy.context.scene).externalsystem:
                bpy.ops.object.select_all('INVOKE_DEFAULT' if True else 'EXEC_DEFAULT',action=sn_cast_enum(r"SELECT", [("TOGGLE","Toggle","Toggle selection for all elements"),("SELECT","Select","Select all elements"),("DESELECT","Deselect","Deselect all elements"),("INVERT","Invert","Invert selection of all elements"),]),)
                bpy.ops.object.delete('INVOKE_DEFAULT' if True else 'EXEC_DEFAULT',use_global=False,confirm=False,)
                try: exec(r"bpy.ops.outliner.orphans_purge(do_local_ids=True, do_linked_ids=True, do_recursive=True)")
                except Exception as exc: sn_handle_script_line_exception(exc, r"bpy.ops.outliner.orphans_purge(do_local_ids=True, do_linked_ids=True, do_recursive=True)")
                pass # LoadSystem Script Start
                #import bpy
                myfile = bpy.context.scene.rendsystemfile
                with bpy.data.libraries.load(myfile) as (data_from, data_to):
                    files = []
                    for obj in data_from.objects:
                        files.append({'name' : obj})
                    bpy.ops.wm.append(directory=myfile+'\\Object\\', files=files, autoselect=True)
                pass # LoadSystem Script End
                function_return_D93A6 = externamefilename()
            else:
                pass
            bpy.ops.wm.console_toggle('INVOKE_DEFAULT' if True else 'EXEC_DEFAULT',)
            function_return_F328B = removecurrentrednerscene()
            try: exec(r"bpy.ops.outliner.orphans_purge(do_local_ids=True, do_linked_ids=True, do_recursive=True)")
            except Exception as exc: sn_handle_script_line_exception(exc, r"bpy.ops.outliner.orphans_purge(do_local_ids=True, do_linked_ids=True, do_recursive=True)")
            function_return_BE69A = loadrenderscene()
            function_return_83D6B = setrednersettings()
            function_return_0EBCF = setoutputpath()
            pass # RenderAutoComp Script Start
            #import bpy
            systemname = bpy.context.scene.systemname
            bpy.context.scene.use_nodes = True
            tree = bpy.context.scene.node_tree
            links = tree.links
            for node in tree.nodes:
                tree.nodes.remove(node)
            RenderLayer_node = tree.nodes.new(type='CompositorNodeRLayers')
            RenderLayer_node.location = -500,0
            RenderLayer_node.name = "Render Layer"
            RenderLayer_node.label = "Render Layer"
            AgilentCompositing_node = bpy.context.scene.node_tree.nodes.new('CompositorNodeGroup')
            AgilentCompositing_node.node_tree = bpy.data.node_groups['AgilentCompositing']
            AgilentCompositing_node.name = "AgilentCompositing"
            AgilentCompositing_node.location = -200,0
            FileOutput_node = tree.nodes.new(type='CompositorNodeOutputFile')
            FileOutput_node.location = 0,0
            FileOutput_node.name = "File Output"
            FileOutput_node.label = "File Output"
            bpy.context.scene.node_tree.nodes.active = FileOutput_node
            FileOutput_node.format.file_format = "TARGA"
            FileOutput_node.format.color_mode = "RGBA"
            FileOutput_node.file_slots.remove(FileOutput_node.inputs[0])
            FileOutput_node.layer_slots.new(systemname+"_Instrument")
            FileOutput_node.layer_slots.new(systemname+"_Mask")
            FileOutput_node.layer_slots.new(systemname+"_Floor_Shadow")
            FileOutput_node.layer_slots.new(systemname+"_AO")
            FileOutput_node.active_input_index = 0
            #Viewer_node = tree.nodes.new(type='CompositorNodeViewer')
            #Viewer_node.location = 0,120
            Compositor_node = tree.nodes.new(type='CompositorNodeComposite')
            Compositor_node.location = 0,240
            #Combined Links    
            links.new(RenderLayer_node.outputs[0], AgilentCompositing_node.inputs[0])   
            links.new(RenderLayer_node.outputs[3], AgilentCompositing_node.inputs[1])   
            links.new(RenderLayer_node.outputs[4], AgilentCompositing_node.inputs[2])   
            links.new(RenderLayer_node.outputs[5], AgilentCompositing_node.inputs[3])   
            links.new(RenderLayer_node.outputs[6], AgilentCompositing_node.inputs[4])   
            links.new(RenderLayer_node.outputs[7], AgilentCompositing_node.inputs[5])  
            links.new(AgilentCompositing_node.outputs[0], FileOutput_node.inputs[0])   
            links.new(AgilentCompositing_node.outputs[1], FileOutput_node.inputs[1])   
            links.new(AgilentCompositing_node.outputs[2], FileOutput_node.inputs[2])   
            links.new(AgilentCompositing_node.outputs[3], FileOutput_node.inputs[3])
            #links.new(AgilentCompositing_node.outputs[0], Viewer_node.inputs[0])  
            links.new(AgilentCompositing_node.outputs[0], Compositor_node.inputs[0])   
            pass # RenderAutoComp Script End
            pass # RenderAutomation Script Start
            #import bpy
            import bpy_extras
            import time
            from bpy_extras.view3d_utils import location_3d_to_region_2d
            from math import radians
            from math import pi
            import bmesh
            import math
            import os
            #bpy.context.scene.render.resolution_percentage = 25
            #RenderScene = bpy.context.scene.rendscene
            #RenderSystemPath = bpy.context.scene.rendsystemfile
            outPathBase = bpy.context.scene.outputpath
            Systemname = bpy.context.scene.systemname
            resolutionmultiplier = bpy.context.scene.resmultiplier
            renderLeft = bpy.context.scene.left
            renderFront = bpy.context.scene.front
            renderRight = bpy.context.scene.right
            #standardScenePath = RenderScene + "/Object/"
            #standardSceneWorldPath = RenderScene + "/World/"
            bpy.context.scene.render.engine = 'CYCLES'
            preContext = None
            sizeX = 0
            sizeY = 0
            sizeZ = 0
            _pf = 1.5 # puffer for bbox/camera
            cropPufferMulti = 1.15 # for 15%
            helper_bottomLeft = None
            helper_bottomRight = None
            helper_topLeft = None
            helper_topRight = None

            def CleanHelper():
                helperBL = bpy.data.objects['HELPER_BottomLeft'].select_set(True)
                bpy.ops.object.delete()
                helperBR = bpy.data.objects['HELPER_BottomRight'].select_set(True)
                bpy.ops.object.delete()
                helperTL = bpy.data.objects['HELPER_TopLeft'].select_set(True)
                bpy.ops.object.delete()
                helperTR = bpy.data.objects['HELPER_TopRight'].select_set(True)
                bpy.ops.object.delete()
                helperBL = bpy.data.objects['HELPER_BottomLeftBack'].select_set(True)
                bpy.ops.object.delete()
                helperBR = bpy.data.objects['HELPER_BottomRightBack'].select_set(True)
                bpy.ops.object.delete()
                helperTL = bpy.data.objects['HELPER_TopLeftBack'].select_set(True)
                bpy.ops.object.delete()
                helperTR = bpy.data.objects['HELPER_TopRightBack'].select_set(True)
                bpy.ops.object.delete()

            def agilent_render_camera(cam):
                print("Now Rendering " + cam.name)
                bpy.context.view_layer.objects.active = cam
                #return True
                # switch to cam view 1
                #bpy.ops.object.select_camera()
                #area = next(area for area in bpy.context.screen.areas if area.type == 'VIEW_3D')
                #area.spaces[0].region_3d.view_perspective = 'CAMERA'
                #for area in bpy.context.screen.areas:
                #   if area.type == 'VIEW_3D':
                #      #bpy.ops.view3d.object_as_camera()
                #     area.spaces[0].region_3d.update()
                    #    area.spaces[0].region_3d.view_perspective = 'CAMERA'
                    #   area.spaces[0].region_3d.update()
                    #  break
                # switch to cam view 2
                #area= next(area for area in bpy.context.screen.areas if area.type == 'VIEW_3D')
                #area.spaces[0].region_3d.view_perspective = 'CAMERA'
                #area.spaces.active.region_3d.update()
                #area.spaces[0].region_3d.update()
                # switch to cam view 3
                #for area in bpy.context.screen.areas:
                #    if area.type == 'VIEW_3D':
                #        override = bpy.context.copy()
                #        override['area'] = area
                #        bpy.ops.view3d.viewnumpad(override, type = 'CAMERA')
                #        break
                # switch to cam view 4
                #bpy.context.screen.areas[5].spaces[0].region_3d.update()
                #bpy.context.screen.areas[5].spaces[0].region_3d.view_perspective = 'CAMERA'
                #bpy.context.screen.areas[5].spaces[0].region_3d.update()
                # import bpy_extras    
                # create output path
                #outPathBase = "M:/01_Projekte/Agilent/ZE041 Agilent 3d product library/4_VIZ/05_Rendering/00_BLENDER/"
                camAddition = ""
                if "Left" in cam.name:
                    camAddition = "_L"
                elif "Right" in cam.name:
                    camAddition = "_R"
                else:
                    camAddition = "_F"
                timestampID = (str((time.time())).split("."))[0]
                outPathName = Systemname + "_" + timestampID + camAddition
                outPathFull = (outPathBase + outPathName)
                #Set Output Node
                tree = bpy.context.scene.node_tree
                FileOutput_node = tree.nodes.get("File Output")
                FileOutput_node.base_path = outPathFull
                # SETTINGS
                #bpy.data.scenes['Scene'].render.filepath = outPathFull
                #bpy.context.scene.render.image_settings.file_format = 'JPEG'
                #bpy.context.scene.render.image_settings.quality = 100
                #bpy.context.scene.render.resolution_x = 3840
                #bpy.context.scene.render.resolution_y = 2160
                #bpy.context.scene.render.resolution_percentage = 25
                #bpy.context.scene.render.use_border = True
                #bpy.context.scene.render.use_crop_to_border = True
                #bpy.data.scenes["Scene"].render.border_max_y = 0.62
                #bpy.data.scenes["Scene"].render.border_min_y = 0.38
                #bpy.data.scenes["Scene"].render.border_min_x = 0.4
                #bpy.data.scenes["Scene"].render.border_max_x = 0.6
                #bpy.ops.view3d.render_border(xmin=468, xmax=708, ymin=244, ymax=705)
                #bpy.ops.view3d.render_border(xmin=896, xmax=1221, ymin=362, ymax=843)
                CleanHelper()
                bpy.ops.render.render('INVOKE_DEFAULT', animation=False, write_still=False)
                # ohne INVOKE DEFAULT probieren für batch rendering
                return {'FINISHED'}

            def agilent_calc_label_resolution():
                global sizeX
                global sizeY
                global sizeZ
                print("Calculating resolution for rendering")
                # we have a dummy in renderscene with a given size
                # this dummy should have a resolution of 200px in the final image
                # therefore we can calculate:
                # (safeframe-size / labeldummy-size) * 200px
                # ==> final resolution before crop
                # >> label size is 5cm - so 200px per 5cm in camera, which is what we can set 
                #   as we know the bbox size
                # since there were no changes at all for the existence of our script we can
                # leave it as is to not produce any script overhead
                theSize = sizeX
                if sizeZ > sizeX:
                    theSize = sizeZ
                theSize = theSize * 100 # because it is in m instead of cm
                _resBeforeCrop = (300 * ((theSize * 1.4) / 5))*resolutionmultiplier
                print("Resolution set to: " + str(_resBeforeCrop))
                #   '''TEMP TURNED OFF         TEMP TURNED OFF              TEMP TURNED OFF'''
                bpy.context.scene.render.resolution_x = round(_resBeforeCrop)
                bpy.context.scene.render.resolution_y = round(_resBeforeCrop)
                #'''STOP SCRIPT'''
                #raise Exception()

            def cleanUp():
                print("Cleaning Scene from helper objects")
                bpy.ops.object.select_all(action='DESELECT')
                bboxDum = bpy.data.objects['AUTOCAM_BBOX_DUMMY'].select_set(True)
                bpy.ops.object.delete()
                return True
                helperBL = bpy.data.objects['HELPER_BottomLeft'].select_set(True)
                bpy.ops.object.delete()
                helperBR = bpy.data.objects['HELPER_BottomRight'].select_set(True)
                bpy.ops.object.delete()
                helperTL = bpy.data.objects['HELPER_TopLeft'].select_set(True)
                bpy.ops.object.delete()
                helperTR = bpy.data.objects['HELPER_TopRight'].select_set(True)
                bpy.ops.object.delete()   

            def getCircularPosition(radius, deg, xOff):
                retty = [1.1,1.2]
                #deg = 90 + deg
                x_offset = xOff
                #deg = 35
                x = (radius * math.cos(deg) + x_offset)
                retty[0] = x
                y = radius * math.sin(deg)
                retty[1] = y
                print("cPos = " + str(x) + ":" + str(y))
                return retty

            def points_on_circumference(center=(0, 0), r=250, n=360):
                return [
                    (
                        center[0]+(math.cos(2 * pi / n * x) * r),  # x
                        center[1] + (math.sin(2 * pi / n * x) * r)  # y
                    ) for x in range(0, n + 1)]

            def agilent_calculate_lefright_cams():
                print("Calculating left and right cameras position/location")
                frontCam = bpy.data.objects['autoCam_Front']
                targetFront = bpy.data.objects['autoCam_Front.Target']
                leftCam = bpy.data.objects['autoCam_Left']
                rightCam = bpy.data.objects['autoCam_Right']
                ### radius
                xOffset = 0 # not needed in this case
                deg = 150 # degrees to rotate
                # radius is distance target to camera
                theRadius = abs((targetFront.location[1] - frontCam.location[1]))
                #theRadius = 50
                print("Radius/Distance: " + str(theRadius))
                posyLeftAll = points_on_circumference(center=(targetFront.location[0],targetFront.location[1]),r=theRadius)
                print("posy left:")
                posyLeft = posyLeftAll[250]
                posyRight = posyLeftAll[290]
                print(posyLeft)
                #posyLeft = getCircularPosition(theRadius, deg, xOffset)
                leftCam.location[0] = posyLeft[0]
                leftCam.location[1] = posyLeft[1]
                rightCam.location[0] = posyRight[0]
                rightCam.location[1] = posyRight[1]
                ### radius end
                #leftCam.location.x -= 2.7
                #rightCam.location.x += 2.7

            def agilent_create_leftright_cams():
                print("Creating left and right cams")    
                bpy.data.objects['autoCam_Front'].select_set(True)
                bpy.ops.object.duplicate()
                bpy.context.selected_objects[0].name = "autoCam_Left"
                bpy.ops.object.select_all(action='DESELECT')
                bpy.data.objects['autoCam_Front'].select_set(True)
                bpy.ops.object.duplicate()
                bpy.context.selected_objects[0].name = "autoCam_Right"
                agilent_calculate_lefright_cams()

            def agilent_get_bbox_center():
                return bpy.data.objects['AUTOCAM_BBOX_DUMMY'].location

            def agilent_align_cam_target_bbox_center(camTarget):
                print("Aligning " + camTarget.name + " target to bbox center")
                centerLoc = agilent_get_bbox_center()
                camTarget.location.x = centerLoc.x
                frontCam = bpy.data.objects['autoCam_Front']
                frontCam.location.x = centerLoc.x

            def agilent_calculate_front_cam():
                global sizeX
                global sizeY
                global sizeZ
                print("Calculating front camera position... with sizeX: " + str(sizeX))
                frontCam = bpy.data.objects['autoCam_Front']
                bpy.context.scene.render.resolution_x = 7862
                bpy.context.scene.render.resolution_y = 7862
                angleY = 39.6 # constant for 50mm camera as we have it
                # formel dreieck: a = b, c = 2a * sin(y/2)
                # h² = a² - 0.25*c²
                # : c = 2a * 0.342
                # :: c = 0.684 * a
                # ::: a = c / 0.684
                # sizeX is my "c" in formula
                # so i know what i need for c and can calculate hc to fit everything in
                # formula: 
                # h² = (c/0.684)² - 0.25c²
                # --> h = sqrt(   (c/0.684)² - 0.25c²)
                # h is my distance in y axis
                _c = sizeX
                if sizeZ > sizeX:
                    _c = sizeZ
                _distancex2 = (math.pow(_c/0.684,2)- math.pow(0.25*_c,2))
                #print("Distance x2: " + str(_distancex2))
                print("_c: " + str(_c))
                _distance = math.sqrt(_distancex2)
                #if _distance > -1.85:
                #    _distance = -1.85
                overflowValue = 1.5
                #if sizeZ < 0.02:
                #    overflowValue = 5.5 # valves
                if sizeZ < 0.2:
                    overflowValue = 3.25
                elif sizeZ < 0.3:
                    overflowValue = 3.2
                elif sizeZ < 0.4:
                    overflowValue = 3.15
                elif sizeZ < 0.5:
                    overflowValue = 3.05
                elif sizeZ < 0.6:
                    overflowValue = 2.75
                elif sizeZ < 0.85:
                    overflowValue = 2.3
                elif sizeZ < 1.00:
                    overflowValue = 1.8
                print("Overflow value: " + str(overflowValue))
                #print("SizeZ: " + str(sizeZ))
                _distance = (-1*_distance * overflowValue)
                print("dist before: " + str(_distance))
                if _distance > -1.85:
                    _distance = -1.875
                frontCam.location.y = (_distance)
                #print ("size is: " + str(sizeX))

            def agilent_crop_helper(theObj):
                scene = bpy.context.scene
                obj = bpy.data.objects['autoCam_Front']
                co = theObj.location
                co_2d = bpy_extras.object_utils.world_to_camera_view(scene, obj, co)
                #print("2D Coords:", co_2d)
                # If you want pixel coords
                render_scale = scene.render.resolution_percentage / 100
                render_size = (
                    int(scene.render.resolution_x * render_scale),
                    int(scene.render.resolution_y * render_scale),
                )
                print("Pixel Coords:", (
                    round(co_2d.x * render_size[0]),
                    round(co_2d.y * render_size[1]),
                ))
                return (round(co_2d.x * render_size[0]),round(co_2d.y * render_size[1]))

            def agilent_calc_region(currentCamera):
                print("Calculation render region for product...")
                bpy.context.scene.render.use_border = True
                bpy.context.scene.render.use_crop_to_border = True
                helper_botLeft = bpy.data.objects["HELPER_BottomLeft"]
                helper_botLeftBack = bpy.data.objects["HELPER_BottomLeftBack"]
                helper_topRight = bpy.data.objects["HELPER_TopRight"]
                helper_topRightBack = bpy.data.objects["HELPER_TopRightBack"]
                helper_botRight = bpy.data.objects["HELPER_BottomRight"]
                helper_botRightBack = bpy.data.objects["HELPER_BottomRightBack"]
                helper_topLeft = bpy.data.objects["HELPER_TopLeft"]
                helper_topLeftBack = bpy.data.objects["HELPER_TopLeftBack"]
                #point_bleft = agilent_crop_helper(helper_botLeft)
                #point_tright = agilent_crop_helper(helper_topRight)
                #print("Points: " + str(point_bleft) + " --- " + str(point_tright))
                #bpy.ops.view3d.render_border(xmin=point_bleft[0], xmax=point_tright[0], ymin=point_bleft[1], ymax=point_tright[1])
                cropOverflowPercentage = 25 # is percentage of pixel size which will be added
                preContext = bpy.context
                if currentCamera == "Front":
                    for area in bpy.context.screen.areas:
                        if area.type == 'VIEW_3D':
                            tRCoords = location_3d_to_region_2d(bpy.context.region, bpy.context.space_data.region_3d, helper_topRight.location, default=None)
                            bLCoords = location_3d_to_region_2d(bpy.context.region, bpy.context.space_data.region_3d, helper_botLeft.location, default=None)
                            backCoords = location_3d_to_region_2d(bpy.context.region, bpy.context.space_data.region_3d, helper_topRightBack.location, default=None)
                            topValue = 4000
                            if backCoords[1] > bLCoords[1]:
                                topValue = backCoords[1]
                            xSize = tRCoords[0] - bLCoords[0]
                            ySize = topValue - bLCoords[1]
                            cropOverflow_x = xSize * (cropOverflowPercentage / 100)
                            cropOverflow_y = ySize * (cropOverflowPercentage / 100)
                            bpy.ops.view3d.render_border(xmin=bLCoords[0]-cropOverflow_x, xmax=tRCoords[0]+cropOverflow_x, ymin=bLCoords[1]-cropOverflow_y, ymax=topValue+cropOverflow_y)
                elif currentCamera == "Right":
                    bpy.context = preContext
                    tRCoords = location_3d_to_region_2d(bpy.context.region, bpy.context.space_data.region_3d, helper_topRightBack.location, default=None)
                    tLCoords = location_3d_to_region_2d(bpy.context.region, bpy.context.space_data.region_3d, helper_topLeftBack.location, default=None)
                    bLCoords = location_3d_to_region_2d(bpy.context.region, bpy.context.space_data.region_3d, helper_botLeft.location, default=None)
                    bRCoords = location_3d_to_region_2d(bpy.context.region, bpy.context.space_data.region_3d, helper_botRight.location, default=None)
                    xSize = tRCoords[0] - bLCoords[0]
                    ySize = tLCoords[1] - bRCoords[1]
                    cropOverflow_x = xSize * (cropOverflowPercentage / 100)
                    cropOverflow_y = ySize * (cropOverflowPercentage / 100)
                    bpy.ops.view3d.render_border(xmin=bLCoords[0]-cropOverflow_x, xmax=tRCoords[0]+cropOverflow_x, ymin=bRCoords[1]-cropOverflow_y, ymax=tLCoords[1]+cropOverflow_y)
                elif currentCamera == "Left":
                    bpy.context = preContext
                    for area in bpy.context.screen.areas:
                        if area.type == 'VIEW_3D':
                            tLCoords = location_3d_to_region_2d(bpy.context.region, bpy.context.space_data.region_3d, helper_topLeftBack.location, default=None)
                            tRCoords = location_3d_to_region_2d(bpy.context.region, bpy.context.space_data.region_3d, helper_topRightBack.location, default=None)
                            bRCoords = location_3d_to_region_2d(bpy.context.region, bpy.context.space_data.region_3d, helper_botRight.location, default=None)
                            bLCoords = location_3d_to_region_2d(bpy.context.region, bpy.context.space_data.region_3d, helper_botLeft.location, default=None)
                            xSize = bRCoords[0] - tLCoords[0]
                            ySize = tRCoords[1] - bLCoords[1]
                            cropOverflow_x= xSize * (cropOverflowPercentage / 100)
                            cropOverflow_y = ySize * (cropOverflowPercentage / 100)
                            bpy.ops.view3d.render_border(xmin=tLCoords[0]-cropOverflow_x, xmax=bRCoords[0]+cropOverflow_x, ymin=bLCoords[1]-cropOverflow_y, ymax=tRCoords[1]+cropOverflow_y)
                # now set coords according to tRCoords and bLCoords

            def agilent_create_bbox():
                print("xCreating Bounding Box around all Meshes in Scene.")
                bpy.ops.object.select_all(action="SELECT")
                bpy.data.objects['Render_Floor'].select_set(False)
                # first get all vertices to get min and max to create a BBox around everything
                minX = 9999
                minY = 9999
                minZ = 9999
                maxX = -9999
                maxY = -9999
                maxZ = -9999
                # loop every selected object (objects are selected after mergin into the scene
                for obj in bpy.context.selected_objects:
                    if obj.type == 'MESH':
                        # if obj is a mesh i can look for verts


                        coords = [(obj.matrix_world @ v.co) for v in obj.data.vertices]
                        for _v in coords:
                            _x = _v[0]
                            _y = _v[1]
                            _z = _v[2]
                            if _x < minX:
                                minX = _x
                            elif _x > maxX:
                                maxX = _x
                            if _y < minY:
                                minY = _y
                            elif _y > maxY:
                                maxY = _y
                            if _z < minZ:
                                minZ = _z
                            elif _z > maxZ:
                                maxZ = _z
                print("Min values are: " + str(minX) + "," + str(minY) + "," + str(minZ))
                print("Max values are: " + str(maxX) + "," + str(maxY) + "," + str(maxZ))
                global helper_bottomLeft
                global helper_bottomRight
                global helper_topLeft
                global helper_topRight
                global helper_bottomLeftBack
                global helper_bottomRightBack
                global helper_topLeftBack
                global helper_topRightBack
                # now i create helper objects for crop later in script
                # front side first
                bpy.ops.mesh.primitive_cube_add(size = 0.04, location=(minX, minY, minZ))
                helper_bottomLeft = bpy.context.active_object
                helper_bottomLeft.hide_render = True
                helper_bottomLeft.name = "HELPER_BottomLeft"
                bpy.ops.mesh.primitive_cube_add(size = 0.04, location=(maxX, minY, minZ))
                helper_bottomRight = bpy.context.active_object
                helper_bottomRight.hide_render = True
                helper_bottomRight.name = "HELPER_BottomRight"
                bpy.ops.mesh.primitive_cube_add(size = 0.04, location=(minX, minY, maxZ))
                helper_topLeft = bpy.context.active_object
                helper_topLeft.hide_render = True
                helper_topLeft.name = "HELPER_TopLeft"
                bpy.ops.mesh.primitive_cube_add(size = 0.04, location=(maxX, minY, maxZ))
                helper_topRight = bpy.context.active_object
                helper_topRight.hide_render = True
                helper_topRight.name = "HELPER_TopRight"
                # now for backside:
                bpy.ops.mesh.primitive_cube_add(size = 0.04, location=(minX, maxY, minZ))
                helper_bottomLeftBack = bpy.context.active_object
                helper_bottomLeftBack.hide_render = True
                helper_bottomLeftBack.name = "HELPER_BottomLeftBack"
                bpy.ops.mesh.primitive_cube_add(size = 0.04, location=(maxX, maxY, minZ))
                helper_bottomRightBack = bpy.context.active_object
                helper_bottomRightBack.hide_render = True
                helper_bottomRightBack.name = "HELPER_BottomRightBack"
                bpy.ops.mesh.primitive_cube_add(size = 0.04, location=(minX, maxY, maxZ))
                helper_topLeftBack = bpy.context.active_object
                helper_topLeftBack.hide_render = True
                helper_topLeftBack.name = "HELPER_TopLeftBack"
                bpy.ops.mesh.primitive_cube_add(size = 0.04, location=(maxX, maxY, maxZ))
                helper_topRightBack = bpy.context.active_object
                helper_topRightBack.hide_render = True
                helper_topRightBack.name = "HELPER_TopRightBack"
                global sizeX
                global sizeY
                global sizeZ
                # calculate size of cube(bbox)
                sizeX = abs(minX - maxX)
                sizeY = abs(minY - maxY)
                sizeZ = abs(minZ - maxZ)
                print("global sizeX in helper function: " + str(sizeX))
                # create cube
                _bbox = bpy.ops.mesh.primitive_cube_add(size = 2.0, scale=(sizeX, sizeY, sizeZ), location=(sizeX/2 + minX, sizeY/2 + minY, sizeZ/2))
                _bbox = bpy.context.active_object 
                # for location we need to move by minX and minY because instruments do not exactly fit in 0,0,0 
                _bbox.name = "AUTOCAM_BBOX_DUMMY"
                return _bbox
                #nameList = ['MAIN_DUMMY_AUTOCAM']
                #for i in range(nameList.__len__()):
                #    bpy.ops.wm.append(filename=nameList[i], directory=helperScenePath)

            #def agilent_load_standard_scene():
            #    print("Loading Standard Scene:")
                #worldList = ['World']
                #for j in range(worldList.__len__()):
                #    bpy.ops.wm.append(filename=worldList[j], directory=standardScenePath)
                #nameList = ['Floor', 'autoCam_Front', 'autoCam_Front.Target', 'MAIN_DUMMY_AUTOCAM']
                #nameList = ['MAIN_DUMMY_AUTOCAM']
                #for i in range(nameList.__len__()):
                #    bpy.ops.wm.append(filename=nameList[i], directory=standardScenePath)

            def agilent_load_selected_module(myfile):
                print("Loading Module: " + str(myfile))
                #bpy.ops.wm.append(filepath=selectedModulePath, autoselect=False)
                with bpy.data.libraries.load(myfile) as (data_from, data_to):
                    files = []
                    for obj in data_from.objects:
                        files.append({'name' : obj})
                    bpy.ops.wm.append(directory=myfile+'\\Object\\', files=files)

            def agilent_create_l_r_cameras():
                print("Creating L and R Cameras:")
                agilent_create_leftright_cams()

            def agilent_clean_scene():
                print("Cleaning Scene from helper objects")

            def agilent_main(context):#missing context
                # First Load the selected Instrument/Module
                # this is needed because we need to open the Render-Scene before starting the script
                # there is no way to merge it because of compositing settings
                #hack
                #TODO: choose file by UI not hard coded!
                #selectedModulePath = RenderSystemPath
                #agilent_load_selected_module(selectedModulePath)
                # first create bounding box for scene
                _bbox = agilent_create_bbox()
                # load standard scene with camera and floor
                #agilent_load_standard_scene()
                #clear selection
                bpy.ops.object.select_all(action='DESELECT')
                # align front camera target
                front_target = bpy.data.objects['autoCam_Front.Target']
                agilent_align_cam_target_bbox_center(front_target)
                #### Front Camera #####
                # calculate y-position of front cam
                agilent_calculate_front_cam()
                #### Create Left and Right Camera ####
                agilent_create_l_r_cameras()
                # calculate resolution before crop - for whole image frame/safe frame
                agilent_calc_label_resolution()
                # Clean the Scene
                cleanUp()
                # now before calculating render region we change to camera perspective
                if renderFront == True:
                    print("Rendering Front Camera!")
                    fCam = bpy.data.objects['autoCam_Front']
                    bpy.context.view_layer.objects.active = fCam
                    # switch to cam view
                    bpy.ops.view3d.view_camera()
                    for area in bpy.context.screen.areas:
                        if area.type == 'VIEW_3D':
                            area.spaces[0].region_3d.update()
                            area.spaces.active.region_3d.update()
                            break
                    # now crop it like its hot!
                    agilent_calc_region("Front")
                    agilent_render_camera(fCam)
                if renderLeft == True:
                    print("Rendering Left Camera!")
                    lCam = bpy.data.objects['autoCam_Left']
                    bpy.context.view_layer.objects.active = lCam
                    # switch to cam view
                    bpy.ops.view3d.view_camera()
                    for area in bpy.context.screen.areas:
                        if area.type == 'VIEW_3D':
                            area.spaces[0].region_3d.update()
                            area.spaces.active.region_3d.update()
                            break
                    # now crop it like its hot!
                    agilent_calc_region("Left")
                    agilent_render_camera(lCam)
                if renderRight == True:
                    print("Rendering Right Camera!")
                    rCam = bpy.data.objects['autoCam_Right']
                    bpy.context.view_layer.objects.active = rCam
                    # switch to cam view
                    bpy.ops.view3d.view_camera()
                    for area in bpy.context.screen.areas:
                        if area.type == 'VIEW_3D':
                            area.spaces[0].region_3d.update()
                            area.spaces.active.region_3d.update()
                            break
                    # now crop it like its hot!
                    agilent_calc_region("Right")
                    agilent_render_camera(rCam) 
                return True
                # render Cameras
                fCam = bpy.data.objects['autoCam_Front']
                bpy.context.view_layer.objects.active = fCam
                # switch to cam view 1
                bpy.ops.object.select_camera()
                area = next(area for area in bpy.context.screen.areas if area.type == 'VIEW_3D')
                area.spaces[0].region_3d.view_perspective = 'CAMERA'
                for area in bpy.context.screen.areas:
                    if area.type == 'VIEW_3D':
                        #bpy.ops.view3d.object_as_camera()
                        area.spaces[0].region_3d.update()
                        area.spaces[0].region_3d.view_perspective = 'CAMERA'
                        area.spaces[0].region_3d.update()
                        break
                agilent_render_camera(fCam)
                print("Rendering Camera!")

            def agilent_init(input):
                print(input)

            def main(context): #missing context
                agilent_init("Initializing Camera Script...")
                agilent_main(context)#missing context


            #class StartScriptButton(bpy.types.Operator):
            #    bl_idname = "scene.agilent_start_autocam_operator"
            #    bl_label = "Agilent Camera Automation"

            #    def execute(self, context):    
            #        main(context)
            #        
            #        return {'FINISHED'}
            main(bpy.context)#missing context
            #return {'FINISHED'}


            class ExpertSettingsButton(bpy.types.Operator):
                bl_idname = "scene.agilent_cam_settings_operator"
                bl_label = "Expert settings"

                def execute(self, context):    
                    print("Expert settings opened!")        
                    return {'FINISHED'}
            #    '''rename Render Images'''
            #outRenderFileNamePadded = outPathFull+"/Instrument0001.tga"
            #outRenderFileName = outPathFull+"/Instrument.tga"
            #if os.path.exists(outRenderFileName):
            #    os.remove(outRenderFileName)
            #os.rename(outRenderFileNamePadded, outRenderFileName)
            #outRenderFileNamePadded = outPathFull+"/_Mask0001.tga"
            #outRenderFileName = outPathFull+"/_Mask.tga"
            #if os.path.exists(outRenderFileName):
            #    os.remove(outRenderFileName)
            #os.rename(outRenderFileNamePadded, outRenderFileName)
            #outRenderFileNamePadded = outPathFull+"/_Floor_Shadow0001.tga"
            #outRenderFileName = outPathFull+"/_Floor_Shadow.tga"
            #if os.path.exists(outRenderFileName):
            #    os.remove(outRenderFileName)
            #os.rename(outRenderFileNamePadded, outRenderFileName)
            #outRenderFileNamePadded = outPathFull+"/_AO0001.tga"
            #outRenderFileName = outPathFull+"/_AO.tga"
            #if os.path.exists(outRenderFileName):
            #    os.remove(outRenderFileName)
            #os.rename(outRenderFileNamePadded, outRenderFileName)
            pass # RenderAutomation Script End
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of Render")
        return self.execute(context)


class SNA_PT_Render_Automation_44137(bpy.types.Panel):
    bl_label = "Render Automation"
    bl_idname = "SNA_PT_Render_Automation_44137"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = 'Agilent'
    bl_order = 0


    @classmethod
    def poll(cls, context):
        return True

    def draw_header(self, context):
        try:
            layout = self.layout
            layout.label(text=r"",icon_value=258)
        except Exception as exc:
            print(str(exc) + " | Error in Render Automation panel header")

    def draw(self, context):
        try:
            layout = self.layout
            box = layout.box()
            box.enabled = True
            box.alert = False
            box.scale_x = 1.0
            box.scale_y = 1.0
            box.prop(sn_cast_blend_data(bpy.context.scene),'externalsystem',icon_value=0,text=r"External File",emboss=True,toggle=False,invert_checkbox=False,)
            if sn_cast_blend_data(bpy.context.scene).externalsystem:
                box.prop(sn_cast_blend_data(bpy.context.scene),'rendsystemfile',icon_value=0,text=r"Select File",emboss=True,)
            else:
                pass
            col = layout.column(align=True)
            col.enabled = True
            col.alert = False
            col.scale_x = 1.0
            col.scale_y = 1.0
            box = col.box()
            box.enabled = True
            box.alert = False
            box.scale_x = 1.0
            box.scale_y = 1.0
            box.label(text=r"Output:",icon_value=690)
            col = box.column(align=True)
            col.enabled = True
            col.alert = False
            col.scale_x = 1.0
            col.scale_y = 1.0
            col.prop(sn_cast_blend_data(bpy.context.scene),'systemname',icon_value=0,text=r"Name",emboss=True,)
            col.prop(sn_cast_blend_data(bpy.context.scene),'outputpath',icon_value=0,text=r"Folder",emboss=True,)
            col.separator(factor=1.0)
            col = col.column(align=True)
            col.enabled = True
            col.alert = False
            col.scale_x = 1.0
            col.scale_y = 1.0
            row = col.row(align=True)
            row.enabled = True
            row.alert = False
            row.scale_x = 1.0
            row.scale_y = 1.0
            row.prop(sn_cast_blend_data(bpy.context.scene),'cameratorender',icon_value=0,text=r"CameraToRender",emboss=True,expand=True,)
            col.prop(sn_cast_blend_data(bpy.context.scene),'resmultiplier',text=r"Resolution Multiplier",emboss=True,slider=False,)
            row = col.row(align=True)
            row.enabled = True
            row.alert = False
            row.scale_x = 1.0
            row.scale_y = 1.0
            col = row.column(align=True)
            col.enabled = True
            col.alert = False
            col.scale_x = -0.5
            col.scale_y = 1.5
            col.prop(sn_cast_blend_data(bpy.context.scene),'previewrend',icon_value=0,text=r"Preview",emboss=True,toggle=True,invert_checkbox=False,)
            col = row.column(align=True)
            col.enabled = ((sn_cast_boolean(sn_cast_blend_data(bpy.context.scene).systemname) and sn_cast_boolean(sn_cast_blend_data(bpy.context.scene).outputpath)) or (sn_cast_boolean(sn_cast_blend_data(bpy.context.scene).outputpath) and sn_cast_blend_data(bpy.context.scene).externalsystem))
            col.alert = True
            col.scale_x = 3.190000057220459
            col.scale_y = 1.5
            op = col.operator("sna.render",text=r"",emboss=True,depress=False,icon_value=258)
        except Exception as exc:
            print(str(exc) + " | Error in Render Automation panel")


###############   REGISTER ICONS
def sn_register_icons():
    icons = []
    bpy.types.Scene.agilent__render_automation_icons = bpy.utils.previews.new()
    icons_dir = os.path.join( os.path.dirname( __file__ ), "icons" )
    for icon in icons:
        bpy.types.Scene.agilent__render_automation_icons.load( icon, os.path.join( icons_dir, icon + ".png" ), 'IMAGE' )

def sn_unregister_icons():
    bpy.utils.previews.remove( bpy.types.Scene.agilent__render_automation_icons )


###############   REGISTER PROPERTIES
def sn_register_properties():
    bpy.types.Scene.outputpath = bpy.props.StringProperty(name='OutputPath',description='Set the output folder for the rendering',subtype='DIR_PATH',options=set(),default='')
    bpy.types.Scene.rendsystemfile = bpy.props.StringProperty(name='RendSystemFile',description='',subtype='FILE_PATH',options=set(),update=update_rendsystemfile,default='')
    bpy.types.Scene.rendscene = bpy.props.StringProperty(name='RendScene',description='',subtype='FILE_PATH',options=set(),default='')
    bpy.types.Scene.previewrend = bpy.props.BoolProperty(name='PreviewRend',description='Render a preview (10% Resolution + low sample count)',options=set(),default=True)
    bpy.types.Scene.left = bpy.props.BoolProperty(name='Left',description='',options=set(),default=True)
    bpy.types.Scene.front = bpy.props.BoolProperty(name='Front',description='',options=set(),default=False)
    bpy.types.Scene.right = bpy.props.BoolProperty(name='Right',description='',options=set(),default=False)
    bpy.types.Scene.cameratorender = bpy.props.EnumProperty(name='CameraToRender',description='',options=set(),items=[('Left', 'Left', 'Render the Left camera'), ('Front', 'Front', 'Render the Front camera'), ('Right', 'Right', 'Render the Right camera')])
    bpy.types.Scene.systemname = bpy.props.StringProperty(name='SystemName',description='Set the name of the Instrument or the Solution',subtype='NONE',options=set(),default='')
    bpy.types.Scene.resmultiplier = bpy.props.FloatProperty(name='ResMultiplier',description='Set a custom render resolution multiplier (below 1 = smaller resolution / above 1 = higher resolution)',subtype='NONE',unit='NONE',options=set(),precision=2, default=1.0,min=0.10000000149011612,max=3.0)
    bpy.types.Scene.externalsystem = bpy.props.BoolProperty(name='ExternalSystem',description='',options=set(),default=True)

def sn_unregister_properties():
    del bpy.types.Scene.outputpath
    del bpy.types.Scene.rendsystemfile
    del bpy.types.Scene.rendscene
    del bpy.types.Scene.previewrend
    del bpy.types.Scene.left
    del bpy.types.Scene.front
    del bpy.types.Scene.right
    del bpy.types.Scene.cameratorender
    del bpy.types.Scene.systemname
    del bpy.types.Scene.resmultiplier
    del bpy.types.Scene.externalsystem


###############   REGISTER ADDON
def register():
    sn_register_icons()
    sn_register_properties()
    bpy.app.handlers.render_complete.append(render_complete_handler_E646F)
    bpy.utils.register_class(SNA_OT_Clear)
    bpy.utils.register_class(SNA_OT_Render)
    bpy.utils.register_class(SNA_PT_Render_Automation_44137)


###############   UNREGISTER ADDON
def unregister():
    sn_unregister_icons()
    sn_unregister_properties()
    bpy.utils.unregister_class(SNA_PT_Render_Automation_44137)
    bpy.utils.unregister_class(SNA_OT_Render)
    bpy.utils.unregister_class(SNA_OT_Clear)
    bpy.app.handlers.render_complete.remove(render_complete_handler_E646F)