# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

bl_info = {
    "name" : "Material Tools",
    "author" : "Elin", 
    "description" : "",
    "blender" : (3, 0, 0),
    "version" : (1, 0, 0),
    "location" : "",
    "warning" : "",
    "doc_url": "", 
    "tracker_url": "", 
    "category" : "3D View" 
}


import bpy
import bpy.utils.previews


addon_keymaps = {}
_icons = None


importmaterial = {'sna_objects': [], 'sna_importedmaterialname': '', }
class SNA_OT_Eh_Cleanmaterialslots_5D4E5(bpy.types.Operator):
    bl_idname = "sna.eh_cleanmaterialslots_5d4e5"
    bl_label = "EH_CleanMaterialSlots"
    bl_description = "Remove all unused Material slots from objects"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and False:
            cls.poll_message_set()
        return not False

    def execute(self, context):
        if bpy.context.scene.sna_eh_allmats:
            bpy.ops.object.select_by_type(type='MESH')
            objs = bpy.context.selected_objects
            for obj in objs:
                if obj.type == 'MESH':
                    mesh = obj.data
                    faces = mesh.polygons
                    slots = obj.material_slots
                    # get material index per face
                    face_len = len (faces)
                    used_material_indices = [0 for n in range (face_len)]
                    faces.foreach_get ('material_index', used_material_indices)
                    # one index should only be once in the list
                    used_material_indices = set (used_material_indices)
                    # list unused material slots
                    slot_len = len (slots)
                    all_material_slot_indices = set (n for n in range (slot_len))
                    unused_slot_indices = all_material_slot_indices - used_material_indices
                    # override context's object to obj
                    ctx = bpy.context.copy ()
                    ctx['object'] = obj
                    # delete unused slots
                    unused_slot_indices = list (unused_slot_indices)
                    unused_slot_indices.sort (reverse=True)
                    for slot_index in unused_slot_indices:
                        obj.active_material_index = slot_index
                        bpy.ops.object.material_slot_remove (ctx)
            bpy.ops.object.select_all(action='DESELECT')
        else:
            #bpy.ops.object.select_by_type(type='MESH')
            objs = bpy.context.selected_objects
            for obj in objs:
                if obj.type == 'MESH':
                    mesh = obj.data
                    faces = mesh.polygons
                    slots = obj.material_slots
                    # get material index per face
                    face_len = len (faces)
                    used_material_indices = [0 for n in range (face_len)]
                    faces.foreach_get ('material_index', used_material_indices)
                    # one index should only be once in the list
                    used_material_indices = set (used_material_indices)
                    # list unused material slots
                    slot_len = len (slots)
                    all_material_slot_indices = set (n for n in range (slot_len))
                    unused_slot_indices = all_material_slot_indices - used_material_indices
                    # override context's object to obj
                    ctx = bpy.context.copy ()
                    ctx['object'] = obj
                    # delete unused slots
                    unused_slot_indices = list (unused_slot_indices)
                    unused_slot_indices.sort (reverse=True)
                    for slot_index in unused_slot_indices:
                        obj.active_material_index = slot_index
                        bpy.ops.object.material_slot_remove (ctx)
            #bpy.ops.object.select_all(action='DESELECT')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Eh_Removeduplicatedmaterials_B4Acd(bpy.types.Operator):
    bl_idname = "sna.eh_removeduplicatedmaterials_b4acd"
    bl_label = "EH_RemoveDuplicatedMaterials"
    bl_description = "Remove al, duplicated Materials with a .001, .002,... suffix and apply the original one"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and False:
            cls.poll_message_set()
        return not False

    def execute(self, context):
        props = self.properties
        scene = context.scene 

        def replace_material(bad_mat, good_mat):
            bad_mat.user_remap(good_mat)
            bpy.data.materials.remove(bad_mat)

        def get_duplicate_materials(og_material):
            common_name = og_material.name
            if common_name[-3:].isnumeric():
                common_name = common_name[:-4]
            duplicate_materials = []
            for material in bpy.data.materials:
                if material is not og_material:
                    name = material.name
                    if name[-3:].isnumeric() and name[-4] == ".":
                        name = name[:-4]
                    if name == common_name:
                        duplicate_materials.append(material)
            text = "{} duplicate materials found"
            print(text.format(len(duplicate_materials)))
            return duplicate_materials

        def remove_all_duplicate_materials():
            i = 0
            while i < len(bpy.data.materials):
                og_material = bpy.data.materials[i]
                print("og material: " + og_material.name)
                # get duplicate materials
                duplicate_materials = get_duplicate_materials(og_material)
                # replace all duplicates
                for duplicate_material in duplicate_materials:
                    replace_material(duplicate_material, og_material)
                # adjust name to no trailing numbers
                if og_material.name[-3:].isnumeric() and og_material.name[-4] == ".":
                    og_material.name = og_material.name[:-4]
                i = i+1
        remove_all_duplicate_materials()

        def replace_material(bad_mat, good_mat):
            bad_mat.user_remap(good_mat)
            bpy.data.materials.remove(bad_mat)

        def get_duplicate_materials(og_material):
            common_name = og_material.name
            if common_name[-3:].isnumeric():
                common_name = common_name[:-4]
            duplicate_materials = []
            for material in bpy.data.materials:
                if material is not og_material:
                    name = material.name
                    if name[-3:].isnumeric() and name[-4] == ".":
                        name = name[:-4]
                    if name == common_name:
                        duplicate_materials.append(material)
            text = "{} duplicate materials found"
            print(text.format(len(duplicate_materials)))
            return duplicate_materials

        def remove_all_duplicate_materials():
            i = 0
            while i < len(bpy.data.materials):
                og_material = bpy.data.materials[i]
                print("og material: " + og_material.name)
                # get duplicate materials
                duplicate_materials = get_duplicate_materials(og_material)
                # replace all duplicates
                for duplicate_material in duplicate_materials:
                    replace_material(duplicate_material, og_material)
                # adjust name to no trailing numbers
                if og_material.name[-3:].isnumeric() and og_material.name[-4] == ".":
                    og_material.name = og_material.name[:-4]
                i = i+1
        remove_all_duplicate_materials()
        bpy.ops.outliner.orphans_purge(do_local_ids=True, do_linked_ids=True, do_recursive=True)
        self.report({'INFO'}, "DONE!")
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_add_to_eevee_material_pt_context_material_8FAB8(self, context):
    if not (False):
        layout = self.layout
        row_C145D = layout.row(heading='', align=True)
        row_C145D.alert = False
        row_C145D.enabled = True
        row_C145D.active = True
        row_C145D.use_property_split = False
        row_C145D.use_property_decorate = False
        row_C145D.scale_x = 1.0
        row_C145D.scale_y = 1.0
        row_C145D.alignment = 'Expand'.upper()
        op = row_C145D.operator('sna.ot_importmaterial_062be', text='Paste Material', icon_value=599, emboss=True, depress=False)
        op = row_C145D.operator('sna.eh_removeduplicatedmaterials_b4acd', text='Remove Duplicate', icon_value=553, emboss=True, depress=False)
        split_256BB = row_C145D.split(factor=0.8130841255187988, align=True)
        split_256BB.alert = False
        split_256BB.enabled = True
        split_256BB.active = True
        split_256BB.use_property_split = False
        split_256BB.use_property_decorate = False
        split_256BB.scale_x = 1.0
        split_256BB.scale_y = 1.0
        split_256BB.alignment = 'Expand'.upper()
        op = split_256BB.operator('sna.eh_cleanmaterialslots_5d4e5', text='Clean Slots', icon_value=165, emboss=True, depress=False)
        split_256BB.prop(bpy.context.scene, 'sna_eh_allmats', text='', icon_value=3, emboss=True, toggle=True)


def sna_add_to_view3d_mt_editor_menus_D9040(self, context):
    if not (False):
        layout = self.layout


class SNA_OT_Ot_Importmaterial_062Be(bpy.types.Operator):
    bl_idname = "sna.ot_importmaterial_062be"
    bl_label = "OT_ImportMaterial"
    bl_description = "Past material from the object in the copy buffer"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and False:
            cls.poll_message_set()
        return not False

    def execute(self, context):
        importmaterial['sna_objects'] = []
        for i_8725A in range(len(bpy.context.view_layer.objects.selected)):
            importmaterial['sna_objects'].append(bpy.context.view_layer.objects.selected[i_8725A])
            bpy.context.view_layer.objects.active = bpy.context.view_layer.objects.selected[i_8725A]
        bpy.ops.view3d.pastebuffer()
        bpy.context.view_layer.objects.active = list(bpy.context.view_layer.objects.selected)[0]
        importmaterial['sna_importedmaterialname'] = bpy.context.active_object.material_slots[0].name
        bpy.ops.object.delete('INVOKE_DEFAULT', confirm=False)
        for i_7DD9C in range(len(importmaterial['sna_objects'])):
            importmaterial['sna_objects'][i_7DD9C].select_set(state=True, )
            bpy.context.view_layer.objects.active = importmaterial['sna_objects'][i_7DD9C]
            bpy.context.active_object.active_material = bpy.data.materials[importmaterial['sna_importedmaterialname'].split('.')[0]]
            bpy.ops.outliner.orphans_purge(do_local_ids=True, do_linked_ids=True, do_recursive=True)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def register():
    global _icons
    _icons = bpy.utils.previews.new()
    bpy.types.Scene.sna_eh_allmats = bpy.props.BoolProperty(name='EH_AllMats', description='Remove all unused Material slots from all objects', default=False)
    bpy.utils.register_class(SNA_OT_Eh_Cleanmaterialslots_5D4E5)
    bpy.utils.register_class(SNA_OT_Eh_Removeduplicatedmaterials_B4Acd)
    bpy.types.EEVEE_MATERIAL_PT_context_material.prepend(sna_add_to_eevee_material_pt_context_material_8FAB8)
    bpy.types.VIEW3D_MT_editor_menus.append(sna_add_to_view3d_mt_editor_menus_D9040)
    bpy.utils.register_class(SNA_OT_Ot_Importmaterial_062Be)


def unregister():
    global _icons
    bpy.utils.previews.remove(_icons)
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    for km, kmi in addon_keymaps.values():
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()
    del bpy.types.Scene.sna_eh_allmats
    bpy.utils.unregister_class(SNA_OT_Eh_Cleanmaterialslots_5D4E5)
    bpy.utils.unregister_class(SNA_OT_Eh_Removeduplicatedmaterials_B4Acd)
    bpy.types.EEVEE_MATERIAL_PT_context_material.remove(sna_add_to_eevee_material_pt_context_material_8FAB8)
    bpy.types.VIEW3D_MT_editor_menus.remove(sna_add_to_view3d_mt_editor_menus_D9040)
    bpy.utils.unregister_class(SNA_OT_Ot_Importmaterial_062Be)
