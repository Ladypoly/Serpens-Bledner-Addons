# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.
#
# This addon was created with the Serpens - Visual Scripting Addon.
# This code is generated from nodes and is not intended for manual editing.
# You can find out more about Serpens at <https://blendermarket.com/products/serpens>.


bl_info = {
    "name": "Quest Homes Animation Baking Tools",
    "description": "",
    "author": "Elin",
    "version": (1, 0, 1),
    "blender": (2, 93, 0),
    "location": "",
    "warning": "",
    "wiki_url": "",
    "tracker_url": "",
    "category": "3D View"
}


###############   IMPORTS
import bpy
from bpy.utils import previews
import os
import math


###############   INITALIZE VARIABLES
###############   SERPENS FUNCTIONS
def exec_line(line):
    exec(line)

def sn_print(tree_name, *args):
    if tree_name in bpy.data.node_groups:
        item = bpy.data.node_groups[tree_name].sn_graphs[0].prints.add()
        for arg in args:
            item.value += str(arg) + ";;;"
        if bpy.context and bpy.context.screen:
            for area in bpy.context.screen.areas:
                area.tag_redraw()
    print(*args)

def sn_cast_string(value):
    return str(value)

def sn_cast_boolean(value):
    if type(value) == tuple:
        for data in value:
            if bool(data):
                return True
        return False
    return bool(value)

def sn_cast_float(value):
    if type(value) == str:
        try:
            value = float(value)
            return value
        except:
            return float(bool(value))
    elif type(value) == tuple:
        return float(value[0])
    elif type(value) == list:
        return float(len(value))
    elif not type(value) in [float, int, bool]:
        try:
            value = len(value)
            return float(value)
        except:
            return float(bool(value))
    return float(value)

def sn_cast_int(value):
    return int(sn_cast_float(value))

def sn_cast_boolean_vector(value, size):
    if type(value) in [str, bool, int, float]:
        return_value = []
        for i in range(size):
            return_value.append(bool(value))
        return tuple(return_value)
    elif type(value) == tuple:
        return_value = []
        for i in range(size):
            return_value.append(bool(value[i]) if len(value) > i else bool(value[0]))
        return tuple(return_value)
    elif type(value) == list:
        return sn_cast_boolean_vector(tuple(value), size)
    else:
        try:
            value = tuple(value)
            return sn_cast_boolean_vector(value, size)
        except:
            return sn_cast_boolean_vector(bool(value), size)

def sn_cast_float_vector(value, size):
    if type(value) in [str, bool, int, float]:
        return_value = []
        for i in range(size):
            return_value.append(sn_cast_float(value))
        return tuple(return_value)
    elif type(value) == tuple:
        return_value = []
        for i in range(size):
            return_value.append(sn_cast_float(value[i]) if len(value) > i else sn_cast_float(value[0]))
        return tuple(return_value)
    elif type(value) == list:
        return sn_cast_float_vector(tuple(value), size)
    else:
        try:
            value = tuple(value)
            return sn_cast_float_vector(value, size)
        except:
            return sn_cast_float_vector(sn_cast_float(value), size)

def sn_cast_int_vector(value, size):
    return tuple(map(int, sn_cast_float_vector(value, size)))

def sn_cast_color(value, use_alpha):
    length = 4 if use_alpha else 3
    value = sn_cast_float_vector(value, length)
    tuple_list = []
    for data in range(length):
        data = value[data] if len(value) > data else value[0]
        tuple_list.append(sn_cast_float(min(1, max(0, data))))
    return tuple(tuple_list)

def sn_cast_list(value):
    if type(value) in [str, tuple, list]:
        return list(value)
    elif type(value) in [int, float, bool]:
        return [value]
    else:
        try:
            value = list(value)
            return value
        except:
            return [value]

def sn_cast_blend_data(value):
    if hasattr(value, "bl_rna"):
        return value
    elif type(value) in [tuple, bool, int, float, list]:
        return None
    elif type(value) == str:
        try:
            value = eval(value)
            return value
        except:
            return None
    else:
        return None

def sn_cast_enum(string, enum_values):
    for item in enum_values:
        if item[1] == string:
            return item[0]
        elif item[0] == string.upper():
            return item[0]
    return string


###############   IMPERATIVE CODE
###############   EVALUATED CODE
#######   Quest Homes Animation Baking Tools
class SNA_PT_Animation_Baking_90FBC(bpy.types.Panel):
    bl_label = "Animation Baking"
    bl_idname = "SNA_PT_Animation_Baking_90FBC"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = 'Quest Homes'
    bl_order = 0


    @classmethod
    def poll(cls, context):
        return True

    def draw_header(self, context):
        try:
            layout = self.layout
        except Exception as exc:
            print(str(exc) + " | Error in Animation Baking panel header")

    def draw(self, context):
        try:
            layout = self.layout
            row = layout.row(align=True)
            row.enabled = True
            row.alert = False
            row.scale_x = 1.0
            row.scale_y = 1.5
            row = row.row(align=True)
            row.enabled = True
            row.alert = False
            row.scale_x = 1.3600000143051147
            row.scale_y = 1.0
            op = row.operator("sna.bake_partikles",text=r"Bake Particle",emboss=True,depress=False,icon_value=590)
            row.prop(bpy.context.scene,'startpbat1',icon_value=499,text=r"",emboss=True,toggle=True,invert_checkbox=False,)
            box = layout.box()
            box.enabled = True
            box.alert = False
            box.scale_x = 1.0
            box.scale_y = 1.25
            box.prop(bpy.context.scene,'randomize_factor',text=r"Randomize Factor",emboss=True,slider=True,)
            box.label(text=r"Fade Animation:",icon_value=0)
            col = box.column(align=True)
            col.enabled = True
            col.alert = False
            col.scale_x = 1.0
            col.scale_y = 1.0
            split = col.split(align=True,factor=0.5)
            split.enabled = True
            split.alert = False
            split.scale_x = 1.0
            split.scale_y = 1.0
            split.prop(bpy.context.scene,'fadein',text=r"FadeIn",emboss=True,slider=True,)
            split.prop(bpy.context.scene,'fadeout',text=r"FadeOut",emboss=True,slider=True,)
            row = col.row(align=True)
            row.enabled = True
            row.alert = False
            row.scale_x = 1.3600000143051147
            row.scale_y = 1.0
            split = row.split(align=True,factor=0.5)
            split.enabled = bpy.context.scene.randomscale
            split.alert = False
            split.scale_x = 1.0
            split.scale_y = 1.0
            split.prop(bpy.context.scene,'scalemin',text=r"Min",emboss=True,slider=True,)
            split.prop(bpy.context.scene,'scalemax',text=r"Max",emboss=True,slider=True,)
            row.prop(bpy.context.scene,'randomscale',icon_value=76,text=r"",emboss=True,toggle=True,invert_checkbox=False,)
            col.prop(bpy.context.scene,'keydecirate',text=r"Keyframe decimate rate",emboss=True,slider=True,)
            row = box.row(align=True)
            row.enabled = True
            row.alert = False
            row.scale_x = 1.0
            row.scale_y = 1.5
            op = row.operator("sna.bake_loop",text=r"Bake Loop",emboss=True,depress=False,icon_value=232)
            box = layout.box()
            box.enabled = True
            box.alert = False
            box.scale_x = 1.0
            box.scale_y = 1.25
            row = box.row(align=True)
            row.enabled = True
            row.alert = False
            row.scale_x = 1.0
            row.scale_y = 1.0
            op = row.operator("sna.addvertexgrouptolooseparts",text=r"V group to Parts",emboss=True,depress=False,icon_value=0)
            op = row.operator("sna.parentemptystovertices",text=r"Empthys to Verts",emboss=True,depress=False,icon_value=0)
        except Exception as exc:
            print(str(exc) + " | Error in Animation Baking panel")


class SNA_OT_Addvertexgrouptolooseparts(bpy.types.Operator):
    bl_idname = "sna.addvertexgrouptolooseparts"
    bl_label = "AddVertexGroupToLooseParts"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            pass # AddVertexGroupToLooseParts Script Start
            import bpy

            def island_verts(mesh):  
                import bmesh
                bpy.ops.object.mode_set(mode='EDIT')
                bpy.ops.mesh.select_all(action='DESELECT')
                bm = bmesh.from_edit_mesh(mesh)
                bm.verts.ensure_lookup_table()
                verts = [v.index for v in bm.verts]
                vgs = []
                while len(verts):        
                    bm.verts[verts[0]].select = True
                    #bpy.ops.mesh.select_linked(delimit={'SEAM'})
                    bpy.ops.mesh.select_linked()
                    sv = [v.index for v in bm.verts if v.select]
                    vgs.append(sv)
                    for v in sv:
                        bm.verts[v].select = False
                        verts.remove(v)
                bm.free() # prob not nec.        
                bpy.ops.object.mode_set(mode='OBJECT')
                return vgs      
            # test run            
            obj = bpy.context.object
            mesh = obj.data
            vgs = island_verts(mesh)
            for vg in vgs:
                group = obj.vertex_groups.new()
                group.name = "Island"
                group.add(vg, 1.0, 'ADD')
            pass # AddVertexGroupToLooseParts Script End
        except Exception as exc:
            print(str(exc) + " | Error in execute function of AddVertexGroupToLooseParts")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of AddVertexGroupToLooseParts")
        return self.execute(context)


class SNA_OT_Bake_Loop(bpy.types.Operator):
    bl_idname = "sna.bake_loop"
    bl_label = "Bake Loop"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            pass # RandomizedAniLoop Script Start
            import bpy
            import random
            props = self.properties
            scene = context.scene
            #----------------Set Variables--------------------
            RandomizeLoops = bpy.context.scene.randomize_factor
            FadeInTime = bpy.context.scene.fadein
            FadeOutTime = bpy.context.scene.fadeout
            RandomScale = bpy.context.scene.randomscale
            RandomScaleMin = bpy.context.scene.scalemin
            RandomScaleMax = bpy.context.scene.scalemax
            DecimateRate = bpy.context.scene.keydecirate
            #----------------Set Variables--------------------
            #----------------Set Animation length--------------------
            first_frame = 9999
            last_frame = -9999
            for action in bpy.data.actions :
                    if  action.frame_range[1] > last_frame :
                        AnimationLength = action.frame_range[1]
                    if  action.frame_range[0] < first_frame :
                        first_frame = action.frame_range[0]
            print ("Ready") 
            txt = ("Started")            
            #----------------Delte all scale Keyframes--------------------
            bpy.ops.object.select_all(action='SELECT')
            bpy.context.area.type = 'DOPESHEET_EDITOR'
            bpy.context.space_data.dopesheet.filter_text = "scale"
            bpy.ops.action.select_all(action='SELECT')
            bpy.ops.action.delete()
            bpy.context.space_data.dopesheet.filter_text = ""
            print ("scale Keyframes cleared")
            #----------------RandomScale--------------------
            bpy.context.area.ui_type = 'VIEW_3D'
            bpy.context.scene.tool_settings.transform_pivot_point = 'INDIVIDUAL_ORIGINS'
            if RandomScale:      
                for obj in bpy.context.selected_objects:
                    if obj.type == 'MESH':
                        RandoScale = random.uniform(RandomScaleMin, RandomScaleMax) 
                        obj.scale = (RandoScale,RandoScale,RandoScale)
            #----------------Apply transforms--------------------
            bpy.ops.object.make_single_user(object=True, obdata=True, material=False, animation=False)
            bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
            bpy.context.scene.tool_settings.transform_pivot_point = 'MEDIAN_POINT'
            print ("transformation applyed")
            #----------------Keyframe Fade In and Fade Out Scaling--------------------
            bpy.context.scene.frame_current = first_frame+FadeInTime
            bpy.ops.anim.keyframe_insert_menu(type='Scaling')
            bpy.context.scene.frame_current = AnimationLength-FadeOutTime
            bpy.ops.anim.keyframe_insert_menu(type='Scaling')
            bpy.context.scene.frame_end = AnimationLength
            bpy.context.scene.frame_current = first_frame
            for obj in bpy.context.selected_objects:
                if obj.type == 'MESH':
                    obj.scale = (0.001,0.001,0.001)
            bpy.ops.anim.keyframe_insert_menu(type='Scaling')
            bpy.context.scene.frame_current = AnimationLength 
            for obj in bpy.context.selected_objects:
                if obj.type == 'MESH':
                    obj.scale = (0.001,0.001,0.001)
            bpy.ops.anim.keyframe_insert_menu(type='Scaling')
            print ("Fade In and fade out keyed")
            #----------------Bake Keyframes--------------------
            bpy.context.area.type = 'GRAPH_EDITOR'
            bpy.ops.graph.select_all(action='SELECT')
            bpy.ops.graph.sample()
            bpy.ops.nla.bake(frame_start=first_frame, frame_end=AnimationLength, bake_types={'OBJECT'})
            print ("Animation Baked")
            #----------------Randomize--------------------
            for i in range(RandomizeLoops):
                bpy.ops.object.select_all(action='DESELECT')
                y = random.choice(range(0, 999))
                bpy.ops.object.select_random(seed=y)
                x = random.choice(range(int(first_frame), int(AnimationLength)))
                bpy.context.area.ui_type = 'TIMELINE'
                bpy.ops.action.select_all(action='SELECT')
                bpy.ops.transform.transform(mode='TIME_TRANSLATE', value=(x, 0, 0, 0), orient_axis='Z', orient_type='VIEW', orient_matrix=((-1, -0, -0), (-0, -1, -0), (-0, -0, -1)), orient_matrix_type='VIEW', mirror=True, use_proportional_edit=False, proportional_edit_falloff='SMOOTH', proportional_size=1, use_proportional_connected=False, use_proportional_projected=False)
                bpy.ops.action.select_all(action='DESELECT')
                bpy.context.scene.frame_current = (AnimationLength+1)
                bpy.context.area.type = 'DOPESHEET_EDITOR'
                bpy.ops.action.select_leftright(mode='RIGHT', extend=False)
                bpy.context.area.ui_type = 'TIMELINE'
                bpy.ops.transform.transform(mode='TIME_TRANSLATE', value=(-AnimationLength, 0, 0, 0), orient_axis='Z', orient_type='VIEW', orient_matrix=((-1, -0, -0), (-0, -1, -0), (-0, -0, -1)), orient_matrix_type='VIEW', mirror=True, use_proportional_edit=False, proportional_edit_falloff='SMOOTH', proportional_size=1, use_proportional_connected=False, use_proportional_projected=False)
            print ("Randomized")   
            #----------------Optimize and post process--------------------
            bpy.ops.object.select_all(action='SELECT')
            bpy.context.area.type = 'GRAPH_EDITOR'
            bpy.ops.graph.select_all(action='SELECT')
            bpy.ops.graph.decimate(mode='RATIO', remove_ratio=DecimateRate)
            bpy.context.area.ui_type = 'VIEW_3D'
            bpy.ops.screen.animation_play()
            print ("DONE")
            pass # RandomizedAniLoop Script End
        except Exception as exc:
            print(str(exc) + " | Error in execute function of Bake Loop")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of Bake Loop")
        return self.execute(context)


class SNA_OT_Bake_Partikles(bpy.types.Operator):
    bl_idname = "sna.bake_partikles"
    bl_label = "Bake Partikles"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            pass # BakeParticles Script Start
            props = self.properties
            scene = context.scene
            # Set these to False if you don't want to key that property.
            KEYFRAME_LOCATION = True
            KEYFRAME_ROTATION = True
            KEYFRAME_SCALE = True
            KEYFRAME_VISIBILITY = False  # Viewport and render visibility.
            KEYFRAME_VISIBILITY_SCALE = True
            StartAllAt1 = bpy.context.scene.startpbat1
            P_startframe = bpy.data.particles["ParticleSettings"].frame_start
            P_endframe = bpy.data.particles["ParticleSettings"].frame_end

            def create_objects_for_particles(ps, obj):
                # Duplicate the given object for every particle and return the duplicates.
                # Use instances instead of full copies.
                obj_list = []
                mesh = obj.data
                particles_coll = bpy.data.collections.new(name="particles")
                bpy.context.scene.collection.children.link(particles_coll)
                # print ("Baking Particles 2")
                for i, _ in enumerate(ps.particles):
                    dupli = bpy.data.objects.new(
                                name="particle.{:03d}".format(i),
                                object_data=mesh)
                    particles_coll.objects.link(dupli)
                    obj_list.append(dupli)
                return obj_list
                # print ("Baking Particles 3")

            def match_and_keyframe_objects(ps, obj_list, start_frame, end_frame):
                # Match and keyframe the objects to the particles for every frame in the
                # given range.
                for frame in range(start_frame, end_frame + 1):
                    print("frame {} processed".format(frame))
                    bpy.context.scene.frame_set(frame)
                    for p, obj in zip(ps.particles, obj_list):
                        match_object_to_particle(p, obj)
                        keyframe_obj(obj)

            def match_object_to_particle(p, obj):
                # Match the location, rotation, scale and visibility of the object to
                # the particle.
                loc = p.location
                rot = p.rotation
                size = p.size
                if p.alive_state == 'ALIVE':
                    vis = True
                else:
                    vis = False
                obj.location = loc
                # Set rotation mode to quaternion to match particle rotation.
                obj.rotation_mode = 'QUATERNION'
                obj.rotation_quaternion = rot
                # print ("Baking Particles 4")
                if KEYFRAME_VISIBILITY_SCALE:
                    if vis:
                        obj.scale = (size, size, size)
                    if not vis:
                        obj.scale = (0.001, 0.001, 0.001)
                #obj.hide_viewport = not(vis) # <<<-- this was called "hide" in <= 2.79
            # obj.hide_render = not(vis)

            def keyframe_obj(obj):
                # Keyframe location, rotation, scale and visibility if specified.
                if KEYFRAME_LOCATION:
                    obj.keyframe_insert("location")
                if KEYFRAME_ROTATION:
                    obj.keyframe_insert("rotation_quaternion")
                if KEYFRAME_SCALE:
                    obj.keyframe_insert("scale")
                if KEYFRAME_VISIBILITY:
                    obj.keyframe_insert("hide_viewport") # <<<-- this was called "hide" in <= 2.79
                    obj.keyframe_insert("hide_render")
                    # print ("Baking Particles 5")

            def main():
                    #----------------Set Particle Lifetime--------------------  
                if StartAllAt1: 
                    bpy.data.particles["ParticleSettings"].frame_start = 1
                    bpy.data.particles["ParticleSettings"].frame_end = 1
                    particle_lifetime = bpy.data.particles["ParticleSettings"].lifetime
                    bpy.context.scene.frame_end = particle_lifetime
                #in 2.8 you need to evaluate the Dependency graph in order to get data from animation, modifiers, etc           
                depsgraph = bpy.context.evaluated_depsgraph_get()
                # assume only 2 objects are selected
                if len(bpy.context.selected_objects) != 2:
                    self.report({'INFO'}, 'you will have to select two objects, active object must have a particle system')
                    return {'CANCELLED'}
                # active object should be the one with the particle system
                if len(bpy.context.active_object.particle_systems.keys()) == 0:
                    self.report({'INFO'}, 'active object must have a particle system')
                    return {'CANCELLED'}
                ps_obj = bpy.context.object
                ps_obj_evaluated = depsgraph.objects[ ps_obj.name ]
                obj = [obj for obj in bpy.context.selected_objects if obj != ps_obj][0]
                # print ("Baking Particles 6")
                for psy in ps_obj_evaluated.particle_systems:         
                    ps = psy  # Assume only 1 particle system is present.
                    start_frame = bpy.context.scene.frame_start
                    end_frame = bpy.context.scene.frame_end
                    obj_list = create_objects_for_particles(ps, obj)
                    match_and_keyframe_objects(ps, obj_list, start_frame, end_frame)
                    # print ("Baking Particles 7")
            # call main
            main()
            #----------------Reset Particle Settings--------------------  
            if StartAllAt1: 
                bpy.data.particles["ParticleSettings"].frame_start = P_startframe
                bpy.data.particles["ParticleSettings"].frame_end = P_endframe 
                #----------------Run radomize after-------------------- 

            #        def execute(self, context):
            #            bpy.ops.camera.elintools.bakeanimation()     
            pass # BakeParticles Script End
        except Exception as exc:
            print(str(exc) + " | Error in execute function of Bake Partikles")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of Bake Partikles")
        return self.execute(context)


class SNA_OT_Parentemptystovertices(bpy.types.Operator):
    bl_idname = "sna.parentemptystovertices"
    bl_label = "ParentEmptysToVertices"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            pass # ParentEmptysToVertices Script Start
            import bpy
            from bpy import context
            ob = context.object
            coll = context.collection
            for v in ob.data.vertices:
                mt = bpy.data.objects.new(
                    f"Vert{v.index}",
                    None,
                    )
                mt.empty_display_type = 'CIRCLE'
                mt.empty_display_size = 0.2
                mt.parent = ob
                mt.parent_type = 'VERTEX'
                mt.parent_vertices = [v.index] * 3
                coll.objects.link(mt)
            pass # ParentEmptysToVertices Script End
        except Exception as exc:
            print(str(exc) + " | Error in execute function of ParentEmptysToVertices")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of ParentEmptysToVertices")
        return self.execute(context)


###############   REGISTER ICONS
def sn_register_icons():
    icons = []
    bpy.types.Scene.quest_homes_animation_baking_tools_icons = bpy.utils.previews.new()
    icons_dir = os.path.join( os.path.dirname( __file__ ), "icons" )
    for icon in icons:
        bpy.types.Scene.quest_homes_animation_baking_tools_icons.load( icon, os.path.join( icons_dir, icon + ".png" ), 'IMAGE' )

def sn_unregister_icons():
    bpy.utils.previews.remove( bpy.types.Scene.quest_homes_animation_baking_tools_icons )


###############   REGISTER PROPERTIES
def sn_register_properties():
    bpy.types.Scene.startpbat1 = bpy.props.BoolProperty(name='StartPBat1',description='Particles will be emittet only at frame one. This is usefull for creating a loop',options=set(),default=False)
    bpy.types.Scene.randomize_factor = bpy.props.IntProperty(name='Randomize Factor',description='Randomize Factor',subtype='NONE',options=set(),default=100,min=0,max=500)
    bpy.types.Scene.fadein = bpy.props.IntProperty(name='FadeIn',description='',subtype='NONE',options=set(),default=25,min=0,max=100)
    bpy.types.Scene.fadeout = bpy.props.IntProperty(name='FadeOut',description='',subtype='NONE',options=set(),default=25,min=0,max=100)
    bpy.types.Scene.randomscale = bpy.props.BoolProperty(name='RandomScale',description='',options=set(),default=False)
    bpy.types.Scene.scalemin = bpy.props.FloatProperty(name='ScaleMin',description='',subtype='NONE',unit='NONE',options=set(),precision=2, default=1.0,min=0.009999999776482582,max=1.0)
    bpy.types.Scene.scalemax = bpy.props.FloatProperty(name='ScaleMax',description='',subtype='NONE',unit='NONE',options=set(),precision=2, default=2.0,min=1.0,max=2.5)
    bpy.types.Scene.keydecirate = bpy.props.FloatProperty(name='KeyDeciRate',description='',subtype='NONE',unit='NONE',options=set(),precision=2, default=0.8500000238418579,min=0.0,max=0.9900000095367432)

def sn_unregister_properties():
    del bpy.types.Scene.startpbat1
    del bpy.types.Scene.randomize_factor
    del bpy.types.Scene.fadein
    del bpy.types.Scene.fadeout
    del bpy.types.Scene.randomscale
    del bpy.types.Scene.scalemin
    del bpy.types.Scene.scalemax
    del bpy.types.Scene.keydecirate


###############   REGISTER ADDON
def register():
    sn_register_icons()
    sn_register_properties()
    bpy.utils.register_class(SNA_PT_Animation_Baking_90FBC)
    bpy.utils.register_class(SNA_OT_Addvertexgrouptolooseparts)
    bpy.utils.register_class(SNA_OT_Bake_Loop)
    bpy.utils.register_class(SNA_OT_Bake_Partikles)
    bpy.utils.register_class(SNA_OT_Parentemptystovertices)


###############   UNREGISTER ADDON
def unregister():
    sn_unregister_icons()
    sn_unregister_properties()
    bpy.utils.unregister_class(SNA_OT_Parentemptystovertices)
    bpy.utils.unregister_class(SNA_OT_Bake_Partikles)
    bpy.utils.unregister_class(SNA_OT_Bake_Loop)
    bpy.utils.unregister_class(SNA_OT_Addvertexgrouptolooseparts)
    bpy.utils.unregister_class(SNA_PT_Animation_Baking_90FBC)