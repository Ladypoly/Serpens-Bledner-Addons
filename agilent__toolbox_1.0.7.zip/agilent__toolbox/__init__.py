# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.
#
# This addon was created with the Serpens - Visual Scripting Addon.
# This code is generated from nodes and is not intended for manual editing.
# You can find out more about Serpens at <https://blendermarket.com/products/serpens>.


bl_info = {
    "name": "Agilent - Toolbox",
    "description": "",
    "author": "Creapolis",
    "version": (1, 0, 7),
    "blender": (2, 93, 0),
    "location": "Properties Panel -> Agilent",
    "warning": "",
    "wiki_url": "",
    "tracker_url": "",
    "category": "3D View"
}


###############   IMPORTS
import bpy
from bpy.utils import previews
import os
import math


###############   INITALIZE VARIABLES
import_material_fromclipboard = {
    "activeobjectname": "", 
    "importedobjectname": "", 
    "selectedobjects": None, 
    "activeobject": None, 
    "selectedobject": None, 
    "selectedobjectslist": [], 
    "importedmaterialname": "", 
    }
fbx_batchimport = {
    "importedemptys": [], 
    "importedmeshes": [], 
    "done": True, 
    }
clean_duplimaterials = {
    "new_variable": "", 
    }
fiximportedmeshes = {
    "temp_obj": None, 
    "originalobj_name": "", 
    "tempchildren": [], 
    }


###############   SERPENS FUNCTIONS
def exec_line(line):
    exec(line)

def sn_print(tree_name, *args):
    if tree_name in bpy.data.node_groups:
        item = bpy.data.node_groups[tree_name].sn_graphs[0].prints.add()
        for arg in args:
            item.value += str(arg) + ";;;"
        if bpy.context and bpy.context.screen:
            for area in bpy.context.screen.areas:
                area.tag_redraw()
    print(*args)

def sn_cast_string(value):
    return str(value)

def sn_cast_boolean(value):
    if type(value) == tuple:
        for data in value:
            if bool(data):
                return True
        return False
    return bool(value)

def sn_cast_float(value):
    if type(value) == str:
        try:
            value = float(value)
            return value
        except:
            return float(bool(value))
    elif type(value) == tuple:
        return float(value[0])
    elif type(value) == list:
        return float(len(value))
    elif not type(value) in [float, int, bool]:
        try:
            value = len(value)
            return float(value)
        except:
            return float(bool(value))
    return float(value)

def sn_cast_int(value):
    return int(sn_cast_float(value))

def sn_cast_boolean_vector(value, size):
    if type(value) in [str, bool, int, float]:
        return_value = []
        for i in range(size):
            return_value.append(bool(value))
        return tuple(return_value)
    elif type(value) == tuple:
        return_value = []
        for i in range(size):
            return_value.append(bool(value[i]) if len(value) > i else bool(value[0]))
        return tuple(return_value)
    elif type(value) == list:
        return sn_cast_boolean_vector(tuple(value), size)
    else:
        try:
            value = tuple(value)
            return sn_cast_boolean_vector(value, size)
        except:
            return sn_cast_boolean_vector(bool(value), size)

def sn_cast_float_vector(value, size):
    if type(value) in [str, bool, int, float]:
        return_value = []
        for i in range(size):
            return_value.append(sn_cast_float(value))
        return tuple(return_value)
    elif type(value) == tuple:
        return_value = []
        for i in range(size):
            return_value.append(sn_cast_float(value[i]) if len(value) > i else sn_cast_float(value[0]))
        return tuple(return_value)
    elif type(value) == list:
        return sn_cast_float_vector(tuple(value), size)
    else:
        try:
            value = tuple(value)
            return sn_cast_float_vector(value, size)
        except:
            return sn_cast_float_vector(sn_cast_float(value), size)

def sn_cast_int_vector(value, size):
    return tuple(map(int, sn_cast_float_vector(value, size)))

def sn_cast_color(value, use_alpha):
    length = 4 if use_alpha else 3
    value = sn_cast_float_vector(value, length)
    tuple_list = []
    for data in range(length):
        data = value[data] if len(value) > data else value[0]
        tuple_list.append(sn_cast_float(min(1, max(0, data))))
    return tuple(tuple_list)

def sn_cast_list(value):
    if type(value) in [str, tuple, list]:
        return list(value)
    elif type(value) in [int, float, bool]:
        return [value]
    else:
        try:
            value = list(value)
            return value
        except:
            return [value]

def sn_cast_blend_data(value):
    if hasattr(value, "bl_rna"):
        return value
    elif type(value) in [tuple, bool, int, float, list]:
        return None
    elif type(value) == str:
        try:
            value = eval(value)
            return value
        except:
            return None
    else:
        return None

def sn_cast_enum(string, enum_values):
    for item in enum_values:
        if item[1] == string:
            return item[0]
        elif item[0] == string.upper():
            return item[0]
    return string


###############   IMPERATIVE CODE
#######   Import Material fromClipboard
def sn_handle_script_line_exception(exc, line):
    print("# # # # # # # # SCRIPT LINE ERROR # # # # # # # #")
    print("Line:", line)
    raise exc


#######   FBX_BatchImport
def cleanimport():
    try:
        pass # RemoveUnusedEmptys Script Start
        import bpy
        childless_empties = [e for e in bpy.data.objects
                if e.type.startswith('EMPTY') and not e.children]
        while childless_empties:
            bpy.data.objects.remove(childless_empties.pop())
        FH = bpy.context.scene.flattenhierachie
        if FH:
            bpy.ops.object.select_all(action='DESELECT')
            bpy.ops.object.select_by_type(type='EMPTY')
            bpy.ops.object.select_all(action='INVERT')
            bpy.ops.object.parent_clear(type='CLEAR_KEEP_TRANSFORM')
            bpy.ops.object.select_by_type(type='EMPTY')
            bpy.ops.object.delete(use_global=False)
        pass # RemoveUnusedEmptys Script End
        function_return_D4DCB = setemptyssize()
        snippet_return_230A5 = new_linked_collection_snippet_230A5(True, bpy.context.scene.name, r"", )
        snippet_return_689B6 = new_linked_collection_snippet_689B6(True, (bpy.context.scene.name + r"_Meshes"), bpy.context.scene.name, )
        for_node_38E3C = 0
        for_node_index_38E3C = 0
        for for_node_index_38E3C, for_node_38E3C in enumerate(bpy.data.objects):
            snippet_return_3FDA4 = move_to_collection_snippet_3FDA4(for_node_38E3C, (bpy.context.scene.name + r"_Meshes"), )
        bpy.ops.sna.dummy_setmain('INVOKE_DEFAULT' if True else 'EXEC_DEFAULT',)
        bpy.context.scene.importpost = False
    except Exception as exc:
        print(str(exc) + " | Error in function CleanImport")

def set_object_active(active_object, ):
    try:
        bpy.context.view_layer.objects.active=active_object
    except Exception as exc:
        print(str(exc) + " | Error in function Set Object Active")
snippet_vars_A9335 = {}

def set_object_active_snippet_B533D(active_object, ):
    try:
        bpy.context.view_layer.objects.active=active_object
    except Exception as exc:
        print(str(exc) + " | Error in function Set Object Active")

def setemptyssize():
    try:
        for_node_F8878 = 0
        for_node_index_F8878 = 0
        for for_node_index_F8878, for_node_F8878 in enumerate(bpy.data.objects):
            if for_node_F8878.type=="EMPTY":
                snippet_return_B533D = set_object_active_snippet_B533D(for_node_F8878, )
                for_node_F8878.empty_display_size = 0.009999999776482582
                bpy.context.area.spaces[0].overlay.show_relationship_lines = False
            else:
                pass
    except Exception as exc:
        print(str(exc) + " | Error in function SetEmptysSize")

def move_to_collection_snippet_3FDA4(objects, collection, ):
    try:
        run_function_on_23BB4 = sn_cast_blend_data(bpy.data.collections[sn_cast_string(collection)].objects).link(object=sn_cast_blend_data(objects), )
        for_node_A588D = 0
        for_node_index_A588D = 0
        for for_node_index_A588D, for_node_A588D in enumerate(bpy.data.collections):
            if for_node_A588D.name != collection:
                if for_node_A588D.objects.find(sn_cast_blend_data(objects).name) != -1:
                    run_function_on_66A6D = for_node_A588D.objects.unlink(object=sn_cast_blend_data(objects), )
                else:
                    pass
            else:
                pass
        if bpy.context.scene.collection.objects.find(sn_cast_blend_data(objects).name) != -1:
            run_function_on_63DDA = bpy.context.scene.collection.objects.unlink(object=sn_cast_blend_data(objects), )
        else:
            pass
    except Exception as exc:
        print(str(exc) + " | Error in function Move to Collection")

def new_linked_collection_snippet_689B6(allow_multiple_of_same_name, new_collection_default__collection, link_to_collection_defualt__scene, ):
    try:
        pass # AuthorAndLegal.py Script Start
        #region INFO
        '''
            == New Linked Collection Snippet ==
            Authored and Managed by Shawn Blanch (blanchsb)
            ---
            The file can also be re-packaged with
            any other addon, so long as the developer respects the limitations of
            the GPL license, outlined below.
        '''
        '''
            This program is free software: you can redistribute it and/or modify
            it under the terms of the GNU General Public License as published by
            the Free Software Foundation, either version 3 of the License, or
            (at your option) any later version.
            This program is distributed in the hope that it will be useful,
            but WITHOUT ANY WARRANTY; without even the implied warranty of
            MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
            GNU General Public License for more details.
            You should have received a copy of the GNU General Public License
            along with this program.  If not, see <http://www.gnu.org/licenses/>.
        '''
        pass # AuthorAndLegal.py Script End
        if (not allow_multiple_of_same_name and bpy.data.collections.find(sn_cast_string(new_collection_default__collection)) != -1):
            pass
        else:
            if sn_cast_boolean(new_collection_default__collection):
                run_function_on_7CC21 = bpy.data.collections.new(name=sn_cast_string(new_collection_default__collection), )
                if sn_cast_boolean(link_to_collection_defualt__scene):
                    if (bpy.data.collections.find(sn_cast_string(link_to_collection_defualt__scene)) != -1 and bpy.data.collections[sn_cast_string(link_to_collection_defualt__scene)] != run_function_on_7CC21):
                        run_function_on_603D5 = bpy.data.collections[sn_cast_string(link_to_collection_defualt__scene)].children.link(child=sn_cast_blend_data(run_function_on_7CC21), )
                    else:
                        sn_print("New Linked Collection",(r"Tried to Move new Collection: " + sn_cast_blend_data(run_function_on_7CC21).name + r" to Named Colleciton: " + sn_cast_string(link_to_collection_defualt__scene) + r" but there was an error." + r" You are either trying to link the Collection within itself, or the Collection: " + sn_cast_blend_data(run_function_on_7CC21).name + r" you are trying to move to does not exist."))
                else:
                    run_function_on_58949 = bpy.context.scene.collection.children.link(child=sn_cast_blend_data(run_function_on_7CC21), )
            else:
                run_function_on_4042B = bpy.data.collections.new(name=r"Collection", )
                if sn_cast_boolean(link_to_collection_defualt__scene):
                    if (bpy.data.collections.find(sn_cast_string(link_to_collection_defualt__scene)) != -1 and bpy.data.collections[sn_cast_string(link_to_collection_defualt__scene)] != run_function_on_4042B):
                        run_function_on_81898 = bpy.data.collections[sn_cast_string(link_to_collection_defualt__scene)].children.link(child=sn_cast_blend_data(run_function_on_4042B), )
                    else:
                        sn_print("New Linked Collection",(r"Tried to Move new Collection: " + sn_cast_blend_data(run_function_on_4042B).name + r" to Named Colleciton: " + sn_cast_string(link_to_collection_defualt__scene) + r" but there was an error." + r" You are either trying to link the Collection within itself, or the Collection: " + sn_cast_blend_data(run_function_on_4042B).name + r" you are trying to move to does not exist."))
                else:
                    run_function_on_00C8B = bpy.context.scene.collection.children.link(child=sn_cast_blend_data(run_function_on_4042B), )
    except Exception as exc:
        print(str(exc) + " | Error in function New Linked Collection")

def new_linked_collection_snippet_230A5(allow_multiple_of_same_name, new_collection_default__collection, link_to_collection_defualt__scene, ):
    try:
        pass # AuthorAndLegal.py Script Start
        #region INFO
        '''
            == New Linked Collection Snippet ==
            Authored and Managed by Shawn Blanch (blanchsb)
            ---
            The file can also be re-packaged with
            any other addon, so long as the developer respects the limitations of
            the GPL license, outlined below.
        '''
        '''
            This program is free software: you can redistribute it and/or modify
            it under the terms of the GNU General Public License as published by
            the Free Software Foundation, either version 3 of the License, or
            (at your option) any later version.
            This program is distributed in the hope that it will be useful,
            but WITHOUT ANY WARRANTY; without even the implied warranty of
            MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
            GNU General Public License for more details.
            You should have received a copy of the GNU General Public License
            along with this program.  If not, see <http://www.gnu.org/licenses/>.
        '''
        pass # AuthorAndLegal.py Script End
        if (not allow_multiple_of_same_name and bpy.data.collections.find(sn_cast_string(new_collection_default__collection)) != -1):
            pass
        else:
            if sn_cast_boolean(new_collection_default__collection):
                run_function_on_7CC21 = bpy.data.collections.new(name=sn_cast_string(new_collection_default__collection), )
                if sn_cast_boolean(link_to_collection_defualt__scene):
                    if (bpy.data.collections.find(sn_cast_string(link_to_collection_defualt__scene)) != -1 and bpy.data.collections[sn_cast_string(link_to_collection_defualt__scene)] != run_function_on_7CC21):
                        run_function_on_603D5 = bpy.data.collections[sn_cast_string(link_to_collection_defualt__scene)].children.link(child=sn_cast_blend_data(run_function_on_7CC21), )
                    else:
                        sn_print("New Linked Collection",(r"Tried to Move new Collection: " + sn_cast_blend_data(run_function_on_7CC21).name + r" to Named Colleciton: " + sn_cast_string(link_to_collection_defualt__scene) + r" but there was an error." + r" You are either trying to link the Collection within itself, or the Collection: " + sn_cast_blend_data(run_function_on_7CC21).name + r" you are trying to move to does not exist."))
                else:
                    run_function_on_58949 = bpy.context.scene.collection.children.link(child=sn_cast_blend_data(run_function_on_7CC21), )
            else:
                run_function_on_4042B = bpy.data.collections.new(name=r"Collection", )
                if sn_cast_boolean(link_to_collection_defualt__scene):
                    if (bpy.data.collections.find(sn_cast_string(link_to_collection_defualt__scene)) != -1 and bpy.data.collections[sn_cast_string(link_to_collection_defualt__scene)] != run_function_on_4042B):
                        run_function_on_81898 = bpy.data.collections[sn_cast_string(link_to_collection_defualt__scene)].children.link(child=sn_cast_blend_data(run_function_on_4042B), )
                    else:
                        sn_print("New Linked Collection",(r"Tried to Move new Collection: " + sn_cast_blend_data(run_function_on_4042B).name + r" to Named Colleciton: " + sn_cast_string(link_to_collection_defualt__scene) + r" but there was an error." + r" You are either trying to link the Collection within itself, or the Collection: " + sn_cast_blend_data(run_function_on_4042B).name + r" you are trying to move to does not exist."))
                else:
                    run_function_on_00C8B = bpy.context.scene.collection.children.link(child=sn_cast_blend_data(run_function_on_4042B), )
    except Exception as exc:
        print(str(exc) + " | Error in function New Linked Collection")


#######   Clean DupliMaterials
def sn_handle_script_line_exception(exc, line):
    print("# # # # # # # # SCRIPT LINE ERROR # # # # # # # #")
    print("Line:", line)
    raise exc


#######   FixImportedMeshes
def has_parent(parent, ):
    try:
        run_function_on_99294 = parent.select_set(state=True, view_layer=None, )
        bpy.context.view_layer.objects.active=parent
        bpy.ops.object.parent_set('INVOKE_DEFAULT' if True else 'EXEC_DEFAULT',type=sn_cast_enum(r"OBJECT", [("OBJECT","Object",""),("ARMATURE","Armature Deform",""),("ARMATURE_NAME","   With Empty Groups",""),("ARMATURE_AUTO","   With Automatic Weights",""),("ARMATURE_ENVELOPE","   With Envelope Weights",""),("BONE","Bone",""),("BONE_RELATIVE","Bone Relative",""),("CURVE","Curve Deform",""),("FOLLOW","Follow Path",""),("PATH_CONST","Path Constraint",""),("LATTICE","Lattice Deform",""),("VERTEX","Vertex",""),("VERTEX_TRI","Vertex (Triangle)",""),]),xmirror=False,keep_transform=True,)
        run_function_on_B8A2B = parent.select_set(state=False, view_layer=None, )
    except Exception as exc:
        print(str(exc) + " | Error in function Has Parent")

def has_children(children, ):
    try:
        for_node_2D7C1 = 0
        for_node_index_2D7C1 = 0
        for for_node_index_2D7C1, for_node_2D7C1 in enumerate(children):
            bpy.ops.object.parent_clear('INVOKE_DEFAULT' if True else 'EXEC_DEFAULT',type=sn_cast_enum(r"CLEAR_KEEP_TRANSFORM", [("CLEAR","Clear Parent","Completely clear the parenting relationship, including involved modifiers if any"),("CLEAR_KEEP_TRANSFORM","Clear and Keep Transformation","As 'Clear Parent', but keep the current visual transformations of the object"),("CLEAR_INVERSE","Clear Parent Inverse","Reset the transform corrections applied to the parenting relationship, does not remove parenting itself"),]),)
            run_function_on_9A140 = sn_cast_blend_data(for_node_2D7C1).select_set(state=True, view_layer=None, )
        run_function_on_65F19 = fiximportedmeshes["temp_obj"].select_set(state=True, view_layer=None, )
        bpy.context.view_layer.objects.active=fiximportedmeshes["temp_obj"]
        bpy.ops.object.parent_set('INVOKE_DEFAULT' if True else 'EXEC_DEFAULT',type=sn_cast_enum(r"OBJECT", [("OBJECT","Object",""),("ARMATURE","Armature Deform",""),("ARMATURE_NAME","   With Empty Groups",""),("ARMATURE_AUTO","   With Automatic Weights",""),("ARMATURE_ENVELOPE","   With Envelope Weights",""),("BONE","Bone",""),("BONE_RELATIVE","Bone Relative",""),("CURVE","Curve Deform",""),("FOLLOW","Follow Path",""),("PATH_CONST","Path Constraint",""),("LATTICE","Lattice Deform",""),("VERTEX","Vertex",""),("VERTEX_TRI","Vertex (Triangle)",""),]),xmirror=False,keep_transform=True,)
        for_node_0EDA7 = 0
        for_node_index_0EDA7 = 0
        for for_node_index_0EDA7, for_node_0EDA7 in enumerate(children):
            run_function_on_89CCC = sn_cast_blend_data(for_node_0EDA7).select_set(state=False, view_layer=None, )
    except Exception as exc:
        print(str(exc) + " | Error in function Has Children")

def sn_handle_script_line_exception(exc, line):
    print("# # # # # # # # SCRIPT LINE ERROR # # # # # # # #")
    print("Line:", line)
    raise exc

def move_to_collection_snippet_669C0(objects, collection, ):
    try:
        run_function_on_23BB4 = sn_cast_blend_data(bpy.data.collections[sn_cast_string(collection)].objects).link(object=sn_cast_blend_data(objects), )
        for_node_A588D = 0
        for_node_index_A588D = 0
        for for_node_index_A588D, for_node_A588D in enumerate(bpy.data.collections):
            if for_node_A588D.name != collection:
                if for_node_A588D.objects.find(sn_cast_blend_data(objects).name) != -1:
                    run_function_on_66A6D = for_node_A588D.objects.unlink(object=sn_cast_blend_data(objects), )
                else:
                    pass
            else:
                pass
        if bpy.context.scene.collection.objects.find(sn_cast_blend_data(objects).name) != -1:
            run_function_on_63DDA = bpy.context.scene.collection.objects.unlink(object=sn_cast_blend_data(objects), )
        else:
            pass
    except Exception as exc:
        print(str(exc) + " | Error in function Move to Collection")


#######   Finalize
def sn_handle_script_line_exception(exc, line):
    print("# # # # # # # # SCRIPT LINE ERROR # # # # # # # #")
    print("Line:", line)
    raise exc


#######   SetHelper
def sn_handle_script_line_exception(exc, line):
    print("# # # # # # # # SCRIPT LINE ERROR # # # # # # # #")
    print("Line:", line)
    raise exc

def move_to_collection_snippet_9E93C(objects, collection, ):
    try:
        run_function_on_23BB4 = sn_cast_blend_data(bpy.data.collections[sn_cast_string(collection)].objects).link(object=sn_cast_blend_data(objects), )
        for_node_A588D = 0
        for_node_index_A588D = 0
        for for_node_index_A588D, for_node_A588D in enumerate(bpy.data.collections):
            if for_node_A588D.name != collection:
                if for_node_A588D.objects.find(sn_cast_blend_data(objects).name) != -1:
                    run_function_on_66A6D = for_node_A588D.objects.unlink(object=sn_cast_blend_data(objects), )
                else:
                    pass
            else:
                pass
        if bpy.context.scene.collection.objects.find(sn_cast_blend_data(objects).name) != -1:
            run_function_on_63DDA = bpy.context.scene.collection.objects.unlink(object=sn_cast_blend_data(objects), )
        else:
            pass
    except Exception as exc:
        print(str(exc) + " | Error in function Move to Collection")

def move_to_collection_snippet_F3462(objects, collection, ):
    try:
        run_function_on_23BB4 = sn_cast_blend_data(bpy.data.collections[sn_cast_string(collection)].objects).link(object=sn_cast_blend_data(objects), )
        for_node_A588D = 0
        for_node_index_A588D = 0
        for for_node_index_A588D, for_node_A588D in enumerate(bpy.data.collections):
            if for_node_A588D.name != collection:
                if for_node_A588D.objects.find(sn_cast_blend_data(objects).name) != -1:
                    run_function_on_66A6D = for_node_A588D.objects.unlink(object=sn_cast_blend_data(objects), )
                else:
                    pass
            else:
                pass
        if bpy.context.scene.collection.objects.find(sn_cast_blend_data(objects).name) != -1:
            run_function_on_63DDA = bpy.context.scene.collection.objects.unlink(object=sn_cast_blend_data(objects), )
        else:
            pass
    except Exception as exc:
        print(str(exc) + " | Error in function Move to Collection")

def move_to_collection_snippet_B9072(objects, collection, ):
    try:
        run_function_on_23BB4 = sn_cast_blend_data(bpy.data.collections[sn_cast_string(collection)].objects).link(object=sn_cast_blend_data(objects), )
        for_node_A588D = 0
        for_node_index_A588D = 0
        for for_node_index_A588D, for_node_A588D in enumerate(bpy.data.collections):
            if for_node_A588D.name != collection:
                if for_node_A588D.objects.find(sn_cast_blend_data(objects).name) != -1:
                    run_function_on_66A6D = for_node_A588D.objects.unlink(object=sn_cast_blend_data(objects), )
                else:
                    pass
            else:
                pass
        if bpy.context.scene.collection.objects.find(sn_cast_blend_data(objects).name) != -1:
            run_function_on_63DDA = bpy.context.scene.collection.objects.unlink(object=sn_cast_blend_data(objects), )
        else:
            pass
    except Exception as exc:
        print(str(exc) + " | Error in function Move to Collection")

def move_to_collection_snippet_99861(objects, collection, ):
    try:
        run_function_on_23BB4 = sn_cast_blend_data(bpy.data.collections[sn_cast_string(collection)].objects).link(object=sn_cast_blend_data(objects), )
        for_node_A588D = 0
        for_node_index_A588D = 0
        for for_node_index_A588D, for_node_A588D in enumerate(bpy.data.collections):
            if for_node_A588D.name != collection:
                if for_node_A588D.objects.find(sn_cast_blend_data(objects).name) != -1:
                    run_function_on_66A6D = for_node_A588D.objects.unlink(object=sn_cast_blend_data(objects), )
                else:
                    pass
            else:
                pass
        if bpy.context.scene.collection.objects.find(sn_cast_blend_data(objects).name) != -1:
            run_function_on_63DDA = bpy.context.scene.collection.objects.unlink(object=sn_cast_blend_data(objects), )
        else:
            pass
    except Exception as exc:
        print(str(exc) + " | Error in function Move to Collection")

def move_to_collection_snippet_8C0FB(objects, collection, ):
    try:
        run_function_on_23BB4 = sn_cast_blend_data(bpy.data.collections[sn_cast_string(collection)].objects).link(object=sn_cast_blend_data(objects), )
        for_node_A588D = 0
        for_node_index_A588D = 0
        for for_node_index_A588D, for_node_A588D in enumerate(bpy.data.collections):
            if for_node_A588D.name != collection:
                if for_node_A588D.objects.find(sn_cast_blend_data(objects).name) != -1:
                    run_function_on_66A6D = for_node_A588D.objects.unlink(object=sn_cast_blend_data(objects), )
                else:
                    pass
            else:
                pass
        if bpy.context.scene.collection.objects.find(sn_cast_blend_data(objects).name) != -1:
            run_function_on_63DDA = bpy.context.scene.collection.objects.unlink(object=sn_cast_blend_data(objects), )
        else:
            pass
    except Exception as exc:
        print(str(exc) + " | Error in function Move to Collection")


###############   EVALUATED CODE
#######   Agilent - Toolbox
class SNA_AddonPreferences_DCA6B(bpy.types.AddonPreferences):
    bl_idname = 'agilent__toolbox'

    def draw(self, context):
        try:
            layout = self.layout
            box = layout.box()
            box.enabled = True
            box.alert = False
            box.scale_x = 1.0
            box.scale_y = 1.0
            box.label(text=r"Set default values:",icon_value=0)
            row = box.row(align=False)
            row.enabled = True
            row.alert = False
            row.scale_x = 1.0
            row.scale_y = 1.0
            row.prop(sn_cast_blend_data(bpy.context.scene),'batchimport',icon_value=0,text=r"Batch Import",emboss=True,toggle=False,invert_checkbox=False,)
            if sn_cast_blend_data(bpy.context.scene).batchimport:
                col = row.column(align=False)
                col.enabled = True
                col.alert = False
                col.scale_x = 1.75
                col.scale_y = 1.0
                col.prop(sn_cast_blend_data(bpy.context.scene),'matfilepath',icon_value=0,text=r"Default Material File",emboss=True,)
                col.prop(sn_cast_blend_data(bpy.context.scene),'fbxdirpath',icon_value=0,text=r"Default FBX DIr",emboss=True,)
            else:
                pass
        except Exception as exc:
            print(str(exc) + " | Error in addon preferences")


class SNA_PT_Agilent_Toolbox_CB617(bpy.types.Panel):
    bl_label = "Agilent Toolbox"
    bl_idname = "SNA_PT_Agilent_Toolbox_CB617"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = 'Agilent'
    bl_order = 0


    @classmethod
    def poll(cls, context):
        return True

    def draw_header(self, context):
        try:
            layout = self.layout
            layout.label(text=r"",icon_value=bpy.context.scene.agilent__toolbox_icons['SPARK'].icon_id)
        except Exception as exc:
            print(str(exc) + " | Error in Agilent Toolbox panel header")

    def draw(self, context):
        try:
            layout = self.layout
            if sn_cast_blend_data(bpy.context.scene).batchimport:
                box = layout.box()
                box.enabled = True
                box.alert = False
                box.scale_x = 1.0
                box.scale_y = 1.0
                col = box.column(align=True)
                col.enabled = True
                col.alert = False
                col.scale_x = 1.0
                col.scale_y = 1.0
                col.prop(sn_cast_blend_data(bpy.context.scene),'matfilepath',icon_value=0,text=r"MatFilePath",emboss=True,)
                if sn_cast_blend_data(bpy.context.scene).batchimport:
                    col.prop(sn_cast_blend_data(bpy.context.scene),'fbxdirpath',icon_value=0,text=r"FBX File",emboss=True,)
                    op = col.operator("sna.fbxbatchimport",text=r"Run Import",emboss=True,depress=False,icon_value=454)
                    col.separator(factor=1.7799999713897705)
                else:
                    pass
            else:
                pass
            if not sn_cast_blend_data(bpy.context.scene).batchimport:
                box = layout.box()
                box.enabled = True
                box.alert = False
                box.scale_x = 1.0
                box.scale_y = 1.0
                row = box.row(align=True)
                row.enabled = True
                row.alert = not sn_cast_boolean(bpy.context.scene.name)
                row.scale_x = 1.0
                row.scale_y = 1.0
                row.prop(sn_cast_blend_data(bpy.context.scene),'name',icon_value=0,text=r"Set Name",emboss=True,)
                if sn_cast_boolean(bpy.context.scene.name):
                    col = box.column(align=False)
                    col.enabled = True
                    col.alert = False
                    col.scale_x = 1.0
                    col.scale_y = 1.0
                    row = col.row(align=True)
                    row.enabled = True
                    row.alert = False
                    row.scale_x = 1.0
                    row.scale_y = 1.0
                    if bpy.context.preferences.addons.find(r"STEPper") != -1:
                        op = row.operator("sna.importstep",text=r"Import STEP",emboss=True,depress=False,icon_value=314)
                    else:
                        pass
                    op = row.operator("sna.fbxbatchimport",text=r"Import FBX",emboss=True,depress=False,icon_value=290)
                    if sn_cast_blend_data(bpy.context.scene).importpost:
                        row = col.row(align=True)
                        row.enabled = True
                        row.alert = False
                        row.scale_x = 1.0
                        row.scale_y = 1.0
                        op = row.operator("sna.importpost",text=r"Initial Setup",emboss=True,depress=False,icon_value=92)
                        row.prop(sn_cast_blend_data(bpy.context.scene),'flattenhierachie',icon_value=18,text=r"",emboss=True,toggle=True,invert_checkbox=False,)
                    else:
                        pass
                else:
                    pass
            else:
                pass
            if sn_cast_boolean(bpy.context.scene.name):
                box = layout.box()
                box.enabled = True
                box.alert = False
                box.scale_x = 1.0
                box.scale_y = 1.0
                box.label(text=r"Scene Setup",icon_value=0)
                col = box.column(align=True)
                col.enabled = True
                col.alert = False
                col.scale_x = 1.0
                col.scale_y = 1.0
                col.label(text=r"Add Dummys",icon_value=0)
                row = col.row(align=True)
                row.enabled = True
                row.alert = False
                row.scale_x = 1.0
                row.scale_y = 1.0
                op = row.operator("sna.dummy_setmain",text=r"Main",emboss=True,depress=False,icon_value=320)
                op = row.operator("sna.dummy_settop",text=r"Second Top",emboss=True,depress=False,icon_value=318)
                row = col.row(align=True)
                row.enabled = True
                row.alert = False
                row.scale_x = 1.0
                row.scale_y = 1.0
                op = row.operator("sna.dummy_setdoor",text=r"Door",emboss=True,depress=False,icon_value=578)
                op = row.operator("sna.dummy_setsocket",text=r"Socket",emboss=True,depress=False,icon_value=303)
            else:
                pass
            if sn_cast_boolean(bpy.context.scene.name):
                if (bpy.context.active_object.type=="MESH" and sn_cast_boolean(bpy.context.selected_objects)):
                    box = layout.box()
                    box.enabled = True
                    box.alert = False
                    box.scale_x = 1.0
                    box.scale_y = 1.0
                    box.label(text=r"Mesh Tools",icon_value=261)
                    col = box.column(align=True)
                    col.enabled = True
                    col.alert = False
                    col.scale_x = 1.0
                    col.scale_y = 1.0
                    op = col.operator("sna.joinsamematerial",text=r"Join by Material",emboss=True,depress=False,icon_value=280)
                    row = col.row(align=True)
                    row.enabled = True
                    row.alert = False
                    row.scale_x = 1.0
                    row.scale_y = 1.0
                    op = row.operator("sna.fiximportedmeshes",text=r"Fix Shading",emboss=True,depress=False,icon_value=280)
                    row.prop(sn_cast_blend_data(bpy.context.scene),'clearsharp',icon_value=547,text=r"",emboss=True,toggle=True,invert_checkbox=False,)
                    row.prop(sn_cast_blend_data(bpy.context.scene),'clearcustomsplit',icon_value=453,text=r"",emboss=True,toggle=True,invert_checkbox=False,)
                    row.prop(sn_cast_blend_data(bpy.context.scene),'weightednormals',icon_value=484,text=r"",emboss=True,toggle=True,invert_checkbox=False,)
                else:
                    pass
            else:
                pass
            if sn_cast_boolean(bpy.context.scene.name):
                box = layout.box()
                box.enabled = True
                box.alert = False
                box.scale_x = 1.0
                box.scale_y = 1.0
                box.label(text=r"Material Utilitys",icon_value=0)
                col = box.column(align=True)
                col.enabled = True
                col.alert = False
                col.scale_x = 1.0
                col.scale_y = 1.0
                if ((bpy.context.active_object.type=="MESH" and sn_cast_boolean(bpy.context.selected_objects)) and len(sn_cast_list(bpy.context.selected_objects)) == 1):
                    op = col.operator("sna.",text=r"Paste Material",emboss=True,depress=False,icon_value=127)
                else:
                    pass
                if ((bpy.context.active_object.type=="MESH" and sn_cast_boolean(bpy.context.selected_objects)) and len(sn_cast_list(bpy.context.selected_objects)) >= 2):
                    row = col.row(align=True)
                    row.enabled = True
                    row.alert = False
                    row.scale_x = 1.0
                    row.scale_y = 1.0
                    op = row.operator("sna.linkmaterials",text=r"Link Materials",emboss=True,depress=False,icon_value=56)
                    if ((bpy.context.active_object.type=="MESH" and sn_cast_boolean(bpy.context.selected_objects)) and len(sn_cast_list(bpy.context.selected_objects)) == 2):
                        op = row.operator("sna.selectlinked",text=r"Link Instance Materials",emboss=True,depress=False,icon_value=704)
                    else:
                        pass
                else:
                    pass
                row = box.row(align=True)
                row.enabled = True
                row.alert = False
                row.scale_x = 1.0
                row.scale_y = 1.0
                op = row.operator("sna.cleanmaterialslots",text=r"Clean Slots",emboss=True,depress=False,icon_value=627)
                op = row.operator("sna.clean_duplimaterials",text=r"Clean Dupli Mats",emboss=True,depress=False,icon_value=629)
                op = row.operator("sna.clean_up",text=r"",emboss=True,depress=False,icon_value=182)
            else:
                pass
            if sn_cast_boolean(bpy.context.scene.name):
                box = layout.box()
                box.enabled = True
                box.alert = False
                box.scale_x = 1.0
                box.scale_y = 1.0
                box.label(text=r"Pack and Collect textures",icon_value=0)
                col = box.column(align=False)
                col.enabled = True
                col.alert = False
                col.scale_x = 1.0
                col.scale_y = 1.5
                op = col.operator("sna.finalize",text=r"Finalize",emboss=True,depress=False,icon_value=103)
            else:
                pass
        except Exception as exc:
            print(str(exc) + " | Error in Agilent Toolbox panel")


#######   Import Material fromClipboard
class SNA_OT_Selectlinked(bpy.types.Operator):
    bl_idname = "sna.selectlinked"
    bl_label = "SelectLinked"
    bl_description = "Link Material to all instance Materials"
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in execute function of SelectLinked")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            import_material_fromclipboard["selectedobjectslist"] = sn_cast_list(bpy.context.selected_objects)
            import_material_fromclipboard["selectedobjectslist"].remove(bpy.context.active_object)
            import_material_fromclipboard["selectedobject"] = sn_cast_blend_data(import_material_fromclipboard["selectedobjectslist"][0])
            import_material_fromclipboard["activeobject"] = bpy.context.active_object
            try: exec(r"bpy.ops.object.select_all(action='DESELECT')")
            except Exception as exc: sn_handle_script_line_exception(exc, r"bpy.ops.object.select_all(action='DESELECT')")
            run_function_on_78D4A = import_material_fromclipboard["selectedobject"].select_set(state=True, view_layer=None, )
            bpy.context.view_layer.objects.active=import_material_fromclipboard["selectedobject"]
            try: exec(r"bpy.ops.object.select_linked(type='MATERIAL')")
            except Exception as exc: sn_handle_script_line_exception(exc, r"bpy.ops.object.select_linked(type='MATERIAL')")
            run_function_on_1F8E3 = import_material_fromclipboard["activeobject"].select_set(state=True, view_layer=None, )
            bpy.context.view_layer.objects.active=import_material_fromclipboard["activeobject"]
            try: exec(r"bpy.ops.object.make_links_data(type='MATERIAL')")
            except Exception as exc: sn_handle_script_line_exception(exc, r"bpy.ops.object.make_links_data(type='MATERIAL')")
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of SelectLinked")
        return self.execute(context)


class SNA_OT_Linkmaterials(bpy.types.Operator):
    bl_idname = "sna.linkmaterials"
    bl_label = "LinkMaterials"
    bl_description = "Copa Material from active Object to all selected Objects"
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in execute function of LinkMaterials")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            try: exec(r"bpy.ops.object.make_links_data(type='MATERIAL')")
            except Exception as exc: sn_handle_script_line_exception(exc, r"bpy.ops.object.make_links_data(type='MATERIAL')")
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of LinkMaterials")
        return self.execute(context)


class SNA_OT_(bpy.types.Operator):
    bl_idname = "sna."
    bl_label = "ImportMaterial"
    bl_description = "Import the material from the object in the clipboard and apply it to the active object"
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in execute function of ImportMaterial")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            import_material_fromclipboard["activeobjectname"] = bpy.context.active_object.name
            try: exec(r"bpy.ops.view3d.pastebuffer()")
            except Exception as exc: sn_handle_script_line_exception(exc, r"bpy.ops.view3d.pastebuffer()")
            bpy.context.view_layer.objects.active=sn_cast_blend_data(sn_cast_list(bpy.context.selected_objects)[0])
            import_material_fromclipboard["importedmaterialname"] = sn_cast_blend_data(sn_cast_list(bpy.context.active_object.material_slots)[0]).name
            try: exec(r"bpy.ops.object.delete() ")
            except Exception as exc: sn_handle_script_line_exception(exc, r"bpy.ops.object.delete() ")
            run_function_on_3864E = bpy.data.objects[import_material_fromclipboard["activeobjectname"]].select_set(state=True, view_layer=None, )
            bpy.context.view_layer.objects.active=bpy.data.objects[import_material_fromclipboard["activeobjectname"]]
            bpy.context.active_object.active_material=bpy.data.materials[sn_cast_string(import_material_fromclipboard["importedmaterialname"].split(r".")[0])]
            try: exec(r"bpy.ops.outliner.orphans_purge(do_local_ids=True, do_linked_ids=True, do_recursive=True)")
            except Exception as exc: sn_handle_script_line_exception(exc, r"bpy.ops.outliner.orphans_purge(do_local_ids=True, do_linked_ids=True, do_recursive=True)")
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of ImportMaterial")
        return self.execute(context)


#######   FBX_BatchImport
class SNA_OT_Fbxbatchimport(bpy.types.Operator):
    bl_idname = "sna.fbxbatchimport"
    bl_label = "FbxBatchImport"
    bl_description = "Import FBX file"
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in execute function of FbxBatchImport")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            bpy.ops.import_scene.fbx('INVOKE_DEFAULT' if True else 'EXEC_DEFAULT',filepath=r"",directory=r"",filter_glob=r"*.fbx",files=[],ui_tab=sn_cast_enum(r"MAIN", [("MAIN","Main","Main basic settings"),("ARMATURE","Armatures","Armature-related settings"),]),use_manual_orientation=False,global_scale=1.0,bake_space_transform=True,use_custom_normals=True,use_image_search=True,use_alpha_decals=False,decal_offset=0.0,use_anim=False,anim_offset=1.0,use_subsurf=True,use_custom_props=True,use_custom_props_enum_as_string=True,ignore_leaf_bones=False,force_connect_children=False,automatic_bone_orientation=False,primary_bone_axis=sn_cast_enum(r"Y", [("X","X Axis",""),("Y","Y Axis",""),("Z","Z Axis",""),("-X","-X Axis",""),("-Y","-Y Axis",""),("-Z","-Z Axis",""),]),secondary_bone_axis=sn_cast_enum(r"X", [("X","X Axis",""),("Y","Y Axis",""),("Z","Z Axis",""),("-X","-X Axis",""),("-Y","-Y Axis",""),("-Z","-Z Axis",""),]),use_prepost_rot=True,axis_forward=sn_cast_enum(r"-Z", [("X","X Forward",""),("Y","Y Forward",""),("Z","Z Forward",""),("-X","-X Forward",""),("-Y","-Y Forward",""),("-Z","-Z Forward",""),]),axis_up=sn_cast_enum(r"Y", [("X","X Up",""),("Y","Y Up",""),("Z","Z Up",""),("-X","-X Up",""),("-Y","-Y Up",""),("-Z","-Z Up",""),]),)
            bpy.context.scene.importpost = True
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of FbxBatchImport")
        return self.execute(context)


class SNA_OT_Importstep(bpy.types.Operator):
    bl_idname = "sna.importstep"
    bl_label = "ImportStep"
    bl_description = "Import STEP file"
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in execute function of ImportStep")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            bpy.ops.import_scene.occ_import_step('INVOKE_DEFAULT' if True else 'EXEC_DEFAULT',filepath=r"",filter_glob=r"*.step;*.stp;*.st",files=[],override_file=r"",fw_as=sn_cast_enum(r"ZPOS", [("XPOS","X",""),("YPOS","Y",""),("ZPOS","Z",""),]),up_as=sn_cast_enum(r"YPOS", [("XPOS","X",""),("YPOS","Y",""),("ZPOS","Z",""),]),hierarchy_types=sn_cast_enum(r"EMPTIES", [("FLAT","Flat collection",""),("TREE","Tree collection",""),("EMPTIES","Parented empties",""),]),user_scale=0.009999999776482582,lin_deflection=0.800000011920929,ang_deflection=0.5,detail_level=100,custom_scale=False,)
            bpy.context.scene.importpost = True
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of ImportStep")
        return self.execute(context)


class SNA_OT_Importpost(bpy.types.Operator):
    bl_idname = "sna.importpost"
    bl_label = "ImportPost"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in execute function of ImportPost")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            function_return_07950 = cleanimport()
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of ImportPost")
        return self.execute(context)


#######   CleanMaterialSlots
class SNA_OT_Cleanmaterialslots(bpy.types.Operator):
    bl_idname = "sna.cleanmaterialslots"
    bl_label = "CleanMaterialSlots"
    bl_description = "Remove Unused Mat Slots"
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in execute function of CleanMaterialSlots")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            pass # CleanMaterialSlots Script Start
            import bpy
            bpy.ops.object.select_by_type(type='MESH')
            objs = bpy.context.selected_objects
            for obj in objs:
                if obj.type == 'MESH':
                    mesh = obj.data
                    faces = mesh.polygons
                    slots = obj.material_slots
                    # get material index per face
                    face_len = len (faces)
                    used_material_indices = [0 for n in range (face_len)]
                    faces.foreach_get ('material_index', used_material_indices)
                    # one index should only be once in the list
                    used_material_indices = set (used_material_indices)
                    # list unused material slots
                    slot_len = len (slots)
                    all_material_slot_indices = set (n for n in range (slot_len))
                    unused_slot_indices = all_material_slot_indices - used_material_indices
                    # override context's object to obj
                    ctx = bpy.context.copy ()
                    ctx['object'] = obj
                    # delete unused slots
                    unused_slot_indices = list (unused_slot_indices)
                    unused_slot_indices.sort (reverse=True)
                    for slot_index in unused_slot_indices:
                        obj.active_material_index = slot_index
                        bpy.ops.object.material_slot_remove (ctx)
            bpy.ops.object.select_all(action='DESELECT')
            #Cleanup
            bpy.ops.outliner.orphans_purge(do_local_ids=True, do_linked_ids=True, do_recursive=True)
            bpy.ops.outliner.orphans_purge(do_linked_ids=True, do_recursive=True)
            self.report({'INFO'}, "DONE!") 
            pass # CleanMaterialSlots Script End
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of CleanMaterialSlots")
        return self.execute(context)


#######   Clean DupliMaterials
class SNA_OT_Clean_Up(bpy.types.Operator):
    bl_idname = "sna.clean_up"
    bl_label = "Clean Up"
    bl_description = "Remove local and linked Data"
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in execute function of Clean Up")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            try: exec(r"bpy.ops.outliner.orphans_purge(do_local_ids=True, do_linked_ids=True, do_recursive=True)")
            except Exception as exc: sn_handle_script_line_exception(exc, r"bpy.ops.outliner.orphans_purge(do_local_ids=True, do_linked_ids=True, do_recursive=True)")
            try: exec(r"bpy.ops.outliner.orphans_purge(do_linked_ids=True, do_recursive=True)")
            except Exception as exc: sn_handle_script_line_exception(exc, r"bpy.ops.outliner.orphans_purge(do_linked_ids=True, do_recursive=True)")
            try: exec(r"self.report({'INFO'}, 'CLEANED!')")
            except Exception as exc: sn_handle_script_line_exception(exc, r"self.report({'INFO'}, 'CLEANED!')")
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of Clean Up")
        return self.execute(context)


class SNA_OT_Clean_Duplimaterials(bpy.types.Operator):
    bl_idname = "sna.clean_duplimaterials"
    bl_label = "Clean DupliMaterials"
    bl_description = "Remove Duplicated Materials"
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in execute function of Clean DupliMaterials")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            pass # Clean DupliMaterials Script Start
            import bpy
            props = self.properties
            scene = context.scene 

            def replace_material(bad_mat, good_mat):
                bad_mat.user_remap(good_mat)
                bpy.data.materials.remove(bad_mat)

            def get_duplicate_materials(og_material):
                common_name = og_material.name
                if common_name[-3:].isnumeric():
                    common_name = common_name[:-4]
                duplicate_materials = []
                for material in bpy.data.materials:
                    if material is not og_material:
                        name = material.name
                        if name[-3:].isnumeric() and name[-4] == ".":
                            name = name[:-4]
                        if name == common_name:
                            duplicate_materials.append(material)
                text = "{} duplicate materials found"
                print(text.format(len(duplicate_materials)))
                return duplicate_materials

            def remove_all_duplicate_materials():
                i = 0
                while i < len(bpy.data.materials):
                    og_material = bpy.data.materials[i]
                    print("og material: " + og_material.name)
                    # get duplicate materials
                    duplicate_materials = get_duplicate_materials(og_material)
                    # replace all duplicates
                    for duplicate_material in duplicate_materials:
                        replace_material(duplicate_material, og_material)
                    # adjust name to no trailing numbers
                    if og_material.name[-3:].isnumeric() and og_material.name[-4] == ".":
                        og_material.name = og_material.name[:-4]
                    i = i+1
            remove_all_duplicate_materials()

            def replace_material(bad_mat, good_mat):
                bad_mat.user_remap(good_mat)
                bpy.data.materials.remove(bad_mat)

            def get_duplicate_materials(og_material):
                common_name = og_material.name
                if common_name[-3:].isnumeric():
                    common_name = common_name[:-4]
                duplicate_materials = []
                for material in bpy.data.materials:
                    if material is not og_material:
                        name = material.name
                        if name[-3:].isnumeric() and name[-4] == ".":
                            name = name[:-4]
                        if name == common_name:
                            duplicate_materials.append(material)
                text = "{} duplicate materials found"
                print(text.format(len(duplicate_materials)))
                return duplicate_materials

            def remove_all_duplicate_materials():
                i = 0
                while i < len(bpy.data.materials):
                    og_material = bpy.data.materials[i]
                    print("og material: " + og_material.name)
                    # get duplicate materials
                    duplicate_materials = get_duplicate_materials(og_material)
                    # replace all duplicates
                    for duplicate_material in duplicate_materials:
                        replace_material(duplicate_material, og_material)
                    # adjust name to no trailing numbers
                    if og_material.name[-3:].isnumeric() and og_material.name[-4] == ".":
                        og_material.name = og_material.name[:-4]
                    i = i+1
            remove_all_duplicate_materials()
            bpy.ops.outliner.orphans_purge(do_local_ids=True, do_linked_ids=True, do_recursive=True)
            self.report({'INFO'}, "DONE!")
            pass # Clean DupliMaterials Script End
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of Clean DupliMaterials")
        return self.execute(context)


#######   FixImportedMeshes
class SNA_OT_Joinsamematerial(bpy.types.Operator):
    bl_idname = "sna.joinsamematerial"
    bl_label = "JoinSameMaterial"
    bl_description = "Join objects with the same material"
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in execute function of JoinSameMaterial")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            try: exec(r"bpy.ops.object.select_linked(type='MATERIAL')")
            except Exception as exc: sn_handle_script_line_exception(exc, r"bpy.ops.object.select_linked(type='MATERIAL')")
            try: exec(r"bpy.ops.object.join()")
            except Exception as exc: sn_handle_script_line_exception(exc, r"bpy.ops.object.join()")
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of JoinSameMaterial")
        return self.execute(context)


class SNA_OT_Fiximportedmeshes(bpy.types.Operator):
    bl_idname = "sna.fiximportedmeshes"
    bl_label = "FixImportedMeshes"
    bl_description = "Clear shading from selected objects"
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in execute function of FixImportedMeshes")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            for_node_8F006 = 0
            for_node_index_8F006 = 0
            for for_node_index_8F006, for_node_8F006 in enumerate(bpy.context.selected_objects):
                if for_node_8F006.type=="MESH":
                    fiximportedmeshes["originalobj_name"] = sn_cast_blend_data(for_node_8F006).name
                    bpy.ops.mesh.primitive_plane_add('INVOKE_DEFAULT' if True else 'EXEC_DEFAULT',size=1.0,calc_uvs=True,enter_editmode=True,align=sn_cast_enum(r"WORLD", [("WORLD","World","Align the new object to the world"),("VIEW","View","Align the new object to the view"),("CURSOR","3D Cursor","Use the 3D cursor orientation for the new object"),]),location=sn_cast_blend_data(for_node_8F006).location,rotation=sn_cast_blend_data(for_node_8F006).rotation_euler,scale=sn_cast_blend_data(for_node_8F006).scale,)
                    fiximportedmeshes["temp_obj"] = bpy.context.active_object
                    bpy.context.active_object.data.use_auto_smooth = True
                    bpy.context.active_object.data.auto_smooth_angle = math.radians(60.0)
                    bpy.ops.mesh.delete('INVOKE_DEFAULT' if True else 'EXEC_DEFAULT',type=sn_cast_enum(r"VERT", [("VERT","Vertices",""),("EDGE","Edges",""),("FACE","Faces",""),("EDGE_FACE","Only Edges & Faces",""),("ONLY_FACE","Only Faces",""),]),)
                    bpy.ops.object.editmode_toggle('INVOKE_DEFAULT' if True else 'EXEC_DEFAULT',)
                    snippet_return_669C0 = move_to_collection_snippet_669C0(bpy.context.active_object, sn_cast_blend_data(sn_cast_list(getattr(bpy.data.objects[fiximportedmeshes["originalobj_name"]],r"users_collection"))[0]).name, )
                    fiximportedmeshes["tempchildren"] = sn_cast_list(getattr(sn_cast_blend_data(for_node_8F006),r"children"))
                    if len(fiximportedmeshes["tempchildren"]) == 0:
                        pass
                    else:
                        function_return_CD4FB = has_children(fiximportedmeshes["tempchildren"], )
                    if sn_cast_blend_data(getattr(sn_cast_blend_data(for_node_8F006),r"parent")) == None:
                        pass
                    else:
                        function_return_BEDB4 = has_parent(sn_cast_blend_data(getattr(sn_cast_blend_data(for_node_8F006),r"parent")), )
                    run_function_on_C215E = sn_cast_blend_data(for_node_8F006).select_set(state=True, view_layer=None, )
                    bpy.context.view_layer.objects.active=sn_cast_blend_data(for_node_8F006)
                    bpy.ops.object.make_links_data('INVOKE_DEFAULT' if True else 'EXEC_DEFAULT',type=sn_cast_enum(r"MATERIAL", [("OBDATA","Link Object Data","Replace assigned Object Data"),("MATERIAL","Link Materials","Replace assigned Materials"),("ANIMATION","Link Animation Data","Replace assigned Animation Data"),("GROUPS","Link Collections","Replace assigned Collections"),("DUPLICOLLECTION","Link Instance Collection","Replace assigned Collection Instance"),("FONTS","Link Fonts to Text","Replace Text object Fonts"),("MODIFIERS","Copy Modifiers","Replace Modifiers"),("EFFECTS","Copy Grease Pencil Effects","Replace Grease Pencil Effects"),]),)
                    bpy.context.view_layer.objects.active=fiximportedmeshes["temp_obj"]
                    bpy.ops.object.join('INVOKE_DEFAULT' if True else 'EXEC_DEFAULT',)
                    if bpy.context.scene.clearcustomsplit:
                        bpy.ops.mesh.customdata_custom_splitnormals_clear('INVOKE_DEFAULT' if True else 'EXEC_DEFAULT',)
                    else:
                        pass
                    if bpy.context.scene.clearsharp:
                        bpy.ops.object.editmode_toggle('INVOKE_DEFAULT' if True else 'EXEC_DEFAULT',)
                        bpy.ops.mesh.select_all('INVOKE_DEFAULT' if True else 'EXEC_DEFAULT',action=sn_cast_enum(r"SELECT", [("TOGGLE","Toggle","Toggle selection for all elements"),("SELECT","Select","Select all elements"),("DESELECT","Deselect","Deselect all elements"),("INVERT","Invert","Invert selection of all elements"),]),)
                        bpy.ops.mesh.mark_sharp('INVOKE_DEFAULT' if True else 'EXEC_DEFAULT',clear=True,)
                        bpy.ops.mesh.select_all('INVOKE_DEFAULT' if True else 'EXEC_DEFAULT',action=sn_cast_enum(r"DESELECT", [("TOGGLE","Toggle","Toggle selection for all elements"),("SELECT","Select","Select all elements"),("DESELECT","Deselect","Deselect all elements"),("INVERT","Invert","Invert selection of all elements"),]),)
                        bpy.ops.object.editmode_toggle('INVOKE_DEFAULT' if True else 'EXEC_DEFAULT',)
                    else:
                        pass
                    if bpy.context.scene.weightednormals:
                        run_function_on_E2E4B = bpy.context.active_object.modifiers.new(name=r"Name", type=sn_cast_enum(r"WEIGHTED_NORMAL", [("DATA_TRANSFER","Data Transfer","Transfer several types of data (vertex groups, UV maps, vertex colors, custom normals) from one mesh to another"),("MESH_CACHE","Mesh Cache","Deform the mesh using an external frame-by-frame vertex transform cache"),("MESH_SEQUENCE_CACHE","Mesh Sequence Cache","Deform the mesh or curve using an external mesh cache in Alembic format"),("NORMAL_EDIT","Normal Edit","Modify the direction of the surface normals"),("WEIGHTED_NORMAL","Weighted Normal","Modify the direction of the surface normals using a weighting method"),("UV_PROJECT","UV Project","Project the UV map coordinates from the negative Z axis of another object"),("UV_WARP","UV Warp","Transform the UV map using the difference between two objects"),("VERTEX_WEIGHT_EDIT","Vertex Weight Edit","Modify of the weights of a vertex group"),("VERTEX_WEIGHT_MIX","Vertex Weight Mix","Mix the weights of two vertex groups"),("VERTEX_WEIGHT_PROXIMITY","Vertex Weight Proximity","Set the vertex group weights based on the distance to another target object"),("ARRAY","Array","Create copies of the shape with offsets"),("BEVEL","Bevel","Generate sloped corners by adding geometry to the mesh's edges or vertices"),("BOOLEAN","Boolean","Use another shape to cut, combine or perform a difference operation"),("BUILD","Build","Cause the faces of the mesh object to appear or disappear one after the other over time"),("DECIMATE","Decimate","Reduce the geometry density"),("EDGE_SPLIT","Edge Split","Split away joined faces at the edges"),("NODES","Geometry Nodes",""),("MASK","Mask","Dynamically hide vertices based on a vertex group or armature"),("MIRROR","Mirror","Mirror along the local X, Y and/or Z axes, over the object origin"),("MESH_TO_VOLUME","Mesh to Volume",""),("MULTIRES","Multiresolution","Subdivide the mesh in a way that allows editing the higher subdivision levels"),("REMESH","Remesh","Generate new mesh topology based on the current shape"),("SCREW","Screw","Lathe around an axis, treating the input mesh as a profile"),("SKIN","Skin","Create a solid shape from vertices and edges, using the vertex radius to define the thickness"),("SOLIDIFY","Solidify","Make the surface thick"),("SUBSURF","Subdivision Surface","Split the faces into smaller parts, giving it a smoother appearance"),("TRIANGULATE","Triangulate","Convert all polygons to triangles"),("VOLUME_TO_MESH","Volume to Mesh",""),("WELD","Weld","Find groups of vertices closer than dist and merge them together"),("WIREFRAME","Wireframe","Convert faces into thickened edges"),("ARMATURE","Armature","Deform the shape using an armature object"),("CAST","Cast","Shift the shape towards a predefined primitive"),("CURVE","Curve","Bend the mesh using a curve object"),("DISPLACE","Displace","Offset vertices based on a texture"),("HOOK","Hook","Deform specific points using another object"),("LAPLACIANDEFORM","Laplacian Deform","Deform based a series of anchor points"),("LATTICE","Lattice","Deform using the shape of a lattice object"),("MESH_DEFORM","Mesh Deform","Deform using a different mesh, which acts as a deformation cage"),("SHRINKWRAP","Shrinkwrap","Project the shape onto another object"),("SIMPLE_DEFORM","Simple Deform","Deform the shape by twisting, bending, tapering or stretching"),("SMOOTH","Smooth","Smooth the mesh by flattening the angles between adjacent faces"),("CORRECTIVE_SMOOTH","Smooth Corrective","Smooth the mesh while still preserving the volume"),("LAPLACIANSMOOTH","Smooth Laplacian","Reduce the noise on a mesh surface with minimal changes to its shape"),("SURFACE_DEFORM","Surface Deform","Transfer motion from another mesh"),("WARP","Warp","Warp parts of a mesh to a new location in a very flexible way thanks to 2 specified objects"),("WAVE","Wave","Adds a ripple-like motion to an object's geometry"),("VOLUME_DISPLACE","Volume Displace","Deform volume based on noise or other vector fields"),("CLOTH","Cloth",""),("COLLISION","Collision",""),("DYNAMIC_PAINT","Dynamic Paint",""),("EXPLODE","Explode","Break apart the mesh faces and let them follow particles"),("FLUID","Fluid",""),("OCEAN","Ocean","Generate a moving ocean surface"),("PARTICLE_INSTANCE","Particle Instance",""),("PARTICLE_SYSTEM","Particle System","Spawn particles from the shape"),("SOFT_BODY","Soft Body",""),("SURFACE","Surface",""),]), )
                        run_function_on_E2E4B.keep_sharp = True
                    else:
                        pass
                    fiximportedmeshes["temp_obj"].name=fiximportedmeshes["originalobj_name"]
                    try: exec(r"bpy.ops.object.shade_smooth()")
                    except Exception as exc: sn_handle_script_line_exception(exc, r"bpy.ops.object.shade_smooth()")
                    print(r"Fixed: ", fiximportedmeshes["originalobj_name"])
                else:
                    pass
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of FixImportedMeshes")
        return self.execute(context)


#######   Finalize
class SNA_OT_Packtoblend(bpy.types.Operator):
    bl_idname = "sna.packtoblend"
    bl_label = "PackToBlend"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in execute function of PackToBlend")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            if bpy.context.scene.ispacktoblend:
                pass
            else:
                bpy.context.scene.ispacktoblend = True
                print(sn_cast_string(bpy.context.scene.ispacktoblend))
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of PackToBlend")
        return self.execute(context)


class SNA_OT_Packtotexturefolder(bpy.types.Operator):
    bl_idname = "sna.packtotexturefolder"
    bl_label = "PackToTextureFolder"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in execute function of PackToTextureFolder")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            if bpy.context.scene.ispacktoblend:
                bpy.context.scene.ispacktoblend = False
                print(sn_cast_string(bpy.context.scene.ispacktoblend))
            else:
                pass
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of PackToTextureFolder")
        return self.execute(context)


class SNA_OT_Finalize(bpy.types.Operator):
    bl_idname = "sna.finalize"
    bl_label = "Finalize"
    bl_description = "Collect all Textures and save them to //textures"
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            if bpy.context.scene.ispacktoblend:
                try: exec(r"bpy.ops.file.pack_all()")
                except Exception as exc: sn_handle_script_line_exception(exc, r"bpy.ops.file.pack_all()")
                try: exec(r"self.report({'INFO'}, 'DONE!')")
                except Exception as exc: sn_handle_script_line_exception(exc, r"self.report({'INFO'}, 'DONE!')")
            else:
                try: exec(r"bpy.ops.file.pack_all()")
                except Exception as exc: sn_handle_script_line_exception(exc, r"bpy.ops.file.pack_all()")
                try: exec(r"bpy.ops.file.unpack_all(method='WRITE_LOCAL')")
                except Exception as exc: sn_handle_script_line_exception(exc, r"bpy.ops.file.unpack_all(method='WRITE_LOCAL')")
                try: exec(r"bpy.ops.outliner.orphans_purge(do_local_ids=True, do_linked_ids=True, do_recursive=True)")
                except Exception as exc: sn_handle_script_line_exception(exc, r"bpy.ops.outliner.orphans_purge(do_local_ids=True, do_linked_ids=True, do_recursive=True)")
                try: exec(r"bpy.ops.outliner.orphans_purge(do_linked_ids=True, do_recursive=True)")
                except Exception as exc: sn_handle_script_line_exception(exc, r"bpy.ops.outliner.orphans_purge(do_linked_ids=True, do_recursive=True)")
                try: exec(r"bpy.ops.file.make_paths_relative()")
                except Exception as exc: sn_handle_script_line_exception(exc, r"bpy.ops.file.make_paths_relative()")
                try: exec(r"self.report({'INFO'}, 'DONE!')")
                except Exception as exc: sn_handle_script_line_exception(exc, r"self.report({'INFO'}, 'DONE!')")
        except Exception as exc:
            print(str(exc) + " | Error in execute function of Finalize")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of Finalize")
        return context.window_manager.invoke_props_dialog(self, width=300)

    def draw(self, context):
        layout = self.layout
        try:
            row = layout.row(align=True)
            row.enabled = True
            row.alert = False
            row.scale_x = 1.0
            row.scale_y = 1.0
            op = row.operator("sna.packtoblend",text=r"Pack to Blend file",emboss=True,depress=bpy.context.scene.ispacktoblend,icon_value=695)
            op = row.operator("sna.packtotexturefolder",text=r"Pack to Texture Folder",emboss=True,depress=not bpy.context.scene.ispacktoblend,icon_value=693)
        except Exception as exc:
            print(str(exc) + " | Error in draw function of Finalize")


#######   SetHelper
class SNA_OT_Dummy_Setmain(bpy.types.Operator):
    bl_idname = "sna.dummy_setmain"
    bl_label = "Dummy_SetMain"
    bl_description = "Create Dummy_SetMain"
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in execute function of Dummy_SetMain")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            bpy.ops.object.empty_add('INVOKE_DEFAULT' if True else 'EXEC_DEFAULT',type=sn_cast_enum(r"ARROWS", [("PLAIN_AXES","Plain Axes",""),("ARROWS","Arrows",""),("SINGLE_ARROW","Single Arrow",""),("CIRCLE","Circle",""),("CUBE","Cube",""),("SPHERE","Sphere",""),("CONE","Cone",""),("IMAGE","Image",""),]),radius=0.05000000074505806,align=sn_cast_enum(r"WORLD", [("WORLD","World","Align the new object to the world"),("VIEW","View","Align the new object to the view"),("CURSOR","3D Cursor","Use the 3D cursor orientation for the new object"),]),location=(0.0, 0.0, 0.0),rotation=(0.0, 0.0, 0.0),scale=(0.0, 0.0, 0.0),)
            bpy.context.active_object.name=(r"Dummy_" + bpy.context.scene.name + r"_Main")
            bpy.context.active_object.parent_bone=r""
            snippet_return_9E93C = move_to_collection_snippet_9E93C(bpy.context.active_object, bpy.context.scene.name, )
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of Dummy_SetMain")
        return self.execute(context)


class SNA_OT_Dummy_Setdoor(bpy.types.Operator):
    bl_idname = "sna.dummy_setdoor"
    bl_label = "Dummy_SetDoor"
    bl_description = "Create Dummy_SetDoor"
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in execute function of Dummy_SetDoor")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            if bpy.context.active_object == None:
                pass
            else:
                if bpy.context.active_object.type=="MESH":
                    if bpy.context.active_object.data.is_editmode:
                        op_reset_context = bpy.context.area.type
                        bpy.context.area.type = 'VIEW_3D'
                        bpy.ops.view3d.snap_cursor_to_selected('INVOKE_DEFAULT' if True else 'EXEC_DEFAULT',)
                        bpy.context.area.type = op_reset_context
                        try: exec(r"bpy.ops.object.mode_set(mode='OBJECT')")
                        except Exception as exc: sn_handle_script_line_exception(exc, r"bpy.ops.object.mode_set(mode='OBJECT')")
                    else:
                        op_reset_context = bpy.context.area.type
                        bpy.context.area.type = 'VIEW_3D'
                        bpy.ops.view3d.snap_cursor_to_selected('INVOKE_DEFAULT' if True else 'EXEC_DEFAULT',)
                        bpy.context.area.type = op_reset_context
                else:
                    op_reset_context = bpy.context.area.type
                    bpy.context.area.type = 'VIEW_3D'
                    bpy.ops.view3d.snap_cursor_to_selected('INVOKE_DEFAULT' if True else 'EXEC_DEFAULT',)
                    bpy.context.area.type = op_reset_context
            bpy.ops.object.empty_add('INVOKE_DEFAULT' if True else 'EXEC_DEFAULT',type=sn_cast_enum(r"SPHERE", [("PLAIN_AXES","Plain Axes",""),("ARROWS","Arrows",""),("SINGLE_ARROW","Single Arrow",""),("CIRCLE","Circle",""),("CUBE","Cube",""),("SPHERE","Sphere",""),("CONE","Cone",""),("IMAGE","Image",""),]),radius=0.05000000074505806,align=sn_cast_enum(r"CURSOR", [("WORLD","World","Align the new object to the world"),("VIEW","View","Align the new object to the view"),("CURSOR","3D Cursor","Use the 3D cursor orientation for the new object"),]),location=(0.0, 0.0, 0.0),rotation=(0.0, 0.0, 0.0),scale=(0.0, 0.0, 0.0),)
            bpy.context.active_object.name=(r"Dummy_" + bpy.context.scene.name + r"_Door")
            bpy.context.active_object.parent_bone=r""
            bpy.ops.view3d.snap_selected_to_cursor('INVOKE_DEFAULT' if True else 'EXEC_DEFAULT',use_offset=False,)
            snippet_return_F3462 = move_to_collection_snippet_F3462(bpy.context.active_object, bpy.context.scene.name, )
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of Dummy_SetDoor")
        return self.execute(context)


class SNA_OT_Dummy_Setsocket(bpy.types.Operator):
    bl_idname = "sna.dummy_setsocket"
    bl_label = "Dummy_SetSocket"
    bl_description = "Create Dummy_SetSocket"
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in execute function of Dummy_SetSocket")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            if bpy.context.active_object == None:
                pass
            else:
                if bpy.context.active_object.type=="MESH":
                    if bpy.context.active_object.data.is_editmode:
                        op_reset_context = bpy.context.area.type
                        bpy.context.area.type = 'VIEW_3D'
                        bpy.ops.view3d.snap_cursor_to_selected('INVOKE_DEFAULT' if True else 'EXEC_DEFAULT',)
                        bpy.context.area.type = op_reset_context
                        try: exec(r"bpy.ops.object.mode_set(mode='OBJECT')")
                        except Exception as exc: sn_handle_script_line_exception(exc, r"bpy.ops.object.mode_set(mode='OBJECT')")
                    else:
                        op_reset_context = bpy.context.area.type
                        bpy.context.area.type = 'VIEW_3D'
                        bpy.ops.view3d.snap_cursor_to_selected('INVOKE_DEFAULT' if True else 'EXEC_DEFAULT',)
                        bpy.context.area.type = op_reset_context
                else:
                    op_reset_context = bpy.context.area.type
                    bpy.context.area.type = 'VIEW_3D'
                    bpy.ops.view3d.snap_cursor_to_selected('INVOKE_DEFAULT' if True else 'EXEC_DEFAULT',)
                    bpy.context.area.type = op_reset_context
            bpy.ops.object.empty_add('INVOKE_DEFAULT' if True else 'EXEC_DEFAULT',type=sn_cast_enum(r"CUBE", [("PLAIN_AXES","Plain Axes",""),("ARROWS","Arrows",""),("SINGLE_ARROW","Single Arrow",""),("CIRCLE","Circle",""),("CUBE","Cube",""),("SPHERE","Sphere",""),("CONE","Cone",""),("IMAGE","Image",""),]),radius=0.019999999552965164,align=sn_cast_enum(r"CURSOR", [("WORLD","World","Align the new object to the world"),("VIEW","View","Align the new object to the view"),("CURSOR","3D Cursor","Use the 3D cursor orientation for the new object"),]),location=(0.0, 0.0, 0.0),rotation=(0.0, 0.0, 0.0),scale=(0.0, 0.0, 0.0),)
            bpy.context.active_object.name=(r"Dummy_" + bpy.context.scene.name + r"_Socket")
            bpy.context.active_object.parent_bone=r""
            bpy.ops.view3d.snap_selected_to_cursor('INVOKE_DEFAULT' if True else 'EXEC_DEFAULT',use_offset=False,)
            snippet_return_B9072 = move_to_collection_snippet_B9072(bpy.context.active_object, bpy.context.scene.name, )
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of Dummy_SetSocket")
        return self.execute(context)


class SNA_OT_Dummy_Settop(bpy.types.Operator):
    bl_idname = "sna.dummy_settop"
    bl_label = "Dummy_SetTop"
    bl_description = "Create Dummy_SetTop"
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in execute function of Dummy_SetTop")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            if bpy.context.active_object.data.is_editmode:
                if bpy.context.active_object == None:
                    pass
                else:
                    if bpy.context.active_object.type=="MESH":
                        op_reset_context = bpy.context.area.type
                        bpy.context.area.type = 'VIEW_3D'
                        bpy.ops.view3d.snap_cursor_to_selected('INVOKE_DEFAULT' if True else 'EXEC_DEFAULT',)
                        bpy.context.area.type = op_reset_context
                        try: exec(r"bpy.ops.object.mode_set(mode='OBJECT')")
                        except Exception as exc: sn_handle_script_line_exception(exc, r"bpy.ops.object.mode_set(mode='OBJECT')")
                    else:
                        op_reset_context = bpy.context.area.type
                        bpy.context.area.type = 'VIEW_3D'
                        bpy.ops.view3d.snap_cursor_to_selected('INVOKE_DEFAULT' if True else 'EXEC_DEFAULT',)
                        bpy.context.area.type = op_reset_context
                bpy.ops.object.empty_add('INVOKE_DEFAULT' if True else 'EXEC_DEFAULT',type=sn_cast_enum(r"PLAIN_AXES", [("PLAIN_AXES","Plain Axes",""),("ARROWS","Arrows",""),("SINGLE_ARROW","Single Arrow",""),("CIRCLE","Circle",""),("CUBE","Cube",""),("SPHERE","Sphere",""),("CONE","Cone",""),("IMAGE","Image",""),]),radius=0.009999999776482582,align=sn_cast_enum(r"CURSOR", [("WORLD","World","Align the new object to the world"),("VIEW","View","Align the new object to the view"),("CURSOR","3D Cursor","Use the 3D cursor orientation for the new object"),]),location=(0.0, 0.0, 0.0),rotation=(0.0, 0.0, 0.0),scale=(0.0, 0.0, 0.0),)
                bpy.context.active_object.name=(r"Dummy_" + bpy.context.scene.name + r"_Second-Top")
                bpy.ops.view3d.snap_selected_to_cursor('INVOKE_DEFAULT' if True else 'EXEC_DEFAULT',use_offset=False,)
                bpy.context.scene.maxz = bpy.context.active_object.location[2]
                bpy.context.active_object.location=(0.0,0.0,bpy.context.scene.maxz,)
                snippet_return_8C0FB = move_to_collection_snippet_8C0FB(bpy.context.active_object, bpy.context.scene.name, )
            else:
                pass # getMaxZ Script Start
                #import bpy
                o  = bpy.context.object  # active object
                mw = o.matrix_world      # Active object's world matrix


                glob_vertex_coordinates = [ mw @ v.co for v in o.data.vertices ] # Global 
                getmaxZ = max( [ co.z for co in glob_vertex_coordinates ] ) 
                bpy.context.scene.maxz = getmaxZ
                pass # getMaxZ Script End
                bpy.ops.object.empty_add('INVOKE_DEFAULT' if True else 'EXEC_DEFAULT',type=sn_cast_enum(r"PLAIN_AXES", [("PLAIN_AXES","Plain Axes",""),("ARROWS","Arrows",""),("SINGLE_ARROW","Single Arrow",""),("CIRCLE","Circle",""),("CUBE","Cube",""),("SPHERE","Sphere",""),("CONE","Cone",""),("IMAGE","Image",""),]),radius=0.009999999776482582,align=sn_cast_enum(r"CURSOR", [("WORLD","World","Align the new object to the world"),("VIEW","View","Align the new object to the view"),("CURSOR","3D Cursor","Use the 3D cursor orientation for the new object"),]),location=(0.0,0.0,(bpy.context.scene.maxz - 0.002489000093191862),),rotation=(0.0, 0.0, 0.0),scale=(0.0, 0.0, 0.0),)
                bpy.context.active_object.name=(r"Dummy_" + bpy.context.scene.name + r"_Second-Top")
                bpy.context.active_object.parent_bone=r""
                snippet_return_99861 = move_to_collection_snippet_99861(bpy.context.active_object, bpy.context.scene.name, )
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of Dummy_SetTop")
        return self.execute(context)


###############   REGISTER ICONS
def sn_register_icons():
    icons = ["STACK","SPARK",]
    bpy.types.Scene.agilent__toolbox_icons = bpy.utils.previews.new()
    icons_dir = os.path.join( os.path.dirname( __file__ ), "icons" )
    for icon in icons:
        bpy.types.Scene.agilent__toolbox_icons.load( icon, os.path.join( icons_dir, icon + ".png" ), 'IMAGE' )

def sn_unregister_icons():
    bpy.utils.previews.remove( bpy.types.Scene.agilent__toolbox_icons )


###############   REGISTER PROPERTIES
def sn_register_properties():
    bpy.types.Scene.fbxdirpath = bpy.props.StringProperty(name='FbxDirPath',description='',subtype='DIR_PATH',options=set(),default='')
    bpy.types.Scene.matfilepath = bpy.props.StringProperty(name='MatFilePath',description='',subtype='FILE_PATH',options=set(),default='C:/Users/EH/Desktop/Agilent/3D_Library/Vorlagen/Materials.blend')
    bpy.types.Scene.ispacktoblend = bpy.props.BoolProperty(name='IsPackToBlend',description='',options=set(),default=False)
    bpy.types.Scene.clearsharp = bpy.props.BoolProperty(name='ClearSharp',description='Clear sharp edges',options=set(),default=True)
    bpy.types.Scene.smoothshading = bpy.props.BoolProperty(name='SmoothShading',description='',options=set(),default=False)
    bpy.types.Scene.clearcustomsplit = bpy.props.BoolProperty(name='ClearCustomSplit',description='Clear custom split and normal data',options=set(),default=True)
    bpy.types.Scene.name = bpy.props.StringProperty(name='Name',description='',subtype='NONE',options=set(),default='')
    bpy.types.Scene.flattenhierachie = bpy.props.BoolProperty(name='FlattenHierachie',description='Flatten Hierarchie',options=set(),default=False)
    bpy.types.Scene.done = bpy.props.BoolProperty(name='Done',description='',options=set(),default=False)
    bpy.types.Scene.weightednormals = bpy.props.BoolProperty(name='WeightedNormals',description='Add weighted Normal Modifier',options=set(),default=True)
    bpy.types.Scene.importpost = bpy.props.BoolProperty(name='ImportPost',description='',options=set(),default=False)
    bpy.types.Scene.batchimport = bpy.props.BoolProperty(name='BatchImport',description='',options=set(),default=False)
    bpy.types.Scene.maxz = bpy.props.FloatProperty(name='maxZ',description='',subtype='NONE',unit='NONE',options=set(),precision=2, default=0.0)

def sn_unregister_properties():
    del bpy.types.Scene.fbxdirpath
    del bpy.types.Scene.matfilepath
    del bpy.types.Scene.ispacktoblend
    del bpy.types.Scene.clearsharp
    del bpy.types.Scene.smoothshading
    del bpy.types.Scene.clearcustomsplit
    del bpy.types.Scene.name
    del bpy.types.Scene.flattenhierachie
    del bpy.types.Scene.done
    del bpy.types.Scene.weightednormals
    del bpy.types.Scene.importpost
    del bpy.types.Scene.batchimport
    del bpy.types.Scene.maxz


###############   REGISTER ADDON
def register():
    sn_register_icons()
    sn_register_properties()
    bpy.utils.register_class(SNA_AddonPreferences_DCA6B)
    bpy.utils.register_class(SNA_PT_Agilent_Toolbox_CB617)
    bpy.utils.register_class(SNA_OT_Selectlinked)
    bpy.utils.register_class(SNA_OT_Linkmaterials)
    bpy.utils.register_class(SNA_OT_)
    bpy.utils.register_class(SNA_OT_Fbxbatchimport)
    bpy.utils.register_class(SNA_OT_Importstep)
    bpy.utils.register_class(SNA_OT_Importpost)
    bpy.utils.register_class(SNA_OT_Cleanmaterialslots)
    bpy.utils.register_class(SNA_OT_Clean_Up)
    bpy.utils.register_class(SNA_OT_Clean_Duplimaterials)
    bpy.utils.register_class(SNA_OT_Joinsamematerial)
    bpy.utils.register_class(SNA_OT_Fiximportedmeshes)
    bpy.utils.register_class(SNA_OT_Packtoblend)
    bpy.utils.register_class(SNA_OT_Packtotexturefolder)
    bpy.utils.register_class(SNA_OT_Finalize)
    bpy.utils.register_class(SNA_OT_Dummy_Setmain)
    bpy.utils.register_class(SNA_OT_Dummy_Setdoor)
    bpy.utils.register_class(SNA_OT_Dummy_Setsocket)
    bpy.utils.register_class(SNA_OT_Dummy_Settop)


###############   UNREGISTER ADDON
def unregister():
    sn_unregister_icons()
    sn_unregister_properties()
    bpy.utils.unregister_class(SNA_OT_Dummy_Settop)
    bpy.utils.unregister_class(SNA_OT_Dummy_Setsocket)
    bpy.utils.unregister_class(SNA_OT_Dummy_Setdoor)
    bpy.utils.unregister_class(SNA_OT_Dummy_Setmain)
    bpy.utils.unregister_class(SNA_OT_Finalize)
    bpy.utils.unregister_class(SNA_OT_Packtotexturefolder)
    bpy.utils.unregister_class(SNA_OT_Packtoblend)
    bpy.utils.unregister_class(SNA_OT_Fiximportedmeshes)
    bpy.utils.unregister_class(SNA_OT_Joinsamematerial)
    bpy.utils.unregister_class(SNA_OT_Clean_Duplimaterials)
    bpy.utils.unregister_class(SNA_OT_Clean_Up)
    bpy.utils.unregister_class(SNA_OT_Cleanmaterialslots)
    bpy.utils.unregister_class(SNA_OT_Importpost)
    bpy.utils.unregister_class(SNA_OT_Importstep)
    bpy.utils.unregister_class(SNA_OT_Fbxbatchimport)
    bpy.utils.unregister_class(SNA_OT_)
    bpy.utils.unregister_class(SNA_OT_Linkmaterials)
    bpy.utils.unregister_class(SNA_OT_Selectlinked)
    bpy.utils.unregister_class(SNA_PT_Agilent_Toolbox_CB617)
    bpy.utils.unregister_class(SNA_AddonPreferences_DCA6B)