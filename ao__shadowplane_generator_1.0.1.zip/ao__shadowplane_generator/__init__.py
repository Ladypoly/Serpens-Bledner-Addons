# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.
#
# This addon was created with the Serpens - Visual Scripting Addon.
# This code is generated from nodes and is not intended for manual editing.
# You can find out more about Serpens at <https://blendermarket.com/products/serpens>.


bl_info = {
    "name": "AO / ShadowPlane generator",
    "description": "",
    "author": "eh",
    "version": (1, 0, 1),
    "blender": (2, 93, 0),
    "location": "Render Settings",
    "warning": "",
    "wiki_url": "",
    "tracker_url": "",
    "category": "Render"
}


###############   IMPORTS
import bpy
from bpy.utils import previews
import os
import math
from bpy.app.handlers import persistent


###############   INITALIZE VARIABLES
ao__shadowplane_generator = {
    "doupliname": "", 
    "ao_plane": None, 
    "sourcename": "", 
    "bakingtexnode": None, 
    "ao_tex": None, 
    "comp_imagenode": None, 
    "isao": True, 
    "material": None, 
    "currentframe": 0, 
    }


###############   SERPENS FUNCTIONS
def exec_line(line):
    exec(line)

def sn_print(tree_name, *args):
    if tree_name in bpy.data.node_groups:
        item = bpy.data.node_groups[tree_name].sn_graphs[0].prints.add()
        for arg in args:
            item.value += str(arg) + ";;;"
        if bpy.context and bpy.context.screen:
            for area in bpy.context.screen.areas:
                area.tag_redraw()
    print(*args)

def sn_cast_string(value):
    return str(value)

def sn_cast_boolean(value):
    if type(value) == tuple:
        for data in value:
            if bool(data):
                return True
        return False
    return bool(value)

def sn_cast_float(value):
    if type(value) == str:
        try:
            value = float(value)
            return value
        except:
            return float(bool(value))
    elif type(value) == tuple:
        return float(value[0])
    elif type(value) == list:
        return float(len(value))
    elif not type(value) in [float, int, bool]:
        try:
            value = len(value)
            return float(value)
        except:
            return float(bool(value))
    return float(value)

def sn_cast_int(value):
    return int(sn_cast_float(value))

def sn_cast_boolean_vector(value, size):
    if type(value) in [str, bool, int, float]:
        return_value = []
        for i in range(size):
            return_value.append(bool(value))
        return tuple(return_value)
    elif type(value) == tuple:
        return_value = []
        for i in range(size):
            return_value.append(bool(value[i]) if len(value) > i else bool(value[0]))
        return tuple(return_value)
    elif type(value) == list:
        return sn_cast_boolean_vector(tuple(value), size)
    else:
        try:
            value = tuple(value)
            return sn_cast_boolean_vector(value, size)
        except:
            return sn_cast_boolean_vector(bool(value), size)

def sn_cast_float_vector(value, size):
    if type(value) in [str, bool, int, float]:
        return_value = []
        for i in range(size):
            return_value.append(sn_cast_float(value))
        return tuple(return_value)
    elif type(value) == tuple:
        return_value = []
        for i in range(size):
            return_value.append(sn_cast_float(value[i]) if len(value) > i else sn_cast_float(value[0]))
        return tuple(return_value)
    elif type(value) == list:
        return sn_cast_float_vector(tuple(value), size)
    else:
        try:
            value = tuple(value)
            return sn_cast_float_vector(value, size)
        except:
            return sn_cast_float_vector(sn_cast_float(value), size)

def sn_cast_int_vector(value, size):
    return tuple(map(int, sn_cast_float_vector(value, size)))

def sn_cast_color(value, use_alpha):
    length = 4 if use_alpha else 3
    value = sn_cast_float_vector(value, length)
    tuple_list = []
    for data in range(length):
        data = value[data] if len(value) > data else value[0]
        tuple_list.append(sn_cast_float(min(1, max(0, data))))
    return tuple(tuple_list)

def sn_cast_list(value):
    if type(value) in [str, tuple, list]:
        return list(value)
    elif type(value) in [int, float, bool]:
        return [value]
    else:
        try:
            value = list(value)
            return value
        except:
            return [value]

def sn_cast_blend_data(value):
    if hasattr(value, "bl_rna"):
        return value
    elif type(value) in [tuple, bool, int, float, list]:
        return None
    elif type(value) == str:
        try:
            value = eval(value)
            return value
        except:
            return None
    else:
        return None

def sn_cast_enum(string, enum_values):
    for item in enum_values:
        if item[1] == string:
            return item[0]
        elif item[0] == string.upper():
            return item[0]
    return string


###############   IMPERATIVE CODE
#######   AO / ShadowPlane generator
def generateplane():
    try:
        ao__shadowplane_generator["sourcename"] = bpy.context.active_object.name
        bpy.ops.object.duplicate_move('INVOKE_DEFAULT' if False else 'EXEC_DEFAULT',OBJECT_OT_duplicate=None,)
        bpy.ops.object.transform_apply('INVOKE_DEFAULT' if True else 'EXEC_DEFAULT',scale=True,properties=True,)
        ao__shadowplane_generator["doupliname"] = bpy.context.active_object.name
        pass # GenerateShadwplane Script Start
        #import bpy
        selected = bpy.context.selected_objects
        for obj in selected:
            #ensure origin is centered on bounding box center
            bpy.ops.object.origin_set(type='ORIGIN_GEOMETRY', center='BOUNDS')
            #create a cube for the bounding box
            bpy.ops.mesh.primitive_plane_add() 
            #our new cube is now the active object, so we can keep track of it in a variable:
            bound_box = bpy.context.active_object 
            #copy transforms
            bound_box.dimensions = obj.dimensions
            #FloorPos = obj.dimensions
            bound_box.location = obj.location
            #bound_box.rotation_euler = obj.rotation_euler
            #bound_box.location[2] = 0
            #bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
            #bpy.ops.transform.resize(value=(2, 2, 2), orient_type='GLOBAL', orient_matrix=((1, 0, 0), (0, 1, 0), (0, 0, 1)), orient_matrix_type='GLOBAL', mirror=True, use_proportional_edit=False, proportional_edit_falloff='SMOOTH', proportional_size=1, use_proportional_connected=False, use_proportional_projected=False)
        pass # GenerateShadwplane Script End
        ao__shadowplane_generator["ao_plane"] = bpy.context.active_object
        bpy.context.active_object.location=(bpy.context.active_object.location[0],bpy.context.active_object.location[1],bpy.context.scene.hight,)
        bpy.context.active_object.name=(ao__shadowplane_generator["sourcename"] + r"_AO-Plane")
        bpy.context.active_object.parent_bone=r""
        bpy.ops.object.transform_apply('INVOKE_DEFAULT' if True else 'EXEC_DEFAULT',location=False,rotation=False,scale=True,properties=True,)
        bpy.ops.transform.resize('INVOKE_DEFAULT' if False else 'EXEC_DEFAULT',value=(bpy.context.scene.sizemultiplier,bpy.context.scene.sizemultiplier,bpy.context.scene.sizemultiplier,),)
        bpy.ops.object.transform_apply('INVOKE_DEFAULT' if True else 'EXEC_DEFAULT',scale=True,properties=True,)
        run_function_on_A7CD5 = bpy.context.active_object.select_set(state=False, view_layer=None, )
        run_function_on_285D2 = bpy.data.objects[ao__shadowplane_generator["doupliname"]].select_set(state=True, view_layer=None, )
        bpy.context.view_layer.objects.active=bpy.data.objects[ao__shadowplane_generator["doupliname"]]
        bpy.ops.object.delete('INVOKE_DEFAULT' if True else 'EXEC_DEFAULT',use_global=True,confirm=False,)
        function_return_4CEE8 = setparent()
        run_function_on_661F7 = ao__shadowplane_generator["ao_plane"].select_set(state=True, view_layer=None, )
        bpy.context.view_layer.objects.active=ao__shadowplane_generator["ao_plane"]
        bpy.context.scene.ao_planematname = (ao__shadowplane_generator["sourcename"] + r"_AO-Plane")
    except Exception as exc:
        print(str(exc) + " | Error in function GeneratePlane")

def createbakingmat(subname, ):
    try:
        new_return_23AB6 = bpy.data.materials.new(name=(ao__shadowplane_generator["sourcename"] + r"_" + subname), )
        bpy.context.active_object.active_material=new_return_23AB6
        ao__shadowplane_generator["material"] = new_return_23AB6
        new_return_23AB6.blend_method = sn_cast_enum(r"BLEND", [("OPAQUE","Opaque","Render surface without transparency"),("CLIP","Alpha Clip","Use the alpha threshold to clip the visibility (binary visibility)"),("HASHED","Alpha Hashed","Use noise to dither the binary visibility (works well with multi-samples)"),("BLEND","Alpha Blend","Render polygon transparent, depending on alpha channel of the texture"),])
        new_return_23AB6.shadow_method = sn_cast_enum(r"HASHED", [("NONE","None","Material will cast no shadow"),("OPAQUE","Opaque","Material will cast shadows without transparency"),("CLIP","Alpha Clip","Use the alpha threshold to clip the visibility (binary visibility)"),("HASHED","Alpha Hashed","Use noise to dither the binary visibility and use filtering to reduce the noise"),])
        new_return_23AB6.use_nodes = True
        run_function_on_C11DD = new_return_23AB6.node_tree.nodes.new(type=r"ShaderNodeTexImage", )
        ao__shadowplane_generator["bakingtexnode"] = run_function_on_C11DD
        run_function_on_C11DD.location=(-400.0, 0.0)
        new_return_23AB6.node_tree.nodes.active=run_function_on_C11DD
        function_return_80700 = linkmaterialnodes(run_function_on_C11DD, 0, new_return_23AB6.node_tree.nodes[r"Principled BSDF"], 0, )
        if ao__shadowplane_generator["isao"]:
            function_return_6E334 = linkmaterialnodes(run_function_on_C11DD, 1, new_return_23AB6.node_tree.nodes[r"Principled BSDF"], 19, )
        else:
            pass
        ao__shadowplane_generator["isao"] = False
    except Exception as exc:
        print(str(exc) + " | Error in function CreateBakingMat")

def linkmaterialnodes(output_node, output_socket, input_node, input_socket, ):
    try:
        for_node_F6F0E = 0
        for_node_index_F6F0E = 0
        for for_node_index_F6F0E, for_node_F6F0E in enumerate(input_node.inputs):
            for_node_D6D2F = 0
            for_node_index_D6D2F = 0
            for for_node_index_D6D2F, for_node_D6D2F in enumerate(output_node.outputs):
                break
            break
        new_return_7D6F3 = bpy.context.active_object.active_material.node_tree.links.new(input=for_node_F6F0E.node.inputs[input_socket], output=for_node_D6D2F.node.outputs[output_socket], verify_limits=True, )
    except Exception as exc:
        print(str(exc) + " | Error in function LinkMaterialNodes")

def setparent():
    try:
        print(ao__shadowplane_generator["sourcename"])
        run_function_on_A6196 = ao__shadowplane_generator["ao_plane"].select_set(state=True, view_layer=None, )
        run_function_on_A28EB = bpy.data.objects[ao__shadowplane_generator["sourcename"]].select_set(state=True, view_layer=None, )
        bpy.context.view_layer.objects.active=bpy.data.objects[ao__shadowplane_generator["sourcename"]]
        op_reset_context = bpy.context.area.type
        bpy.context.area.type = 'VIEW_3D'
        bpy.ops.object.parent_set('INVOKE_DEFAULT' if True else 'EXEC_DEFAULT',type=sn_cast_enum(r"OBJECT", [("OBJECT","Object",""),("ARMATURE","Armature Deform",""),("ARMATURE_NAME","   With Empty Groups",""),("ARMATURE_AUTO","   With Automatic Weights",""),("ARMATURE_ENVELOPE","   With Envelope Weights",""),("BONE","Bone",""),("BONE_RELATIVE","Bone Relative",""),("CURVE","Curve Deform",""),("FOLLOW","Follow Path",""),("PATH_CONST","Path Constraint",""),("LATTICE","Lattice Deform",""),("VERTEX","Vertex",""),("VERTEX_TRI","Vertex (Triangle)",""),]),xmirror=False,keep_transform=True,)
        bpy.context.area.type = op_reset_context
        run_function_on_EFBB2 = bpy.data.objects[ao__shadowplane_generator["sourcename"]].select_set(state=False, view_layer=None, )
    except Exception as exc:
        print(str(exc) + " | Error in function SetParent")

def sn_handle_script_line_exception(exc, line):
    print("# # # # # # # # SCRIPT LINE ERROR # # # # # # # #")
    print("Line:", line)
    raise exc

def createtexture(tex_name, ):
    try:
        bpy.context.scene.render.resolution_x=bpy.context.scene.textureresolution
        bpy.context.scene.render.resolution_y=bpy.context.scene.textureresolution
        bpy.context.scene.render.resolution_percentage=100
        print(sn_cast_string(bpy.context.scene.textureresolution))
        new_return_8EDB5 = bpy.data.images.new(name=(ao__shadowplane_generator["sourcename"] + r"_" + tex_name), width=bpy.context.scene.textureresolution, height=bpy.context.scene.textureresolution, alpha=True, float_buffer=False, stereo3d=False, is_data=False, tiled=False, )
        bpy.context.scene.ao_tex = new_return_8EDB5.name
        ao__shadowplane_generator["bakingtexnode"].parent=ao__shadowplane_generator["bakingtexnode"]
        ao__shadowplane_generator["bakingtexnode"].image=new_return_8EDB5
        ao__shadowplane_generator["ao_tex"] = new_return_8EDB5
    except Exception as exc:
        print(str(exc) + " | Error in function CreateTexture")

def bake_ao():
    try:
        bpy.context.scene.cycles["samples"] = 8
        bpy.context.scene.render.bake.use_selected_to_active=False
        bpy.context.scene.render.bake.use_clear=True
        bpy.context.scene.render.bake.use_split_materials=False
        bpy.context.scene.render.bake.use_automatic_name=False
        bpy.context.scene.render.bake.use_cage=False
        bpy.context.scene.render.bake.use_pass_ambient_occlusion=True
        bpy.context.scene.render.bake.use_pass_emit=False
        bpy.context.scene.render.bake.use_pass_direct=False
        bpy.context.scene.render.bake.use_pass_indirect=False
        bpy.context.scene.render.bake.use_pass_color=False
        bpy.context.scene.render.bake.use_pass_diffuse=False
        bpy.context.scene.render.bake.use_pass_glossy=False
        bpy.context.scene.render.bake.use_pass_transmission=False
        bpy.ops.object.bake('INVOKE_DEFAULT' if False else 'EXEC_DEFAULT',type=sn_cast_enum(r"AO", [("COMBINED","Combined",""),("AO","Ambient Occlusion",""),("SHADOW","Shadow",""),("NORMAL","Normal",""),("UV","UV",""),("ROUGHNESS","ROUGHNESS",""),("EMIT","Emit",""),("ENVIRONMENT","Environment",""),("DIFFUSE","Diffuse",""),("GLOSSY","Glossy",""),("TRANSMISSION","Transmission",""),]),use_clear=True,)
    except Exception as exc:
        print(str(exc) + " | Error in function Bake AO")

def bake_shadow():
    try:
        bpy.context.scene.cycles["samples"] = 8
        bpy.context.scene.render.bake.use_selected_to_active=False
        bpy.context.scene.render.bake.use_clear=True
        bpy.context.scene.render.bake.use_split_materials=False
        bpy.context.scene.render.bake.use_automatic_name=False
        bpy.context.scene.render.bake.use_cage=False
        bpy.context.scene.render.bake.use_pass_ambient_occlusion=False
        bpy.context.scene.render.bake.use_pass_emit=False
        bpy.context.scene.render.bake.use_pass_direct=True
        bpy.context.scene.render.bake.use_pass_indirect=True
        bpy.context.scene.render.bake.use_pass_color=False
        bpy.context.scene.render.bake.use_pass_diffuse=False
        bpy.context.scene.render.bake.use_pass_glossy=False
        bpy.context.scene.render.bake.use_pass_transmission=False
        bpy.ops.object.bake('INVOKE_DEFAULT' if False else 'EXEC_DEFAULT',type=sn_cast_enum(r"SHADOW", [("COMBINED","Combined",""),("AO","Ambient Occlusion",""),("SHADOW","Shadow",""),("NORMAL","Normal",""),("UV","UV",""),("ROUGHNESS","ROUGHNESS",""),("EMIT","Emit",""),("ENVIRONMENT","Environment",""),("DIFFUSE","Diffuse",""),("GLOSSY","Glossy",""),("TRANSMISSION","Transmission",""),]),use_clear=True,)
    except Exception as exc:
        print(str(exc) + " | Error in function Bake Shadow")

def update_setresolution(self, context):
    if self.setresolution == r"256":
        self.textureresolution = sn_cast_int(r"256")
    else:
        if self.setresolution == r"512":
            self.textureresolution = sn_cast_int(r"512")
        else:
            if self.setresolution == r"1024":
                self.textureresolution = sn_cast_int(r"1024")
            else:
                if self.setresolution == r"2048":
                    self.textureresolution = sn_cast_int(r"2048")
                else:
                    if self.setresolution == r"4096":
                        self.textureresolution = sn_cast_int(r"4096")
                    else:
                        pass
    print(self.setresolution)


@persistent
def load_pre_handler_96E8A(dummy):
    bpy.context.scene.setresolution = sn_cast_enum(r"1024", [("256","256","Set the texture resolution to 256"),("512","512","Set the texture resolution to 512"),("1024","1024","Set the texture resolution to 1024"),("2048","2048","Set the texture resolution to 2048"),("4096","4096","Set the texture resolution to 4096"),])


###############   EVALUATED CODE
#######   AO / ShadowPlane generator
class SNA_OT_Bakeao(bpy.types.Operator):
    bl_idname = "sna.bakeao"
    bl_label = "BakeAO"
    bl_description = "Generate Ambient Occlusion Plane"
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in execute function of BakeAO")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            try: exec(r"bpy.ops.outliner.orphans_purge(do_local_ids=True, do_linked_ids=True, do_recursive=True)")
            except Exception as exc: sn_handle_script_line_exception(exc, r"bpy.ops.outliner.orphans_purge(do_local_ids=True, do_linked_ids=True, do_recursive=True)")
            ao__shadowplane_generator["currentframe"] = bpy.context.scene.frame_current
            bpy.context.scene.frame_current = 0
            bpy.context.scene.render.engine = r"CYCLES"
            bpy.context.scene.isao = True
            bpy.context.scene.view_settings.view_transform = r"Standard"
            function_return_B7538 = generateplane()
            ao__shadowplane_generator["isao"] = True
            function_return_44B69 = createbakingmat(r"AO_Plane", )
            function_return_76391 = createtexture(r"AO_Plane", )
            bpy.context.scene.texoutputpath = bpy.context.scene.ao_tex
            function_return_81215 = bake_ao()
            pass # Denoise Script Start
            #import bpy
            #import os
            bpy.context.scene.use_nodes = True
            tree = bpy.context.scene.node_tree
            AO_Tex = bpy.context.scene.ao_tex
            OutputPath = bpy.context.scene.texoutputpath
            isAO = bpy.context.scene.isao
            # clear default nodes
            for node in tree.nodes:
                tree.nodes.remove(node)
            # create input image node
            image_node = tree.nodes.new(type='CompositorNodeImage')
            image_node.image = bpy.data.images[AO_Tex]
            image_node.location = 0,0
            denoise_node = tree.nodes.new('CompositorNodeDenoise')   
            denoise_node.location = 150,0
            #contrast_node = tree.nodes.new('CompositorNodeBrightContrast')  
            #contrast_node.inputs[1].default_value = 5
            #contrast_node.inputs[2].default_value = 5
            #contrast_node.location = 300,0
            #contrast_node = tree.nodes.new('CompositorNodeGamma')  
            #contrast_node.inputs[1].default_value = 0.25
            #contrast_node.location = 300,0
            contrast_node = tree.nodes.new('CompositorNodeExposure')  
            contrast_node.location = 300,0
            if isAO:
                contrast_node.inputs[1].default_value = 0.25
            else:
                contrast_node.inputs[1].default_value = 2
            invert_node = tree.nodes.new('CompositorNodeInvert')   
            invert_node.location = 450,0
            bw_node = tree.nodes.new('CompositorNodeRGBToBW')   
            bw_node.location = 600,0
            # create output node
            #viewer_node = tree.nodes.new('CompositorNodeViewer')   
            #viewer_node.location = 900,0
            viewer_node = tree.nodes.new(type='CompositorNodeOutputFile')
            bpy.context.scene.node_tree.nodes.active = viewer_node
            viewer_node.location = 1030,0
            viewer_node.base_path = "//"
            viewer_node.format.file_format = "PNG"
            viewer_node.format.color_mode = "RGBA"
            viewer_node.layer_slots.new(OutputPath)
            print(OutputPath)
            BoxMask_node = tree.nodes.new('CompositorNodeBoxMask')   
            BoxMask_node.location = 150,-160
            BoxMask_node.height = 0.9
            BoxMask_node.width = 0.9
            BoxMask_node.mask_type = 'NOT'
            Blur_node = tree.nodes.new('CompositorNodeBlur')  
            Blur_node.location = 300,-160
            Blur_node.filter_type = 'FAST_GAUSS'
            Blur_node.use_relative = True
            Blur_node.factor_x = 10
            Blur_node.factor_y = 10
            Blur_node.use_extended_bounds = True
            invertMask_node = tree.nodes.new('CompositorNodeInvert')   
            invertMask_node.location = 450,-160
            Mix_node = tree.nodes.new('CompositorNodeMixRGB')   
            Mix_node.location = 715,0
            Mix_node.blend_type = 'SUBTRACT'
            SetAlpha_node = tree.nodes.new('CompositorNodeSetAlpha')   
            SetAlpha_node.location = 875,0
            # link nodes
            links = tree.links
            link = links.new(image_node.outputs[0], denoise_node.inputs[0])
            link = links.new(denoise_node.outputs[0], contrast_node.inputs[0])
            link = links.new(contrast_node.outputs[0], invert_node.inputs[1])
            link = links.new(invert_node.outputs[0], bw_node.inputs[0])
            link = links.new(bw_node.outputs[0], Mix_node.inputs[1])
            link = links.new(BoxMask_node.outputs[0], Blur_node.inputs[0])
            link = links.new(Blur_node.outputs[0], invertMask_node.inputs[1])
            link = links.new(invertMask_node.outputs[0], Mix_node.inputs[2])
            link = links.new(Mix_node.outputs[0], SetAlpha_node.inputs[1])
            link = links.new(SetAlpha_node.outputs[0], viewer_node.inputs[1])
            #ForceComp Update
            bpy.ops.render.render(animation=False, write_still=False, use_viewport=False, layer="", scene="")
            pass # Denoise Script End
            bpy.context.scene.render.engine = r"BLENDER_EEVEE"
            pass # LoadTexture Script Start
            #import bpy
            cleanup = bpy.context.scene.cleanup
            mat = bpy.context.active_object.active_material
            #get the nodes
            #mat.use_nodes = True
            nodes = mat.node_tree.nodes
            loadedtexturename = bpy.context.scene.texoutputpath
            # get some specific node:
            # returns None if the node does not exist
            ImageTexture_Node = nodes.get("Image Texture")
            bsdf = nodes.get("Principled BSDF")
            bsdf.inputs[5].default_value = 0
            bsdf.inputs[7].default_value = 1
            ImageTexture_Node.image = bpy.data.images.load("//"+loadedtexturename+"0000"+".png")
            print(ImageTexture_Node.image)
            mat.node_tree.links.new(bsdf.inputs['Base Color'], ImageTexture_Node.outputs['Color'])
            mat.node_tree.links.new(bsdf.inputs['Alpha'], ImageTexture_Node.outputs['Alpha'])
            if cleanup:
                bpy.context.scene.use_nodes = True
                tree = bpy.context.scene.node_tree
                # clear default nodes
                for node in tree.nodes:
                    tree.nodes.remove(node)
                bpy.ops.outliner.orphans_purge(do_local_ids=True, do_linked_ids=True, do_recursive=True)
            pass # LoadTexture Script End
            bpy.context.scene.frame_current = ao__shadowplane_generator["currentframe"]
            try: self.report({'INFO'}, message=r"---------DONE---------")
            except: print("Serpens - Can't report in this context!")
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of BakeAO")
        return self.execute(context)


class SNA_OT_Bakeshadow(bpy.types.Operator):
    bl_idname = "sna.bakeshadow"
    bl_label = "BakeShadow"
    bl_description = "Generate Shadow Plane"
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in execute function of BakeShadow")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            try: exec(r"bpy.ops.outliner.orphans_purge(do_local_ids=True, do_linked_ids=True, do_recursive=True)")
            except Exception as exc: sn_handle_script_line_exception(exc, r"bpy.ops.outliner.orphans_purge(do_local_ids=True, do_linked_ids=True, do_recursive=True)")
            ao__shadowplane_generator["currentframe"] = bpy.context.scene.frame_current
            bpy.context.scene.frame_current = 0
            bpy.context.scene.render.engine = r"CYCLES"
            bpy.context.scene.isao = False
            bpy.context.scene.view_settings.view_transform = r"Standard"
            function_return_3870F = generateplane()
            ao__shadowplane_generator["isao"] = False
            function_return_A0946 = createbakingmat(r"Shadow_Plane", )
            function_return_7F94B = createtexture(r"Shadow_Plane", )
            bpy.context.scene.texoutputpath = bpy.context.scene.ao_tex
            function_return_ABF24 = bake_shadow()
            pass # Denoise Script Start
            #import bpy
            #import os
            bpy.context.scene.use_nodes = True
            tree = bpy.context.scene.node_tree
            AO_Tex = bpy.context.scene.ao_tex
            OutputPath = bpy.context.scene.texoutputpath
            isAO = bpy.context.scene.isao
            # clear default nodes
            for node in tree.nodes:
                tree.nodes.remove(node)
            # create input image node
            image_node = tree.nodes.new(type='CompositorNodeImage')
            image_node.image = bpy.data.images[AO_Tex]
            image_node.location = 0,0
            denoise_node = tree.nodes.new('CompositorNodeDenoise')   
            denoise_node.location = 150,0
            #contrast_node = tree.nodes.new('CompositorNodeBrightContrast')  
            #contrast_node.inputs[1].default_value = 5
            #contrast_node.inputs[2].default_value = 5
            #contrast_node.location = 300,0
            #contrast_node = tree.nodes.new('CompositorNodeGamma')  
            #contrast_node.inputs[1].default_value = 0.25
            #contrast_node.location = 300,0
            contrast_node = tree.nodes.new('CompositorNodeExposure')  
            contrast_node.location = 300,0
            if isAO:
                contrast_node.inputs[1].default_value = 0.25
            else:
                contrast_node.inputs[1].default_value = 2
            invert_node = tree.nodes.new('CompositorNodeInvert')   
            invert_node.location = 450,0
            bw_node = tree.nodes.new('CompositorNodeRGBToBW')   
            bw_node.location = 600,0
            # create output node
            #viewer_node = tree.nodes.new('CompositorNodeViewer')   
            #viewer_node.location = 900,0
            viewer_node = tree.nodes.new(type='CompositorNodeOutputFile')
            bpy.context.scene.node_tree.nodes.active = viewer_node
            viewer_node.location = 1030,0
            viewer_node.base_path = "//"
            viewer_node.format.file_format = "PNG"
            viewer_node.format.color_mode = "RGBA"
            viewer_node.layer_slots.new(OutputPath)
            print(OutputPath)
            BoxMask_node = tree.nodes.new('CompositorNodeBoxMask')   
            BoxMask_node.location = 150,-160
            BoxMask_node.height = 0.9
            BoxMask_node.width = 0.9
            BoxMask_node.mask_type = 'NOT'
            Blur_node = tree.nodes.new('CompositorNodeBlur')  
            Blur_node.location = 300,-160
            Blur_node.filter_type = 'FAST_GAUSS'
            Blur_node.use_relative = True
            Blur_node.factor_x = 10
            Blur_node.factor_y = 10
            Blur_node.use_extended_bounds = True
            invertMask_node = tree.nodes.new('CompositorNodeInvert')   
            invertMask_node.location = 450,-160
            Mix_node = tree.nodes.new('CompositorNodeMixRGB')   
            Mix_node.location = 715,0
            Mix_node.blend_type = 'SUBTRACT'
            SetAlpha_node = tree.nodes.new('CompositorNodeSetAlpha')   
            SetAlpha_node.location = 875,0
            # link nodes
            links = tree.links
            link = links.new(image_node.outputs[0], denoise_node.inputs[0])
            link = links.new(denoise_node.outputs[0], contrast_node.inputs[0])
            link = links.new(contrast_node.outputs[0], invert_node.inputs[1])
            link = links.new(invert_node.outputs[0], bw_node.inputs[0])
            link = links.new(bw_node.outputs[0], Mix_node.inputs[1])
            link = links.new(BoxMask_node.outputs[0], Blur_node.inputs[0])
            link = links.new(Blur_node.outputs[0], invertMask_node.inputs[1])
            link = links.new(invertMask_node.outputs[0], Mix_node.inputs[2])
            link = links.new(Mix_node.outputs[0], SetAlpha_node.inputs[1])
            link = links.new(SetAlpha_node.outputs[0], viewer_node.inputs[1])
            #ForceComp Update
            bpy.ops.render.render(animation=False, write_still=False, use_viewport=False, layer="", scene="")
            pass # Denoise Script End
            bpy.context.scene.render.engine = r"BLENDER_EEVEE"
            pass # LoadTexture Script Start
            #import bpy
            cleanup = bpy.context.scene.cleanup
            mat = bpy.context.active_object.active_material
            #get the nodes
            #mat.use_nodes = True
            nodes = mat.node_tree.nodes
            loadedtexturename = bpy.context.scene.texoutputpath
            # get some specific node:
            # returns None if the node does not exist
            ImageTexture_Node = nodes.get("Image Texture")
            bsdf = nodes.get("Principled BSDF")
            bsdf.inputs[5].default_value = 0
            bsdf.inputs[7].default_value = 1
            ImageTexture_Node.image = bpy.data.images.load("//"+loadedtexturename+"0000"+".png")
            print(ImageTexture_Node.image)
            mat.node_tree.links.new(bsdf.inputs['Base Color'], ImageTexture_Node.outputs['Color'])
            mat.node_tree.links.new(bsdf.inputs['Alpha'], ImageTexture_Node.outputs['Alpha'])
            if cleanup:
                bpy.context.scene.use_nodes = True
                tree = bpy.context.scene.node_tree
                # clear default nodes
                for node in tree.nodes:
                    tree.nodes.remove(node)
                bpy.ops.outliner.orphans_purge(do_local_ids=True, do_linked_ids=True, do_recursive=True)
            pass # LoadTexture Script End
            bpy.context.scene.frame_current = ao__shadowplane_generator["currentframe"]
            try: self.report({'INFO'}, message=r"---------DONE---------")
            except: print("Serpens - Can't report in this context!")
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of BakeShadow")
        return self.execute(context)


class SNA_PT_Generate_Shoadow__AO_Plane_AE490(bpy.types.Panel):
    bl_label = "Generate Shoadow / AO Plane"
    bl_idname = "SNA_PT_Generate_Shoadow__AO_Plane_AE490"
    bl_space_type = "PROPERTIES"
    bl_region_type = "WINDOW"
    bl_context = 'render'
    bl_order = 0


    @classmethod
    def poll(cls, context):
        return True

    def draw_header(self, context):
        try:
            layout = self.layout
        except Exception as exc:
            print(str(exc) + " | Error in Generate Shoadow / AO Plane panel header")

    def draw(self, context):
        try:
            layout = self.layout
            box = layout.box()
            box.enabled = True
            box.alert = False
            box.scale_x = 1.0
            box.scale_y = 1.0
            row = box.row(align=True)
            row.enabled = True
            row.alert = False
            row.scale_x = 1.0
            row.scale_y = 1.0
            row.label(text=r"Generate Shadowplane",icon_value=0)
            row.label(text=r"Resolution:",icon_value=0)
            col = box.column(align=True)
            col.enabled = True
            col.alert = False
            col.scale_x = 2.0
            col.scale_y = 1.0
            row = col.row(align=False)
            row.enabled = True
            row.alert = False
            row.scale_x = 1.0
            row.scale_y = 1.0
            row = row.row(align=True)
            row.enabled = True
            row.alert = False
            row.scale_x = 2.0
            row.scale_y = 1.0
            row.prop(bpy.context.scene,'sizemultiplier',text=r"Size multiplier",emboss=True,slider=True,)
            row.prop(bpy.context.scene,'hight',text=r"Hight offset",emboss=True,slider=True,)
            row = row.row(align=False)
            row.enabled = True
            row.alert = False
            row.scale_x = 0.800000011920929
            row.scale_y = 1.0
            row.prop(bpy.context.scene,'setresolution',icon_value=0,text=r"Set Resolution",emboss=True,expand=True,)
            row.prop(bpy.context.scene,'cleanup',icon_value=182,text=r"",emboss=True,toggle=False,invert_checkbox=False,)
            col = box.column(align=True)
            col.enabled = True
            col.alert = False
            col.scale_x = 1.0
            col.scale_y = 2.0
            row = col.row(align=False)
            row.enabled = (sn_cast_boolean(bpy.context.active_object) and sn_cast_boolean(bpy.context.selected_objects) and bpy.data.is_saved)
            row.alert = False
            row.scale_x = 1.0
            row.scale_y = 1.0
            op = row.operator("sna.bakeao",text=r"Bake AO Map",emboss=True,depress=False,icon_value=627)
            op = row.operator("sna.bakeshadow",text=r"Bake Shadow Map",emboss=True,depress=False,icon_value=736)
        except Exception as exc:
            print(str(exc) + " | Error in Generate Shoadow / AO Plane panel")


###############   REGISTER ICONS
def sn_register_icons():
    icons = []
    bpy.types.Scene.ao__shadowplane_generator_icons = bpy.utils.previews.new()
    icons_dir = os.path.join( os.path.dirname( __file__ ), "icons" )
    for icon in icons:
        bpy.types.Scene.ao__shadowplane_generator_icons.load( icon, os.path.join( icons_dir, icon + ".png" ), 'IMAGE' )

def sn_unregister_icons():
    bpy.utils.previews.remove( bpy.types.Scene.ao__shadowplane_generator_icons )


###############   REGISTER PROPERTIES
def sn_register_properties():
    bpy.types.Scene.sizemultiplier = bpy.props.FloatProperty(name='SizeMultiplier',description='Set the soze multiplier of the AO/Shadow plane',subtype='NONE',unit='NONE',options=set(),precision=1, default=1.5,min=1.0,max=3.0)
    bpy.types.Scene.textureresolution = bpy.props.IntProperty(name='TextureResolution',description='',subtype='NONE',options=set(),default=1024)
    bpy.types.Scene.setresolution = bpy.props.EnumProperty(name='SetResolution',description='',options={'HIDDEN'},update=update_setresolution,items=[('256', '256', 'Set the texture resolution to 256'), ('512', '512', 'Set the texture resolution to 512'), ('1024', '1024', 'Set the texture resolution to 1024'), ('2048', '2048', 'Set the texture resolution to 2048'), ('4096', '4096', 'Set the texture resolution to 4096')])
    bpy.types.Scene.ao_tex = bpy.props.StringProperty(name='AO_Tex',description='',subtype='NONE',options=set(),default='')
    bpy.types.Scene.ao_planematname = bpy.props.StringProperty(name='AO_PlaneMatName',description='',subtype='NONE',options=set(),default='')
    bpy.types.Scene.hight = bpy.props.FloatProperty(name='Hight',description='Set the hight offset of the AO/Shadow plane',subtype='NONE',unit='NONE',options=set(),precision=2, default=0.009999999776482582,min=-1.0,max=1.0)
    bpy.types.Scene.texoutputpath = bpy.props.StringProperty(name='TexOutputPath',description='',subtype='NONE',options=set(),default='//Rendering.png')
    bpy.types.Scene.loadedtexturename = bpy.props.StringProperty(name='LoadedTextureName',description='',subtype='NONE',options=set(),default='')
    bpy.types.Scene.isao = bpy.props.BoolProperty(name='isAO',description='',options=set(),default=True)
    bpy.types.Scene.cleanup = bpy.props.BoolProperty(name='Cleanup',description='Cleanup Compositing',options=set(),default=True)

def sn_unregister_properties():
    del bpy.types.Scene.sizemultiplier
    del bpy.types.Scene.textureresolution
    del bpy.types.Scene.setresolution
    del bpy.types.Scene.ao_tex
    del bpy.types.Scene.ao_planematname
    del bpy.types.Scene.hight
    del bpy.types.Scene.texoutputpath
    del bpy.types.Scene.loadedtexturename
    del bpy.types.Scene.isao
    del bpy.types.Scene.cleanup


###############   REGISTER ADDON
def register():
    sn_register_icons()
    sn_register_properties()
    bpy.utils.register_class(SNA_OT_Bakeao)
    bpy.utils.register_class(SNA_OT_Bakeshadow)
    bpy.app.handlers.load_pre.append(load_pre_handler_96E8A)
    bpy.utils.register_class(SNA_PT_Generate_Shoadow__AO_Plane_AE490)


###############   UNREGISTER ADDON
def unregister():
    sn_unregister_icons()
    sn_unregister_properties()
    bpy.utils.unregister_class(SNA_PT_Generate_Shoadow__AO_Plane_AE490)
    bpy.app.handlers.load_pre.remove(load_pre_handler_96E8A)
    bpy.utils.unregister_class(SNA_OT_Bakeshadow)
    bpy.utils.unregister_class(SNA_OT_Bakeao)