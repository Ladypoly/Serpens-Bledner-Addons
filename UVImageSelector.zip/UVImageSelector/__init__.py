# __init__.py

import bpy
import bpy.utils.previews
from bpy.props import EnumProperty

# Global variable for the preview collection
preview_col = None

def get_image_items(self, context):
    """
    Dynamically generate EnumProperty items for each unique image used by the active object's materials.
    Each item includes the image name and its preview icon.
    """
    obj = context.active_object

    if not obj:
        return []

    if obj.type not in {'MESH', 'CURVE', 'SURFACE', 'META', 'FONT'}:
        return []

    # Collect unique images from the active object's materials
    images = set()
    for mat_slot in obj.material_slots:
        mat = mat_slot.material
        if mat:
            if mat.use_nodes and mat.node_tree:
                for node in mat.node_tree.nodes:
                    if node.type == 'TEX_IMAGE' and node.image:
                        images.add(node.image)
            else:
                for tex_slot in mat.texture_slots:
                    if tex_slot and tex_slot.texture and tex_slot.texture.type == 'IMAGE' and tex_slot.texture.image:
                        images.add(tex_slot.texture.image)

    # Build the items list for EnumProperty
    items = []
    for idx, img in enumerate(sorted(images, key=lambda x: x.name.lower())):
        # Initialize the icon_id with a default icon
        icon_id = 'IMAGE_DATA'

        # Check if the image is packed
        if img.packed_file:
            # Packed images cannot have previews loaded from file paths
            # Use the default icon or a custom one if desired
            icon_id = 'FILE_BLEND'  # Represents a packed file
        elif img.filepath and bpy.path.abspath(img.filepath) != "":
            # Attempt to load the image preview if filepath is valid
            if not preview_col.get(img.name):
                try:
                    # Load the image preview; use the absolute path
                    preview_col.load(img.name, bpy.path.abspath(img.filepath), 'IMAGE')
                except Exception as e:
                    # Handle cases where the image file might be missing or corrupted
                    print(f"Failed to load preview for '{img.name}': {e}")
            # If the preview was successfully loaded, use its icon_id
            if preview_col.get(img.name):
                icon_id = preview_col[img.name].icon_id
            else:
                # If loading failed, keep the default icon
                icon_id = 'IMAGE_DATA'
        else:
            # Images without a valid filepath (e.g., procedurally generated)
            # Use the default icon or a different one to indicate missing previews
            icon_id = 'IMAGE_DATA'

        # Append the item with the image name and its preview icon
        items.append((
            img.name,                   # Identifier
            img.name,                   # Name displayed in the UI
            "",                         # Description (optional)
            icon_id,                    # Icon ID
            idx                         # Unique identifier (index)
        ))

    return items

def set_main_image(self, context):
    """
    Update function for the EnumProperty.
    Sets the selected image as the main image in the UV/Image Editor.
    """
    selected_image_name = self.my_texture_gallery

    if selected_image_name:
        img = bpy.data.images.get(selected_image_name)
        if img:
            space = context.space_data
            if space.type == 'IMAGE_EDITOR':
                previous_image = space.image
                space.image = img
                # Provide a user notification
                self.report({'INFO'}, f"Set '{img.name}' as the main image. Previous image '{previous_image.name if previous_image else 'None'}' was replaced.")
                print(f"Set '{img.name}' as the main image. Previous image '{previous_image.name if previous_image else 'None'}' was replaced.")

class TEXTUREGALLERY_PT_gallery(bpy.types.Panel):
    """
    Custom panel to display textures in a gallery view within the UV/Image Editor's sidebar.
    """
    bl_label = "Used Textures Gallery"
    bl_idname = "IMAGE_PT_used_textures_gallery"
    bl_space_type = 'IMAGE_EDITOR'
    bl_region_type = 'UI'
    bl_category = 'Image'  # Changed from 'Textures' to 'Image'

    def draw(self, context):
        layout = self.layout
        scene = context.scene

        obj = context.active_object

        if not obj:
            layout.label(text="No active object selected.")
            return

        if obj.type not in {'MESH', 'CURVE', 'SURFACE', 'META', 'FONT'}:
            layout.label(text="Active object does not support materials.")
            return

        # Check if there are images to display
        images = get_image_items(self, context)
        if not images:
            layout.label(text="No textures found on the active object.")
            return

        # Display the gallery using template_icon_view
        # The 'scale' parameter adjusts the size of the thumbnails
        layout.template_icon_view(scene, "my_texture_gallery", show_labels=True, scale=6.0)

class TEXTUREGALLERY_PT_preferences(bpy.types.AddonPreferences):
    """
    Preferences panel for the extension.
    """
    bl_idname = __package__

    def draw(self, context):
        layout = self.layout
        layout.label(text="No preferences available.")

def register():
    global preview_col
    preview_col = bpy.utils.previews.new()

    # Register the EnumProperty with the update callback
    bpy.types.Scene.my_texture_gallery = EnumProperty(
        name="Texture Gallery",
        description="Select a texture to set as the main image in the UV/Image Editor",
        items=get_image_items,
        update=set_main_image
    )

    bpy.utils.register_class(TEXTUREGALLERY_PT_gallery)
    bpy.utils.register_class(TEXTUREGALLERY_PT_preferences)

def unregister():
    bpy.utils.unregister_class(TEXTUREGALLERY_PT_gallery)
    bpy.utils.unregister_class(TEXTUREGALLERY_PT_preferences)
    del bpy.types.Scene.my_texture_gallery
    bpy.utils.previews.remove(preview_col)

if __name__ == "__main__":
    register()
