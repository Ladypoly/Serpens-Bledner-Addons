# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

bl_info = {
    "name" : "ImportDepthMap",
    "author" : "Elin", 
    "description" : "",
    "blender" : (3, 0, 0),
    "version" : (1, 0, 0),
    "location" : "Tool",
    "warning" : "",
    "doc_url": "", 
    "tracker_url": "", 
    "category" : "3D View" 
}


import bpy
import bpy.utils.previews
import math


addon_keymaps = {}
_icons = None
nodetree = {'sna_image': None, 'sna_depthimage': None, }


def sna_subsurfsettings_8C39B(Name, Levels, Type, Index):
    bpy.context.view_layer.objects.active.modifiers.values()[Index].name = Name
    bpy.context.view_layer.objects.active.modifiers.values()[Index].subdivision_type = Type
    bpy.context.view_layer.objects.active.modifiers.values()[Index].render_levels = Levels
    bpy.context.view_layer.objects.active.modifiers.values()[Index].levels = Levels


def sna_setdisplacesettings_E5830(Index):
    bpy.context.view_layer.objects.active.modifiers.values()[Index].texture_coords = 'UV'
    texture_F90B3 = bpy.data.textures.new(name='DepthDisplace', type='IMAGE', )
    bpy.context.view_layer.objects.active.modifiers.values()[Index].texture = texture_F90B3
    texture_F90B3.extension = 'CLIP'
    if bpy.context.scene.sna_seperateimages:
        texture_F90B3.image = nodetree['sna_depthimage']
    else:
        texture_F90B3.image = nodetree['sna_image']
        bpy.context.view_layer.objects.active.modifiers.values()[Index].texture.crop_min_x = 0.5


def sna_materialsetup_AC51B():
    bpy.ops.object.material_slot_add('INVOKE_DEFAULT', )
    material_F46A0 = bpy.data.materials.new(name=nodetree['sna_image'].name, )
    material_F46A0.use_nodes = True
    bpy.context.object.active_material = material_F46A0
    node_A7B06 = material_F46A0.node_tree.nodes.new(type='ShaderNodeTexImage', )
    node_A7B06.location = (-300.0, 100.0)
    node_A7B06.image = nodetree['sna_image']
    material_F46A0.node_tree.nodes['Principled BSDF'].inputs['Roughness'].default_value = 1.0
    link_B8FF1 = material_F46A0.node_tree.links.new(input=material_F46A0.node_tree.nodes['Principled BSDF'].inputs[0], output=node_A7B06.outputs[0], )
    link_F8C6B = material_F46A0.node_tree.links.new(input=material_F46A0.node_tree.nodes['Principled BSDF'].inputs['Emission'], output=node_A7B06.outputs[0], )
    if bpy.context.scene.sna_seperateimages:
        pass
    else:
        node_4DD1D = material_F46A0.node_tree.nodes.new(type='ShaderNodeMapping', )
        node_4DD1D.location = (-500.0, 100.0)
        link_BF94B = material_F46A0.node_tree.links.new(input=node_A7B06.inputs[0], output=node_4DD1D.outputs[0], )
        node_125D2 = material_F46A0.node_tree.nodes.new(type='ShaderNodeTexCoord', )
        node_125D2.location = (-700.0, 100.0)
        link_0752D = material_F46A0.node_tree.links.new(input=node_4DD1D.inputs[0], output=node_125D2.outputs[2], )
        node_4DD1D.inputs['Scale'].default_value = (0.5, 1.0, 1.0)


def sna_add_to_topbar_mt_file_import_60CA8(self, context):
    if not (False):
        layout = self.layout


class SNA_PT_IMPORT_DEPTH_IMAGE_F8E84(bpy.types.Panel):
    bl_label = 'Import Depth Image'
    bl_idname = 'SNA_PT_IMPORT_DEPTH_IMAGE_F8E84'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_category = 'Tool'
    bl_order = 0
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        col_6CA06 = layout.column(heading='', align=False)
        col_6CA06.alert = False
        col_6CA06.enabled = True
        col_6CA06.active = True
        col_6CA06.use_property_split = False
        col_6CA06.use_property_decorate = False
        col_6CA06.scale_x = 1.0
        col_6CA06.scale_y = 1.0
        col_6CA06.alignment = 'Expand'.upper()
        col_6CA06.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        row_06E30 = col_6CA06.row(heading='', align=True)
        row_06E30.alert = False
        row_06E30.enabled = True
        row_06E30.active = True
        row_06E30.use_property_split = False
        row_06E30.use_property_decorate = False
        row_06E30.scale_x = 1.0
        row_06E30.scale_y = 1.0
        row_06E30.alignment = 'Expand'.upper()
        row_06E30.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        row_06E30.prop(bpy.context.scene, 'sna_image', text='Image', icon_value=0, emboss=True)
        row_06E30.prop(bpy.context.scene, 'sna_seperateimages', text='', icon_value=20, emboss=True, toggle=True)
        if bpy.context.scene.sna_seperateimages:
            col_6CA06.prop(bpy.context.scene, 'sna_depthimage', text='Depth', icon_value=0, emboss=True, toggle=True)
        if bool(bpy.context.scene.sna_image):
            op = col_6CA06.operator('sna.operator_ae495', text='', icon_value=444, emboss=True, depress=False)


class SNA_OT_Operator_Ae495(bpy.types.Operator):
    bl_idname = "sna.operator_ae495"
    bl_label = "Operator"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        image_736E6 = bpy.data.images.load(filepath=bpy.context.scene.sna_image, )
        nodetree['sna_image'] = image_736E6
        if bpy.context.scene.sna_seperateimages:
            image_DC27F = bpy.data.images.load(filepath=bpy.context.scene.sna_depthimage, )
            nodetree['sna_depthimage'] = image_DC27F
        bpy.ops.mesh.primitive_plane_add('INVOKE_DEFAULT', size=1.0)
        bpy.ops.object.shade_smooth('INVOKE_DEFAULT', use_auto_smooth=True, auto_smooth_angle=math.radians(60.0))
        bpy.context.view_layer.objects.active.rotation_euler = (math.radians(90.0), 0.0, 0.0)
        bpy.context.view_layer.objects.active.location = (0.0, 0.0, 0.5)
        bpy.context.view_layer.objects.active.scale = (image_736E6.size[0] / 2.0 / image_736E6.size[1], 1.0, 1.0)
        bpy.ops.object.transform_apply('INVOKE_DEFAULT', location=True, rotation=True, scale=True)
        bpy.ops.object.modifier_add('INVOKE_DEFAULT', type='SUBSURF')
        sna_subsurfsettings_8C39B('SIMPLE Subsurf', 6, 'SIMPLE', 0)
        bpy.ops.object.modifier_add('INVOKE_DEFAULT', type='DISPLACE')
        sna_setdisplacesettings_E5830(1)
        bpy.ops.object.modifier_add('INVOKE_DEFAULT', type='SUBSURF')
        sna_subsurfsettings_8C39B('Smooth Subsurf', 2, 'CATMULL_CLARK', 2)
        sna_materialsetup_AC51B()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def register():
    global _icons
    _icons = bpy.utils.previews.new()
    bpy.types.Scene.sna_seperateimages = bpy.props.BoolProperty(name='SeperateImages', description='', default=False)
    bpy.types.Scene.sna_image = bpy.props.StringProperty(name='Image', description='', default='', subtype='FILE_PATH', maxlen=0)
    bpy.types.Scene.sna_depthimage = bpy.props.StringProperty(name='DepthImage', description='', default='', subtype='FILE_PATH', maxlen=0)
    bpy.types.TOPBAR_MT_file_import.append(sna_add_to_topbar_mt_file_import_60CA8)
    bpy.utils.register_class(SNA_PT_IMPORT_DEPTH_IMAGE_F8E84)
    bpy.utils.register_class(SNA_OT_Operator_Ae495)


def unregister():
    global _icons
    bpy.utils.previews.remove(_icons)
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    for km, kmi in addon_keymaps.values():
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()
    del bpy.types.Scene.sna_depthimage
    del bpy.types.Scene.sna_image
    del bpy.types.Scene.sna_seperateimages
    bpy.types.TOPBAR_MT_file_import.remove(sna_add_to_topbar_mt_file_import_60CA8)
    bpy.utils.unregister_class(SNA_PT_IMPORT_DEPTH_IMAGE_F8E84)
    bpy.utils.unregister_class(SNA_OT_Operator_Ae495)
