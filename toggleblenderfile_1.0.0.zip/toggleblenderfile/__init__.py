# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.
#
# This addon was created with the Serpens - Visual Scripting Addon.
# This code is generated from nodes and is not intended for manual editing.
# You can find out more about Serpens at <https://blendermarket.com/products/serpens>.


bl_info = {
    "name": "ToggleBlenderFile",
    "description": "",
    "author": "eh",
    "version": (1, 0, 0),
    "blender": (2, 93, 0),
    "location": "",
    "warning": "",
    "wiki_url": "",
    "tracker_url": "",
    "category": "3D View"
}


###############   IMPORTS
import bpy
from bpy.utils import previews
import os
import math


###############   INITALIZE VARIABLES
toggleblenderfile = {
    "count": 0, 
    }


###############   SERPENS FUNCTIONS
def exec_line(line):
    exec(line)

def sn_print(tree_name, *args):
    if tree_name in bpy.data.node_groups:
        item = bpy.data.node_groups[tree_name].sn_graphs[0].prints.add()
        for arg in args:
            item.value += str(arg) + ";;;"
        if bpy.context and bpy.context.screen:
            for area in bpy.context.screen.areas:
                area.tag_redraw()
    print(*args)

def sn_cast_string(value):
    return str(value)

def sn_cast_boolean(value):
    if type(value) == tuple:
        for data in value:
            if bool(data):
                return True
        return False
    return bool(value)

def sn_cast_float(value):
    if type(value) == str:
        try:
            value = float(value)
            return value
        except:
            return float(bool(value))
    elif type(value) == tuple:
        return float(value[0])
    elif type(value) == list:
        return float(len(value))
    elif not type(value) in [float, int, bool]:
        try:
            value = len(value)
            return float(value)
        except:
            return float(bool(value))
    return float(value)

def sn_cast_int(value):
    return int(sn_cast_float(value))

def sn_cast_boolean_vector(value, size):
    if type(value) in [str, bool, int, float]:
        return_value = []
        for i in range(size):
            return_value.append(bool(value))
        return tuple(return_value)
    elif type(value) == tuple:
        return_value = []
        for i in range(size):
            return_value.append(bool(value[i]) if len(value) > i else bool(value[0]))
        return tuple(return_value)
    elif type(value) == list:
        return sn_cast_boolean_vector(tuple(value), size)
    else:
        try:
            value = tuple(value)
            return sn_cast_boolean_vector(value, size)
        except:
            return sn_cast_boolean_vector(bool(value), size)

def sn_cast_float_vector(value, size):
    if type(value) in [str, bool, int, float]:
        return_value = []
        for i in range(size):
            return_value.append(sn_cast_float(value))
        return tuple(return_value)
    elif type(value) == tuple:
        return_value = []
        for i in range(size):
            return_value.append(sn_cast_float(value[i]) if len(value) > i else sn_cast_float(value[0]))
        return tuple(return_value)
    elif type(value) == list:
        return sn_cast_float_vector(tuple(value), size)
    else:
        try:
            value = tuple(value)
            return sn_cast_float_vector(value, size)
        except:
            return sn_cast_float_vector(sn_cast_float(value), size)

def sn_cast_int_vector(value, size):
    return tuple(map(int, sn_cast_float_vector(value, size)))

def sn_cast_color(value, use_alpha):
    length = 4 if use_alpha else 3
    value = sn_cast_float_vector(value, length)
    tuple_list = []
    for data in range(length):
        data = value[data] if len(value) > data else value[0]
        tuple_list.append(sn_cast_float(min(1, max(0, data))))
    return tuple(tuple_list)

def sn_cast_list(value):
    if type(value) in [str, tuple, list]:
        return list(value)
    elif type(value) in [int, float, bool]:
        return [value]
    else:
        try:
            value = list(value)
            return value
        except:
            return [value]

def sn_cast_blend_data(value):
    if hasattr(value, "bl_rna"):
        return value
    elif type(value) in [tuple, bool, int, float, list]:
        return None
    elif type(value) == str:
        try:
            value = eval(value)
            return value
        except:
            return None
    else:
        return None

def sn_cast_enum(string, enum_values):
    for item in enum_values:
        if item[1] == string:
            return item[0]
        elif item[0] == string.upper():
            return item[0]
    return string


###############   IMPERATIVE CODE
#######   ToggleBlenderFile
def update_new_property(self, context):
    if self.new_property:
        try: exec(r"bpy.context.space_data.display_mode = 'LIBRARIES'")
        except Exception as exc: sn_handle_script_line_exception(exc, r"bpy.context.space_data.display_mode = 'LIBRARIES'")
    else:
        try: exec(r"bpy.context.space_data.display_mode = 'VIEW_LAYER'")
        except Exception as exc: sn_handle_script_line_exception(exc, r"bpy.context.space_data.display_mode = 'VIEW_LAYER'")

def sn_handle_script_line_exception(exc, line):
    print("# # # # # # # # SCRIPT LINE ERROR # # # # # # # #")
    print("Line:", line)
    raise exc


###############   EVALUATED CODE
#######   ToggleBlenderFile
class SNA_OT_Cleanempthys(bpy.types.Operator):
    bl_idname = "sna.cleanempthys"
    bl_label = "CleanEmpthys"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in execute function of CleanEmpthys")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            bpy.ops.object.select_all('INVOKE_DEFAULT' if True else 'EXEC_DEFAULT',action=sn_cast_enum(r"DESELECT", [("TOGGLE","Toggle","Toggle selection for all elements"),("SELECT","Select","Select all elements"),("DESELECT","Deselect","Deselect all elements"),("INVERT","Invert","Invert selection of all elements"),]),)
            for_node_E3393 = 0
            for_node_index_E3393 = 0
            for for_node_index_E3393, for_node_E3393 in enumerate(bpy.data.objects):
                if for_node_E3393.type=="EMPTY":
                    for_node_E3393.empty_display_size = 0.02500000037252903
                    run_function_on_47FA1 = for_node_E3393.select_set(state=True, view_layer=None, )
                    bpy.ops.object.transform_apply('INVOKE_DEFAULT' if True else 'EXEC_DEFAULT',location=False,rotation=True,scale=True,properties=True,)
                    run_function_on_A754B = for_node_E3393.select_set(state=False, view_layer=None, )
                    toggleblenderfile["count"] = int((sn_cast_float(toggleblenderfile["count"]) + 1.0))
                else:
                    pass
            pass # SelectImportedMaterials Script Start
            #import bpy
            context = bpy.context
            scene = context.scene
            mats = [m.name for m in bpy.data.materials if m.name.startswith("Material #")]
            for mat in mats:
                obs = [o for o in scene.objects
                        if o.type == 'MESH'
                        and mat in o.material_slots]
                if len(obs) > 1:
                    for o in obs:
                        o.select_set(True)
                    bpy.context.view_layer.objects.active = o
            pass # SelectImportedMaterials Script End
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of CleanEmpthys")
        return self.execute(context)


class SNA_OT_Save(bpy.types.Operator):
    bl_idname = "sna.save"
    bl_label = "Save"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in execute function of Save")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            bpy.context.area.type=sn_cast_enum(r"VIEW_3D", [("EMPTY","Empty",""),("VIEW_3D","3D Viewport","Manipulate objects in a 3D environment"),("IMAGE_EDITOR","UV/Image Editor","View and edit images and UV Maps"),("NODE_EDITOR","Node Editor","Editor for node-based shading and compositing tools"),("SEQUENCE_EDITOR","Video Sequencer","Video editing tools"),("CLIP_EDITOR","Movie Clip Editor","Motion tracking tools"),("DOPESHEET_EDITOR","Dope Sheet","Adjust timing of keyframes"),("GRAPH_EDITOR","Graph Editor","Edit drivers and keyframe interpolation"),("NLA_EDITOR","Nonlinear Animation","Combine and layer Actions"),("TEXT_EDITOR","Text Editor","Edit scripts and in-file documentation"),("CONSOLE","Python Console","Interactive programmatic console for advanced editing and script development"),("INFO","Info","Log of operations, warnings and error messages"),("TOPBAR","Top Bar","Global bar at the top of the screen for global per-window settings"),("STATUSBAR","Status Bar","Global bar at the bottom of the screen for general status information"),("OUTLINER","Outliner","Overview of scene graph and all available data-blocks"),("PROPERTIES","Properties","Edit properties of active object and related data-blocks"),("FILE_BROWSER","File Browser","Browse for files and assets"),("SPREADSHEET","Spreadsheet","Explore geometry data in a table"),("PREFERENCES","Preferences","Edit persistent configuration settings"),])
            bpy.context.area.spaces[0].shading.type = sn_cast_enum(r"SOLID", [("WIREFRAME","Wireframe","Display the object as wire edges"),("SOLID","Solid","Display in solid mode"),("MATERIAL","Material Preview","Display in Material Preview mode"),("RENDERED","Rendered","Display render preview"),])
            bpy.context.area.type=sn_cast_enum(r"OUTLINER", [("EMPTY","Empty",""),("VIEW_3D","3D Viewport","Manipulate objects in a 3D environment"),("IMAGE_EDITOR","UV/Image Editor","View and edit images and UV Maps"),("NODE_EDITOR","Node Editor","Editor for node-based shading and compositing tools"),("SEQUENCE_EDITOR","Video Sequencer","Video editing tools"),("CLIP_EDITOR","Movie Clip Editor","Motion tracking tools"),("DOPESHEET_EDITOR","Dope Sheet","Adjust timing of keyframes"),("GRAPH_EDITOR","Graph Editor","Edit drivers and keyframe interpolation"),("NLA_EDITOR","Nonlinear Animation","Combine and layer Actions"),("TEXT_EDITOR","Text Editor","Edit scripts and in-file documentation"),("CONSOLE","Python Console","Interactive programmatic console for advanced editing and script development"),("INFO","Info","Log of operations, warnings and error messages"),("TOPBAR","Top Bar","Global bar at the top of the screen for global per-window settings"),("STATUSBAR","Status Bar","Global bar at the bottom of the screen for general status information"),("OUTLINER","Outliner","Overview of scene graph and all available data-blocks"),("PROPERTIES","Properties","Edit properties of active object and related data-blocks"),("FILE_BROWSER","File Browser","Browse for files and assets"),("SPREADSHEET","Spreadsheet","Explore geometry data in a table"),("PREFERENCES","Preferences","Edit persistent configuration settings"),])
            try: exec(r"bpy.context.space_data.display_mode = 'VIEW_LAYER'")
            except Exception as exc: sn_handle_script_line_exception(exc, r"bpy.context.space_data.display_mode = 'VIEW_LAYER'")
            bpy.ops.wm.save_mainfile('INVOKE_DEFAULT' if True else 'EXEC_DEFAULT',)
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of Save")
        return self.execute(context)

def sn_prepend_menu_C642D(self,context):
    try:
        layout = self.layout
        layout.prop(bpy.context.scene,'new_property',icon_value=614,text=r"",emboss=True,toggle=False,invert_checkbox=False,)
        op = layout.operator("sna.cleanempthys",text=r"",emboss=True,depress=False,icon_value=76)
        op = layout.operator("sna.save",text=r"",emboss=True,depress=False,icon_value=70)
    except Exception as exc:
        print(str(exc) + " | Error in Outliner Ht Header when adding to menu")


###############   REGISTER ICONS
def sn_register_icons():
    icons = []
    bpy.types.Scene.toggleblenderfile_icons = bpy.utils.previews.new()
    icons_dir = os.path.join( os.path.dirname( __file__ ), "icons" )
    for icon in icons:
        bpy.types.Scene.toggleblenderfile_icons.load( icon, os.path.join( icons_dir, icon + ".png" ), 'IMAGE' )

def sn_unregister_icons():
    bpy.utils.previews.remove( bpy.types.Scene.toggleblenderfile_icons )


###############   REGISTER PROPERTIES
def sn_register_properties():
    bpy.types.Scene.new_property = bpy.props.BoolProperty(name='New Property',description='',options=set(),update=update_new_property,default=False)

def sn_unregister_properties():
    del bpy.types.Scene.new_property


###############   REGISTER ADDON
def register():
    sn_register_icons()
    sn_register_properties()
    bpy.utils.register_class(SNA_OT_Cleanempthys)
    bpy.utils.register_class(SNA_OT_Save)
    bpy.types.OUTLINER_HT_header.prepend(sn_prepend_menu_C642D)


###############   UNREGISTER ADDON
def unregister():
    sn_unregister_icons()
    sn_unregister_properties()
    bpy.types.OUTLINER_HT_header.remove(sn_prepend_menu_C642D)
    bpy.utils.unregister_class(SNA_OT_Save)
    bpy.utils.unregister_class(SNA_OT_Cleanempthys)