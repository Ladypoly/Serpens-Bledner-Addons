# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.
#
# This addon was created with the Serpens - Visual Scripting Addon.
# This code is generated from nodes and is not intended for manual editing.
# You can find out more about Serpens at <https://blendermarket.com/products/serpens>.


bl_info = {
    "name": "SelectFromBoundingBox",
    "description": "",
    "author": "Elin",
    "version": (1, 0, 0),
    "blender": (2, 93, 5),
    "location": "",
    "warning": "",
    "wiki_url": "",
    "tracker_url": "",
    "category": "3D View"
}


###############   IMPORTS
import bpy
from bpy.utils import previews
import os
import math
import random


###############   INITALIZE VARIABLES
selectfromboundingbox = {
    "boundingbox": None, 
    "camera": None, 
    "rotstep": 0, 
    "rotcomplete": False, 
    "count": [], 
    "cklickcount": 0, 
    "selectbyview": True, 
    "selectdone": False, 
    }


###############   SERPENS FUNCTIONS
def exec_line(line):
    exec(line)

def sn_print(tree_name, *args):
    if tree_name in bpy.data.node_groups:
        item = bpy.data.node_groups[tree_name].sn_graphs[0].prints.add()
        for arg in args:
            item.value += str(arg) + ";;;"
        if bpy.context and bpy.context.screen:
            for area in bpy.context.screen.areas:
                area.tag_redraw()
    print(*args)

def sn_cast_string(value):
    return str(value)

def sn_cast_boolean(value):
    if type(value) == tuple:
        for data in value:
            if bool(data):
                return True
        return False
    return bool(value)

def sn_cast_float(value):
    if type(value) == str:
        try:
            value = float(value)
            return value
        except:
            return float(bool(value))
    elif type(value) == tuple:
        return float(value[0])
    elif type(value) == list:
        return float(len(value))
    elif not type(value) in [float, int, bool]:
        try:
            value = len(value)
            return float(value)
        except:
            return float(bool(value))
    return float(value)

def sn_cast_int(value):
    return int(sn_cast_float(value))

def sn_cast_boolean_vector(value, size):
    if type(value) in [str, bool, int, float]:
        return_value = []
        for i in range(size):
            return_value.append(bool(value))
        return tuple(return_value)
    elif type(value) == tuple:
        return_value = []
        for i in range(size):
            return_value.append(bool(value[i]) if len(value) > i else bool(value[0]))
        return tuple(return_value)
    elif type(value) == list:
        return sn_cast_boolean_vector(tuple(value), size)
    else:
        try:
            value = tuple(value)
            return sn_cast_boolean_vector(value, size)
        except:
            return sn_cast_boolean_vector(bool(value), size)

def sn_cast_float_vector(value, size):
    if type(value) in [str, bool, int, float]:
        return_value = []
        for i in range(size):
            return_value.append(sn_cast_float(value))
        return tuple(return_value)
    elif type(value) == tuple:
        return_value = []
        for i in range(size):
            return_value.append(sn_cast_float(value[i]) if len(value) > i else sn_cast_float(value[0]))
        return tuple(return_value)
    elif type(value) == list:
        return sn_cast_float_vector(tuple(value), size)
    else:
        try:
            value = tuple(value)
            return sn_cast_float_vector(value, size)
        except:
            return sn_cast_float_vector(sn_cast_float(value), size)

def sn_cast_int_vector(value, size):
    return tuple(map(int, sn_cast_float_vector(value, size)))

def sn_cast_color(value, use_alpha):
    length = 4 if use_alpha else 3
    value = sn_cast_float_vector(value, length)
    tuple_list = []
    for data in range(length):
        data = value[data] if len(value) > data else value[0]
        tuple_list.append(sn_cast_float(min(1, max(0, data))))
    return tuple(tuple_list)

def sn_cast_list(value):
    if type(value) in [str, tuple, list]:
        return list(value)
    elif type(value) in [int, float, bool]:
        return [value]
    else:
        try:
            value = list(value)
            return value
        except:
            return [value]

def sn_cast_blend_data(value):
    if hasattr(value, "bl_rna"):
        return value
    elif type(value) in [tuple, bool, int, float, list]:
        return None
    elif type(value) == str:
        try:
            value = eval(value)
            return value
        except:
            return None
    else:
        return None

def sn_cast_enum(string, enum_values):
    for item in enum_values:
        if item[1] == string:
            return item[0]
        elif item[0] == string.upper():
            return item[0]
    return string


###############   IMPERATIVE CODE
#######   SelectFromBoundingBox
def cameracapture():
    try:
        pass # SelectFromView Script Start
        #import bpy

        def view3d_find():
            # returns first 3d view, normally we get from context
            for area in bpy.context.window.screen.areas:
                if area.type == 'VIEW_3D':
                    v3d = area.spaces[0]
                    rv3d = v3d.region_3d
                    for region in area.regions:
                        if region.type == 'WINDOW':
                            return region, rv3d
            return None, None

        def view3d_camera_border(scene):
            obj = scene.camera
            cam = obj.data
            #frame = cam.view_frame(scene)
            frame = bpy.context.scene.camera.data.view_frame(scene=bpy.context.scene)
            # move from object-space into world-space 


            frame = [obj.matrix_world @ v for v in frame]
            # move into pixelspace
            from bpy_extras.view3d_utils import location_3d_to_region_2d
            region, rv3d = view3d_find()
            #print(region, rv3d)
            frame_px = [location_3d_to_region_2d(region, rv3d, v) for v in frame]
            return frame_px
        #'''

        def getView3dAreaAndRegion(context):
            for area in context.screen.areas:
                if area.type == "VIEW_3D":
                    for region in area.regions:
                        if region.type == "WINDOW":
                            return area, region

        def select_border(context, corners, extend=False):
            bpy.ops.view3d.select_box(getOverride(context), wait_for_input=False, xmin=corners[0], xmax=corners[1], ymin=corners[2],
                    ymax=corners[3],
                    mode='ADD')
            return True

        def getOverride(context):
            view3dArea, view3dRegion = getView3dAreaAndRegion(context)
            override = context.copy()
            override['area'] = view3dArea
            override['region'] = view3dRegion
            return override

        def getCorners(cam_corners):
            '''
            returns xmin,xmax,ymin,ymax
            '''
            #print(cam_corners)
            return [cam_corners[2][0],cam_corners[0][0],cam_corners[2][1],cam_corners[0][1]]

        def doStuff():
            #print("--")
            # go to editmode
            #bpy.ops.object.mode_set(mode="EDIT")
            #bpy.ops.mesh.select_all(action='DESELECT')
            vertex, edge, face = False, False, True
            bpy.context.tool_settings.mesh_select_mode = (vertex, edge, face)
            # set camera view (both approaches do the same)
            area = next(area for area in bpy.context.screen.areas if area.type == 'VIEW_3D')
            area.spaces[0].region_3d.view_perspective = 'CAMERA'
            #bpy.ops.view3d.view_camera(getOverride(bpy.context))
            # get camera borders in view coordinates
            cam_corners = getCorners(view3d_camera_border(bpy.context.scene))
            #print(cam_corners)
            # select stuff in borders
            #print("now ready for splitting")
            select_border(bpy.context, cam_corners, extend = False)
        doStuff()
        #print("selected")
        pass # SelectFromView Script End
        selectfromboundingbox["camera"].rotation_euler=(math.radians((math.degrees(selectfromboundingbox["camera"].rotation_euler[0]) + 30.0)),selectfromboundingbox["camera"].rotation_euler[1],selectfromboundingbox["camera"].rotation_euler[2],)
        print(sn_cast_string(math.radians((math.degrees(selectfromboundingbox["camera"].rotation_euler[0]) + 30.0))))
        selectfromboundingbox["rotstep"] = int((sn_cast_float(selectfromboundingbox["rotstep"]) + 1.0))
    except Exception as exc:
        print(str(exc) + " | Error in function CameraCapture")

def cameracycle():
    try:
        if selectfromboundingbox["rotstep"] < 12:
            function_return_72BB9 = cameracapture()
        else:
            function_return_AC5BC = turncamera()
    except Exception as exc:
        print(str(exc) + " | Error in function CameraCycle")

def randomcamerapos():
    try:
        selectfromboundingbox["camera"].location=(random.uniform(min(bpy.context.scene.xminprop, bpy.context.scene.xmaxprop), max(bpy.context.scene.xminprop, bpy.context.scene.xmaxprop)),random.uniform(min(bpy.context.scene.yminprop, bpy.context.scene.ymaxprop), max(bpy.context.scene.yminprop, bpy.context.scene.ymaxprop)),random.uniform(min(bpy.context.scene.zminprop, bpy.context.scene.zmaxprop), max(bpy.context.scene.zminprop, bpy.context.scene.zmaxprop)),)
        selectfromboundingbox["camera"].rotation_euler=(math.radians(random.uniform(min(0.0, 360.0), max(0.0, 360.0))),math.radians(random.uniform(min(0.0, 360.0), max(0.0, 360.0))),math.radians(random.uniform(min(0.0, 360.0), max(0.0, 360.0))),)
        try: exec(r"bpy.ops.wm.redraw_timer(type='DRAW_WIN_SWAP', iterations=1)")
        except Exception as exc: sn_handle_script_line_exception(exc, r"bpy.ops.wm.redraw_timer(type='DRAW_WIN_SWAP', iterations=1)")
        if selectfromboundingbox["selectbyview"]:
            pass # SelectFromView Script Start
            #import bpy

            def view3d_find():
                # returns first 3d view, normally we get from context
                for area in bpy.context.window.screen.areas:
                    if area.type == 'VIEW_3D':
                        v3d = area.spaces[0]
                        rv3d = v3d.region_3d
                        for region in area.regions:
                            if region.type == 'WINDOW':
                                return region, rv3d
                return None, None

            def view3d_camera_border(scene):
                obj = scene.camera
                cam = obj.data
                #frame = cam.view_frame(scene)
                frame = bpy.context.scene.camera.data.view_frame(scene=bpy.context.scene)
                # move from object-space into world-space 


                frame = [obj.matrix_world @ v for v in frame]
                # move into pixelspace
                from bpy_extras.view3d_utils import location_3d_to_region_2d
                region, rv3d = view3d_find()
                #print(region, rv3d)
                frame_px = [location_3d_to_region_2d(region, rv3d, v) for v in frame]
                return frame_px
            #'''

            def getView3dAreaAndRegion(context):
                for area in context.screen.areas:
                    if area.type == "VIEW_3D":
                        for region in area.regions:
                            if region.type == "WINDOW":
                                return area, region

            def select_border(context, corners, extend=False):
                bpy.ops.view3d.select_box(getOverride(context), wait_for_input=False, xmin=corners[0], xmax=corners[1], ymin=corners[2],
                        ymax=corners[3],
                        mode='ADD')
                return True

            def getOverride(context):
                view3dArea, view3dRegion = getView3dAreaAndRegion(context)
                override = context.copy()
                override['area'] = view3dArea
                override['region'] = view3dRegion
                return override

            def getCorners(cam_corners):
                '''
                returns xmin,xmax,ymin,ymax
                '''
                #print(cam_corners)
                return [cam_corners[2][0],cam_corners[0][0],cam_corners[2][1],cam_corners[0][1]]

            def doStuff():
                #print("--")
                # go to editmode
                #bpy.ops.object.mode_set(mode="EDIT")
                #bpy.ops.mesh.select_all(action='DESELECT')
                vertex, edge, face = False, False, True
                bpy.context.tool_settings.mesh_select_mode = (vertex, edge, face)
                # set camera view (both approaches do the same)
                area = next(area for area in bpy.context.screen.areas if area.type == 'VIEW_3D')
                area.spaces[0].region_3d.view_perspective = 'CAMERA'
                #bpy.ops.view3d.view_camera(getOverride(bpy.context))
                # get camera borders in view coordinates
                cam_corners = getCorners(view3d_camera_border(bpy.context.scene))
                #print(cam_corners)
                # select stuff in borders
                #print("now ready for splitting")
                select_border(bpy.context, cam_corners, extend = False)
            doStuff()
            #print("selected")
            pass # SelectFromView Script End
        else:
            pass # BoxSelect Script Start
            #import bpy

            def getView3dAreaAndRegion():
                for area in bpy.context.screen.areas:
                    if area.type == "VIEW_3D":
                        for region in area.regions:
                            if region.type == "WINDOW":
                                return area, region
            view3dArea, view3dRegion = getView3dAreaAndRegion()
            override = bpy.context.copy()
            override['area'] = view3dArea
            override['region'] = view3dRegion
            #print("***** DEBUG: working") #Debug to see that the script has launched
            bpy.ops.view3d.select_box(override,xmin=0, xmax=4000, ymin=0, ymax=4000, mode='ADD', wait_for_input=False)
            bpy.ops.wm.redraw_timer(type='DRAW_WIN_SWAP', iterations=1)
            #bpy.context.scene.update()
            pass # BoxSelect Script End
    except Exception as exc:
        print(str(exc) + " | Error in function RandomCameraPos")

def sn_handle_script_line_exception(exc, line):
    print("# # # # # # # # SCRIPT LINE ERROR # # # # # # # #")
    print("Line:", line)
    raise exc

def setup():
    try:
        if bpy.context.scene.customboundingbox:
            if len(sn_cast_list(bpy.context.selected_objects)) != 0:
                pass
            else:
                bpy.ops.object.select_all('INVOKE_DEFAULT' if True else 'EXEC_DEFAULT',action=sn_cast_enum(r"DESELECT", [("TOGGLE","Toggle","Toggle selection for all elements"),("SELECT","Select","Select all elements"),("DESELECT","Deselect","Deselect all elements"),("INVERT","Invert","Invert selection of all elements"),]),)
                bpy.ops.mesh.primitive_cube_add('INVOKE_DEFAULT' if True else 'EXEC_DEFAULT',size=1.0,calc_uvs=False,enter_editmode=False,align=sn_cast_enum(r"WORLD", [("WORLD","World","Align the new object to the world"),("VIEW","View","Align the new object to the view"),("CURSOR","3D Cursor","Use the 3D cursor orientation for the new object"),]),location=(0.0, 0.0, 1.25),rotation=(0.0, 0.0, 0.0),scale=(4.5, 4.5, 2.0),)
                bpy.context.scene.customboundingbox = False
        else:
            bpy.ops.object.select_all('INVOKE_DEFAULT' if True else 'EXEC_DEFAULT',action=sn_cast_enum(r"DESELECT", [("TOGGLE","Toggle","Toggle selection for all elements"),("SELECT","Select","Select all elements"),("DESELECT","Deselect","Deselect all elements"),("INVERT","Invert","Invert selection of all elements"),]),)
            bpy.ops.mesh.primitive_cube_add('INVOKE_DEFAULT' if True else 'EXEC_DEFAULT',size=1.0,calc_uvs=False,enter_editmode=False,align=sn_cast_enum(r"WORLD", [("WORLD","World","Align the new object to the world"),("VIEW","View","Align the new object to the view"),("CURSOR","3D Cursor","Use the 3D cursor orientation for the new object"),]),location=(0.0, 0.0, 1.25),rotation=(0.0, 0.0, 0.0),scale=(4.5, 4.5, 2.0),)
        pass # Prep Script Start
        #import bpy
        boundingBox = bpy.context.active_object
        BoundingBoxLocation = boundingBox.location
        boundingBox.name = "BoundingBox"
        if bpy.context.scene.customboundingbox == False:
            #print("SelectBB")
            boundingBox.display_type = 'BOUNDS'
        ######################### get Bounds ####################
        o  = bpy.context.object  # active object
        mw = o.matrix_world      # Active object's world matrix


        glob_vertex_coordinates = [ mw @ v.co for v in o.data.vertices ] # Global 
        getmaxX = max( [ co.x for co in glob_vertex_coordinates ] ) 
        getminX = min( [ co.x for co in glob_vertex_coordinates ] ) 
        getmaxY = max( [ co.y for co in glob_vertex_coordinates ] ) 
        getminY = min( [ co.y for co in glob_vertex_coordinates ] ) 
        getmaxZ = max( [ co.z for co in glob_vertex_coordinates ] ) 
        getminZ = min( [ co.z for co in glob_vertex_coordinates ] )
        ######################### get Bounds #################### 
        bpy.context.scene.xminprop = getmaxX
        bpy.context.scene.xmaxprop = getminX
        bpy.context.scene.yminprop = getmaxY
        bpy.context.scene.ymaxprop = getminY
        bpy.context.scene.zminprop = getmaxZ
        bpy.context.scene.zmaxprop = getminZ
        #remove Box
        #bpy.ops.object.delete()
        #boundingBox.hide_set(True) 
        camera_data = bpy.data.cameras.new(name='SelectionCamera')
        camera_object = bpy.data.objects.new('SelectionCamera', camera_data)
        camera_object.location = BoundingBoxLocation
        bpy.context.scene.collection.objects.link(camera_object)
        bpy.context.scene.camera = bpy.context.scene.objects["SelectionCamera"]
        bpy.data.cameras["SelectionCamera"].lens = 10.0
        for area in bpy.context.screen.areas:
            if area.type == 'VIEW_3D':
                area.spaces[0].region_3d.view_perspective = 'CAMERA'
                break
        objects = bpy.context.scene.objects
        #for obj in objects:
        #    obj.select_set(obj.type == "MESH")
        boundingBox.select_set(False)
        pass # Prep Script End
        bpy.ops.object.select_all('INVOKE_DEFAULT' if False else 'EXEC_DEFAULT',action=sn_cast_enum(r"SELECT", [("TOGGLE","Toggle","Toggle selection for all elements"),("SELECT","Select","Select all elements"),("DESELECT","Deselect","Deselect all elements"),("INVERT","Invert","Invert selection of all elements"),]),)
        for_node_73C78 = 0
        for_node_index_73C78 = 0
        for for_node_index_73C78, for_node_73C78 in enumerate(bpy.context.selected_objects):
            if for_node_73C78.type=="MESH":
                pass
            else:
                run_function_on_CD230 = for_node_73C78.select_set(state=False, view_layer=None, )
        run_function_on_79B56 = bpy.data.objects[r"BoundingBox"].select_set(state=False, view_layer=None, )
        selectfromboundingbox["camera"] = bpy.data.objects[r"SelectionCamera"]
        bpy.context.scene.camerarot = selectfromboundingbox["camera"].rotation_euler
        bpy.context.view_layer.objects.active=sn_cast_blend_data(sn_cast_list(bpy.context.selected_objects)[0])
        selectfromboundingbox["count"] = sn_cast_list(bpy.context.selected_objects)
        try: exec(r"bpy.ops.object.mode_set(mode='EDIT')")
        except Exception as exc: sn_handle_script_line_exception(exc, r"bpy.ops.object.mode_set(mode='EDIT')")
        bpy.ops.mesh.select_all('INVOKE_DEFAULT' if True else 'EXEC_DEFAULT',action=sn_cast_enum(r"DESELECT", [("TOGGLE","Toggle","Toggle selection for all elements"),("SELECT","Select","Select all elements"),("DESELECT","Deselect","Deselect all elements"),("INVERT","Invert","Invert selection of all elements"),]),)
    except Exception as exc:
        print(str(exc) + " | Error in function Setup")

def update_select(self, context):
    if self.select == r"View":
        selectfromboundingbox["selectbyview"] = True
    else:
        selectfromboundingbox["selectbyview"] = False

def turncamera():
    try:
        if selectfromboundingbox["rotcomplete"]:
            function_return_C79A2 = randomcamerapos()
            selectfromboundingbox["rotcomplete"] = False
        else:
            selectfromboundingbox["camera"].rotation_euler=(selectfromboundingbox["camera"].rotation_euler[0],selectfromboundingbox["camera"].rotation_euler[1],math.radians((math.degrees(selectfromboundingbox["camera"].rotation_euler[2]) + 90.0)),)
            selectfromboundingbox["rotstep"] = 0
            selectfromboundingbox["rotcomplete"] = True
    except Exception as exc:
        print(str(exc) + " | Error in function TurnCamera")

def done():
    try:
        selectfromboundingbox["selectdone"] = True
    except Exception as exc:
        print(str(exc) + " | Error in function Done")


###############   EVALUATED CODE
#######   SelectFromBoundingBox
class SNA_OT_Setup(bpy.types.Operator):
    bl_idname = "sna.setup"
    bl_label = "Setup"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in execute function of Setup")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of Setup")
        return self.execute(context)


class SNA_OT_Next(bpy.types.Operator):
    bl_idname = "sna.next"
    bl_label = "Next"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in execute function of Next")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            selectfromboundingbox["cklickcount"] = 0
            function_return_026D3 = setup()
            repeat_node_39F56 = 0
            for repeat_node_39F56 in range(bpy.context.scene.selectiterations):
                function_return_26EAE = randomcamerapos()
                selectfromboundingbox["cklickcount"] = int((sn_cast_float(selectfromboundingbox["cklickcount"]) + 1.0))
                print(sn_cast_string(selectfromboundingbox["cklickcount"]))
                bpy.context.scene.selectiterationsdone = selectfromboundingbox["cklickcount"]
            function_return_F6CEC = done()
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of Next")
        return self.execute(context)


class SNA_OT_Done(bpy.types.Operator):
    bl_idname = "sna.done"
    bl_label = "Done"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in execute function of Done")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            try: exec(r"bpy.ops.wm.redraw_timer(type='DRAW_WIN_SWAP', iterations=1)")
            except Exception as exc: sn_handle_script_line_exception(exc, r"bpy.ops.wm.redraw_timer(type='DRAW_WIN_SWAP', iterations=1)")
            try: exec(r"bpy.ops.object.mode_set(mode='OBJECT')")
            except Exception as exc: sn_handle_script_line_exception(exc, r"bpy.ops.object.mode_set(mode='OBJECT')")
            pass # Done Script Start
            print("Done working")
            #dlbd = bpy.context.scene.customboundingbox
            bd = bpy.data.objects["BoundingBox"]
            bpy.ops.object.select_all(action='DESELECT')
            cam = bpy.data.objects["SelectionCamera"]
            cam.select_set(True)
            context.view_layer.objects.active = cam
            bd.hide_set(False)
            if bpy.context.scene.customboundingbox == False:
                print("SelectBB")
                bd.select_set(True)
            bpy.ops.object.delete()
            bpy.ops.outliner.orphans_purge(do_local_ids=True, do_linked_ids=True, do_recursive=True)
            pass # Done Script End
            selectfromboundingbox["selectdone"] = False
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of Done")
        return self.execute(context)


class SNA_PT_Select_from_View_Volume_E51CE(bpy.types.Panel):
    bl_label = "Select from View Volume"
    bl_idname = "SNA_PT_Select_from_View_Volume_E51CE"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = 'Quest Homes'
    bl_order = 0


    @classmethod
    def poll(cls, context):
        return True

    def draw_header(self, context):
        try:
            layout = self.layout
        except Exception as exc:
            print(str(exc) + " | Error in Select from View Volume panel header")

    def draw(self, context):
        try:
            layout = self.layout
            if selectfromboundingbox["selectdone"]:
                col = layout.column(align=True)
                col.enabled = True
                col.alert = False
                col.scale_x = 1.0
                col.scale_y = 1.5
                op = col.operator("sna.done",text=r"Done",emboss=True,depress=False,icon_value=36)
            else:
                row = layout.row(align=False)
                row.enabled = True
                row.alert = False
                row.scale_x = 1.0
                row.scale_y = 1.0
                row.prop(bpy.context.scene,'select',icon_value=0,text=r"Select",emboss=True,expand=True,)
                row = layout.row(align=True)
                row.enabled = True
                row.alert = False
                row.scale_x = 1.25
                row.scale_y = 1.0
                row.prop(bpy.context.scene,'selectiterations',text=r"Iterations",emboss=True,slider=True,)
                row = row.row(align=True)
                row.enabled = True
                row.alert = False
                row.scale_x = 2.0
                row.scale_y = 1.0
                row.prop(bpy.context.scene,'customboundingbox',icon_value=303,text=r"",emboss=True,toggle=False,invert_checkbox=False,)
                row = row.row(align=True)
                row.enabled = False
                row.alert = False
                row.scale_x = 0.5
                row.scale_y = 1.0
                row.prop(bpy.context.scene,'selectiterationsdone',text=r"",emboss=False,slider=False,)
                col = layout.column(align=True)
                col.enabled = True
                col.alert = True
                col.scale_x = 1.0
                col.scale_y = 1.5
                op = col.operator("sna.next",text=r"Select",emboss=True,depress=False,icon_value=256)
        except Exception as exc:
            print(str(exc) + " | Error in Select from View Volume panel")


###############   REGISTER ICONS
def sn_register_icons():
    icons = []
    bpy.types.Scene.selectfromboundingbox_icons = bpy.utils.previews.new()
    icons_dir = os.path.join( os.path.dirname( __file__ ), "icons" )
    for icon in icons:
        bpy.types.Scene.selectfromboundingbox_icons.load( icon, os.path.join( icons_dir, icon + ".png" ), 'IMAGE' )

def sn_unregister_icons():
    bpy.utils.previews.remove( bpy.types.Scene.selectfromboundingbox_icons )


###############   REGISTER PROPERTIES
def sn_register_properties():
    bpy.types.Scene.camerarot = bpy.props.FloatVectorProperty(name='CameraRot',description='',subtype='NONE',unit='NONE',options=set(),precision=2, default=(0.0, 0.0, 0.0),size=3)
    bpy.types.Scene.xminprop = bpy.props.FloatProperty(name='XminProp',description='',subtype='NONE',unit='NONE',options=set(),precision=2, default=0.0)
    bpy.types.Scene.xmaxprop = bpy.props.FloatProperty(name='XmaxProp',description='',subtype='NONE',unit='NONE',options=set(),precision=2, default=0.0)
    bpy.types.Scene.yminprop = bpy.props.FloatProperty(name='YminProp',description='',subtype='NONE',unit='NONE',options=set(),precision=2, default=0.0)
    bpy.types.Scene.ymaxprop = bpy.props.FloatProperty(name='YmaxProp',description='',subtype='NONE',unit='NONE',options=set(),precision=2, default=0.0)
    bpy.types.Scene.zminprop = bpy.props.FloatProperty(name='ZminProp',description='',subtype='NONE',unit='NONE',options=set(),precision=2, default=0.0)
    bpy.types.Scene.zmaxprop = bpy.props.FloatProperty(name='ZmaxProp',description='',subtype='NONE',unit='NONE',options=set(),precision=2, default=0.0)
    bpy.types.Scene.selectiterations = bpy.props.IntProperty(name='SelectIterations',description='',subtype='NONE',options=set(),default=150,min=50,max=4096)
    bpy.types.Scene.select = bpy.props.EnumProperty(name='Select',description='Select by',options=set(),update=update_select,items=[('View', 'View', 'This is my enum item'), ('Box', 'Box', 'This is my enum item')])
    bpy.types.Scene.selectiterationsdone = bpy.props.IntProperty(name='SelectIterationsDone',description='',subtype='NONE',options=set(),default=0)
    bpy.types.Scene.customboundingbox = bpy.props.BoolProperty(name='CustomBoundingBox',description='Use the active object as Bounding Box',options=set(),default=False)

def sn_unregister_properties():
    del bpy.types.Scene.camerarot
    del bpy.types.Scene.xminprop
    del bpy.types.Scene.xmaxprop
    del bpy.types.Scene.yminprop
    del bpy.types.Scene.ymaxprop
    del bpy.types.Scene.zminprop
    del bpy.types.Scene.zmaxprop
    del bpy.types.Scene.selectiterations
    del bpy.types.Scene.select
    del bpy.types.Scene.selectiterationsdone
    del bpy.types.Scene.customboundingbox


###############   REGISTER ADDON
def register():
    sn_register_icons()
    sn_register_properties()
    bpy.utils.register_class(SNA_OT_Setup)
    bpy.utils.register_class(SNA_OT_Next)
    bpy.utils.register_class(SNA_OT_Done)
    bpy.utils.register_class(SNA_PT_Select_from_View_Volume_E51CE)


###############   UNREGISTER ADDON
def unregister():
    sn_unregister_icons()
    sn_unregister_properties()
    bpy.utils.unregister_class(SNA_PT_Select_from_View_Volume_E51CE)
    bpy.utils.unregister_class(SNA_OT_Done)
    bpy.utils.unregister_class(SNA_OT_Next)
    bpy.utils.unregister_class(SNA_OT_Setup)