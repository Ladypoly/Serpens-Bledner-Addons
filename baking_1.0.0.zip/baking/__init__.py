# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.
#
# This addon was created with the Serpens - Visual Scripting Addon.
# This code is generated from nodes and is not intended for manual editing.
# You can find out more about Serpens at <https://blendermarket.com/products/serpens>.


bl_info = {
    "name": "Baking",
    "description": "",
    "author": "Quacklin",
    "version": (1, 0, 0),
    "blender": (2, 93, 0),
    "location": "",
    "warning": "",
    "wiki_url": "",
    "tracker_url": "",
    "category": "3D View"
}


###############   IMPORTS
import bpy
from bpy.utils import previews
import os
import math


###############   INITALIZE VARIABLES
###############   SERPENS FUNCTIONS
def exec_line(line):
    exec(line)

def sn_print(tree_name, *args):
    if tree_name in bpy.data.node_groups:
        item = bpy.data.node_groups[tree_name].sn_graphs[0].prints.add()
        for arg in args:
            item.value += str(arg) + ";;;"
        if bpy.context and bpy.context.screen:
            for area in bpy.context.screen.areas:
                area.tag_redraw()
    print(*args)

def sn_cast_string(value):
    return str(value)

def sn_cast_boolean(value):
    if type(value) == tuple:
        for data in value:
            if bool(data):
                return True
        return False
    return bool(value)

def sn_cast_float(value):
    if type(value) == str:
        try:
            value = float(value)
            return value
        except:
            return float(bool(value))
    elif type(value) == tuple:
        return float(value[0])
    elif type(value) == list:
        return float(len(value))
    elif not type(value) in [float, int, bool]:
        try:
            value = len(value)
            return float(value)
        except:
            return float(bool(value))
    return float(value)

def sn_cast_int(value):
    return int(sn_cast_float(value))

def sn_cast_boolean_vector(value, size):
    if type(value) in [str, bool, int, float]:
        return_value = []
        for i in range(size):
            return_value.append(bool(value))
        return tuple(return_value)
    elif type(value) == tuple:
        return_value = []
        for i in range(size):
            return_value.append(bool(value[i]) if len(value) > i else bool(value[0]))
        return tuple(return_value)
    elif type(value) == list:
        return sn_cast_boolean_vector(tuple(value), size)
    else:
        try:
            value = tuple(value)
            return sn_cast_boolean_vector(value, size)
        except:
            return sn_cast_boolean_vector(bool(value), size)

def sn_cast_float_vector(value, size):
    if type(value) in [str, bool, int, float]:
        return_value = []
        for i in range(size):
            return_value.append(sn_cast_float(value))
        return tuple(return_value)
    elif type(value) == tuple:
        return_value = []
        for i in range(size):
            return_value.append(sn_cast_float(value[i]) if len(value) > i else sn_cast_float(value[0]))
        return tuple(return_value)
    elif type(value) == list:
        return sn_cast_float_vector(tuple(value), size)
    else:
        try:
            value = tuple(value)
            return sn_cast_float_vector(value, size)
        except:
            return sn_cast_float_vector(sn_cast_float(value), size)

def sn_cast_int_vector(value, size):
    return tuple(map(int, sn_cast_float_vector(value, size)))

def sn_cast_color(value, use_alpha):
    length = 4 if use_alpha else 3
    value = sn_cast_float_vector(value, length)
    tuple_list = []
    for data in range(length):
        data = value[data] if len(value) > data else value[0]
        tuple_list.append(sn_cast_float(min(1, max(0, data))))
    return tuple(tuple_list)

def sn_cast_list(value):
    if type(value) in [str, tuple, list]:
        return list(value)
    elif type(value) in [int, float, bool]:
        return [value]
    else:
        try:
            value = list(value)
            return value
        except:
            return [value]

def sn_cast_blend_data(value):
    if hasattr(value, "bl_rna"):
        return value
    elif type(value) in [tuple, bool, int, float, list]:
        return None
    elif type(value) == str:
        try:
            value = eval(value)
            return value
        except:
            return None
    else:
        return None

def sn_cast_enum(string, enum_values):
    for item in enum_values:
        if item[1] == string:
            return item[0]
        elif item[0] == string.upper():
            return item[0]
    return string


###############   IMPERATIVE CODE
#######   Baking
def update_sampleenum(self, context):
    self.scsamples = sn_cast_int(self.sampleenum)
    print(sn_cast_string(bpy.context.scene.scsamples))

def update_resolutionenum(self, context):
    self.sresolution = sn_cast_int(self.resolutionenum)
    if bpy.context.scene.sresolution == 1024:
        bpy.context.scene.render.bake.margin = 8
    else:
        if bpy.context.scene.sresolution == 2048:
            bpy.context.scene.render.bake.margin = 16
        else:
            if bpy.context.scene.sresolution == 4096:
                bpy.context.scene.render.bake.margin = 32
            else:
                if bpy.context.scene.sresolution == 8182:
                    bpy.context.scene.render.bake.margin = 64
                else:
                    if bpy.context.scene.sresolution == 16384:
                        bpy.context.scene.render.bake.margin = 128
                    else:
                        pass
    print(sn_cast_string(bpy.context.scene.sresolution))


###############   EVALUATED CODE
#######   Baking
class SNA_PT_Baking_9303B(bpy.types.Panel):
    bl_label = "Baking"
    bl_idname = "SNA_PT_Baking_9303B"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = 'Quest Homes'
    bl_order = 0


    @classmethod
    def poll(cls, context):
        return True

    def draw_header(self, context):
        try:
            layout = self.layout
        except Exception as exc:
            print(str(exc) + " | Error in Baking panel header")

    def draw(self, context):
        try:
            layout = self.layout
            col = layout.column(align=True)
            col.enabled = True
            col.alert = False
            col.scale_x = 1.0
            col.scale_y = 1.5
            row = col.row(align=True)
            row.enabled = True
            row.alert = False
            row.scale_x = 1.0
            row.scale_y = 1.0
            row.prop(bpy.context.scene,'sselectedtoactive',icon_value=614,text=r"Selected To Active",emboss=True,toggle=True,invert_checkbox=False,)
            row.prop(bpy.context.scene,'ssetalpha',icon_value=764,text=r"Alpha",emboss=True,toggle=True,invert_checkbox=False,)
            row.prop(bpy.context.scene,'sautouv',icon_value=128,text=r"Auto UV",emboss=True,toggle=True,invert_checkbox=False,)
            row = col.row(align=True)
            row.enabled = True
            row.alert = False
            row.scale_x = 1.0
            row.scale_y = 1.0
            row.prop(bpy.context.scene,'resolutionenum',icon_value=0,text=r"ResolutionEnum",emboss=True,expand=True,)
            row = col.row(align=True)
            row.enabled = True
            row.alert = False
            row.scale_x = 1.0
            row.scale_y = 1.0
            row.prop(bpy.context.scene,'sampleenum',icon_value=0,text=r"SampleEnum",emboss=True,expand=True,)
            row.prop(bpy.context.scene,'scleanup',icon_value=182,text=r"",emboss=True,toggle=True,invert_checkbox=False,)
            row = col.row(align=True)
            row.enabled = True
            row.alert = False
            row.scale_x = 1.0
            row.scale_y = 1.0
            op = row.operator("sna.start",text=r"Baking",emboss=True,depress=False,icon_value=187)
            col = row.column(align=True)
            col.enabled = bpy.context.scene.denoise
            col.alert = False
            col.scale_x = 1.0
            col.scale_y = 1.0
            op = col.operator("sna.denoise",text=r"Denoising",emboss=True,depress=False,icon_value=0)
        except Exception as exc:
            print(str(exc) + " | Error in Baking panel")


class SNA_OT_Denoise(bpy.types.Operator):
    bl_idname = "sna.denoise"
    bl_label = "Denoise"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in execute function of Denoise")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            pass # Albedo Baking Script Start
            #Bake Albedo
            Resolution = bpy.context.scene.sresolution
            mat = bpy.context.active_object.active_material
            albedo_tex = bpy.data.images.new('Albedo_tex',Resolution,Resolution)
            texImage = mat.node_tree.nodes.new('ShaderNodeTexImage')
            texImage.location = 900,0
            texImage.select = True
            mat.node_tree.nodes.active = texImage
            texImage.name = 'DBake_node'
            texImage.image = albedo_tex
            bpy.context.scene.cycles.samples = 4    
            bpy.context.scene.render.bake.use_pass_direct = False
            bpy.context.scene.render.bake.use_pass_indirect = False
            bpy.ops.object.bake(type='DIFFUSE')   
            pass # Albedo Baking Script End
            pass # NormalBaking Script Start
            #Bake Normal
            Resolution = bpy.context.scene.sresolution
            mat = bpy.context.active_object.active_material
            normal_tex = bpy.data.images.new('Normal_tex',Resolution,Resolution)
            texImage = mat.node_tree.nodes.new('ShaderNodeTexImage')
            texImage.location = 600,0
            texImage.select = True
            mat.node_tree.nodes.active = texImage
            texImage.name = 'NBake_node'
            texImage.image = normal_tex
            bpy.context.scene.cycles.samples = 4
            bpy.ops.object.bake(type='NORMAL')
            pass # NormalBaking Script End
            pass # Alpha Bake Script Start
            #print("f04")
            Resolution = bpy.context.scene.sresolution
            SetAlpha = bpy.context.scene.ssetalpha
            if SetAlpha:
                mat = bpy.context.active_object.active_material
                alpha_tex = bpy.data.images.new('Alpha_tex',Resolution,Resolution)
                texImage = mat.node_tree.nodes.new('ShaderNodeTexImage')
                texImage.location = 1200,0
                texImage.select = True
                mat.node_tree.nodes.active = texImage
                texImage.name = 'ABake_node'
                texImage.image = alpha_tex
                bpy.context.scene.cycles.samples = 4    
                #bpy.context.scene.render.bake.use_pass_direct = False
                #bpy.context.scene.render.bake.use_pass_indirect = False
                bpy.ops.object.bake(type='GLOSSY') 
            pass # Alpha Bake Script End
            pass # Denoising Script Start
            bpy.context.scene.render.bake.use_pass_indirect = True
            bpy.context.scene.render.bake.use_pass_direct = True
            SetAlpha = bpy.context.scene.ssetalpha
            obj = bpy.context.active_object
            for mat in obj.data.materials:
                for n in mat.node_tree.nodes:
                    if n.name == 'CBake_node':
                        mat.node_tree.nodes.remove(n)
            for mat in obj.data.materials:
                for n in mat.node_tree.nodes:
                    if n.name == 'NBake_node':
                        mat.node_tree.nodes.remove(n)
            for mat in obj.data.materials:
                for n in mat.node_tree.nodes:
                    if n.name == 'DBake_node':
                        mat.node_tree.nodes.remove(n)
            for mat in obj.data.materials:
                for n in mat.node_tree.nodes:
                    if n.name == 'ABake_node':
                        mat.node_tree.nodes.remove(n)
            #######Denoising
            bpy.context.scene.use_nodes = True
            tree = bpy.context.scene.node_tree
            ###### create input image node
            Combined_node = tree.nodes.new(type='CompositorNodeImage')
            Combined_node.image = bpy.data.images[r'Combined_tex']
            Combined_node.location = -650,0
            Combined_node.name = "Combined"
            Combined_node.label = "Combined"
            Combined_node.use_custom_color = True
            Combined_node.color = (1, 0.016898, 0.005195)
            Combined_node_Reroute_01 = tree.nodes.new(type='NodeReroute')
            Combined_node_Reroute_01.location = -510,10
            Combined_node_Reroute_02 = tree.nodes.new(type='NodeReroute')
            Combined_node_Reroute_02.location = -160,10
            Combined_node_Reroute_03 = tree.nodes.new(type='NodeReroute')
            Combined_node_Reroute_03.location = -160,-87
            Normal_node = tree.nodes.new(type='CompositorNodeImage')
            Normal_node.image = bpy.data.images[r'Normal_tex']
            Normal_node.location = -500,0
            Normal_node.name = "Normal"
            Normal_node.label = "Normal"
            Normal_node.use_custom_color = True
            Normal_node.color = (0.215861, 0.215861, 1)
            Normal_node_Reroute_01 = tree.nodes.new(type='NodeReroute')
            Normal_node_Reroute_01.location = -360,0
            Normal_node_Reroute_02 = tree.nodes.new(type='NodeReroute')
            Normal_node_Reroute_02.location = -175,0
            Normal_node_Reroute_03 = tree.nodes.new(type='NodeReroute')
            Normal_node_Reroute_03.location = -175,-109
            Albedo_node = tree.nodes.new(type='CompositorNodeImage')
            Albedo_node.image = bpy.data.images[r'Albedo_tex']
            Albedo_node.location = -350,0
            Albedo_node.name = "Albedo"
            Albedo_node.label = "Albedo"
            Albedo_node.use_custom_color = True
            Albedo_node.color = (1, 1, 1)
            Albedo_node_Reroute_01 = tree.nodes.new(type='NodeReroute')
            Albedo_node_Reroute_01.location = -190,-35
            Albedo_node_Reroute_02 = tree.nodes.new(type='NodeReroute')
            Albedo_node_Reroute_02.location = -190,-130
            Denoise_node = tree.nodes.new(type='CompositorNodeDenoise')
            Denoise_node.location = -150,0
            Denoise_node.name = "Denoise"
            Denoise_node.label = "Denoise"
            OutputFile_node = tree.nodes.new(type='CompositorNodeOutputFile')
            bpy.context.scene.node_tree.nodes.active = OutputFile_node
            OutputFile_node.location = 50,0
            OutputFile_node.use_custom_color = True
            OutputFile_node.color = (0, 1, 0)
            OutputFile_node.base_path = "//"
            if SetAlpha:
                OutputFile_node.format.file_format = "PNG"
                OutputFile_node.format.color_mode = "RGBA"
            else:
                OutputFile_node.format.file_format = "JPEG"
                OutputFile_node.format.color_mode = "RGB"
            OutputPath = bpy.context.active_object.name+"_baked"
            #OutputPath = Name 
            OutputFile_node.layer_slots.new(OutputPath)
            ######Alpha
            if SetAlpha:
                Alpha_node = tree.nodes.new(type='CompositorNodeImage')
                Alpha_node.image = bpy.data.images[r'Alpha_tex']
                Alpha_node.location = -800,0
                Alpha_node.name = "Alpha"
                Alpha_node.label = "Alpha"
                Alpha_node_Reroute_01 = tree.nodes.new(type='NodeReroute')
                Alpha_node_Reroute_01.location = -660,-300
                Alpha_node_Reroute_02 = tree.nodes.new(type='NodeReroute')
                Alpha_node_Reroute_02.location = -180,-300
                Alpha_node_Reroute_03 = tree.nodes.new(type='NodeReroute')
                Alpha_node_Reroute_03.location = -180,-257
                SetAlpha_node = tree.nodes.new(type='CompositorNodeSetAlpha')
                SetAlpha_node.location = -150,-150
                SetAlpha_node.name = "SetAlpha"
                SetAlpha_node.label = "SetAlpha"
                SetAlpha_node.mode = 'REPLACE_ALPHA'
                SetAlpha_node_Reroute_01 = tree.nodes.new(type='NodeReroute')
                SetAlpha_node_Reroute_01.location = 20,-185
                SetAlpha_node_Reroute_02 = tree.nodes.new(type='NodeReroute')
                SetAlpha_node_Reroute_02.location = 20,-105
                Denoise_node_Reroute_01 = tree.nodes.new(type='NodeReroute')
                Denoise_node_Reroute_01.location = -10,-150
                Denoise_node_Reroute_02 = tree.nodes.new(type='NodeReroute')
                Denoise_node_Reroute_02.location = -180,-150
                Denoise_node_Reroute_03 = tree.nodes.new(type='NodeReroute')
                Denoise_node_Reroute_03.location = -180,-235
            else:
                Denoise_node_Reroute_01 = tree.nodes.new(type='NodeReroute')
                Denoise_node_Reroute_01.location = 15,-35
                Denoise_node_Reroute_02 = tree.nodes.new(type='NodeReroute')
                Denoise_node_Reroute_02.location = 15,-105
            ####### link nodes
            links = tree.links
            #Combined Links    
            links.new(Combined_node.outputs[0], Combined_node_Reroute_01.inputs[0])    
            links.new(Combined_node_Reroute_01.outputs[0], Combined_node_Reroute_02.inputs[0])    
            links.new(Combined_node_Reroute_02.outputs[0], Combined_node_Reroute_03.inputs[0])    
            links.new(Combined_node_Reroute_03.outputs[0], Denoise_node.inputs[0])    
            #Normal Links    
            links.new(Normal_node.outputs[0], Normal_node_Reroute_01.inputs[0])    
            links.new(Normal_node_Reroute_01.outputs[0], Normal_node_Reroute_02.inputs[0])    
            links.new(Normal_node_Reroute_02.outputs[0], Normal_node_Reroute_03.inputs[0])    
            links.new(Normal_node_Reroute_03.outputs[0], Denoise_node.inputs[1])  
            #Albedo Links
            links.new(Albedo_node.outputs[0], Albedo_node_Reroute_01.inputs[0])    
            links.new(Albedo_node_Reroute_01.outputs[0], Albedo_node_Reroute_02.inputs[0])    
            links.new(Albedo_node_Reroute_02.outputs[0], Denoise_node.inputs[2])  
            if SetAlpha:
                links.new(Alpha_node.outputs[0], Alpha_node_Reroute_01.inputs[0])
                links.new(Alpha_node_Reroute_01.outputs[0], Alpha_node_Reroute_02.inputs[0])
                links.new(Alpha_node_Reroute_02.outputs[0], Alpha_node_Reroute_03.inputs[0])
                link = links.new(Alpha_node_Reroute_03.outputs[0], SetAlpha_node.inputs[1])
                link = links.new(Denoise_node.outputs[0], Denoise_node_Reroute_01.inputs[0])
                link = links.new(Denoise_node_Reroute_01.outputs[0], Denoise_node_Reroute_02.inputs[0])
                link = links.new(Denoise_node_Reroute_02.outputs[0], Denoise_node_Reroute_03.inputs[0])
                link = links.new(Denoise_node_Reroute_03.outputs[0], SetAlpha_node.inputs[0])
                link = links.new(SetAlpha_node.outputs[0], SetAlpha_node_Reroute_01.inputs[0])
                link = links.new(SetAlpha_node_Reroute_01.outputs[0], SetAlpha_node_Reroute_02.inputs[0])
                link = links.new(SetAlpha_node_Reroute_02.outputs[0], OutputFile_node.inputs[1])
            else:
                link = links.new(Denoise_node.outputs[0], Denoise_node_Reroute_01.inputs[0])     
                link = links.new(Denoise_node_Reroute_01.outputs[0], Denoise_node_Reroute_02.inputs[0])
                link = links.new(Denoise_node_Reroute_02.outputs[0], OutputFile_node.inputs[1])
            ######ForceComp Update
            bpy.ops.render.render(animation=False, write_still=False, use_viewport=False, layer="", scene="")   
            #time.sleep(sleep)
            pass # Denoising Script End
            pass # LoadTexture Script Start
            #Save and Reload
            #    cleanup = bpy.context.scene.cleanup
            #    HasAlpha = bpy.context.scene.hasalpha
            SetAlpha = bpy.context.scene.ssetalpha
            cleanup = bpy.context.scene.scleanup
            mat = bpy.context.active_object.active_material
            #get the nodes
            #mat.use_nodes = True
            nodes = mat.node_tree.nodes
            #loadedtexturename = bpy.context.scene.texoutputpath
            # get some specific node:
            # returns None if the node does not exist
            ImageTexture_Node = nodes.get("Image Texture")
            #    if mat.use_nodes:
            #        ntree = mat.node_tree
            #        node = ntree.nodes.get("Image Texture", None)
            #        if node is not None:
            #            node_to_delete =  mat.node_tree.nodes['Image Texture']
            #            ImageTexture_Node = mat.node_tree.nodes.new('ShaderNodeTexImage') 
            #        else:
            #            ImageTexture_Node = nodes.get("Image Texture") 
            ImageTexture_Node = mat.node_tree.nodes.new('ShaderNodeTexImage')
            ImageTexture_Node.location = -300,240
            #texImage = mat.node_tree.nodes.new('ShaderNodeTexImage')
            OutputPath = bpy.context.active_object.name+"_baked"
            if SetAlpha:
                ImageTexture_Node.image = bpy.data.images.load("//"+OutputPath+"0000"+".png")
                bsdf = nodes.get("Principled BSDF")
                bsdf.inputs[5].default_value = 0
                bsdf.inputs[7].default_value = 1
                mat.node_tree.links.new(bsdf.inputs['Base Color'], ImageTexture_Node.outputs['Color'])
                mat.node_tree.links.new(bsdf.inputs['Alpha'], ImageTexture_Node.outputs['Alpha'])
                bpy.context.object.active_material.blend_method = 'BLEND'
                bpy.context.object.active_material.shadow_method = 'HASHED'
            else:
                ImageTexture_Node.image = bpy.data.images.load("//"+OutputPath+"0000"+".jpg")
                bsdf = nodes.get("Principled BSDF")
                bsdf.inputs[5].default_value = 0
                bsdf.inputs[7].default_value = 1
                mat.node_tree.links.new(bsdf.inputs['Base Color'], ImageTexture_Node.outputs['Color'])
            if cleanup:
                bpy.context.scene.use_nodes = True
                tree = bpy.context.scene.node_tree
                # clear default nodes
                for node in tree.nodes:
                    tree.nodes.remove(node)
                bpy.ops.outliner.orphans_purge(do_local_ids=True, do_linked_ids=True, do_recursive=True)
            pass # LoadTexture Script End
            bpy.context.scene.denoise = False
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of Denoise")
        return self.execute(context)


class SNA_OT_Start(bpy.types.Operator):
    bl_idname = "sna.start"
    bl_label = "Start"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in execute function of Start")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            pass # PreBake Script Start
            SelectedToActive = bpy.context.scene.sselectedtoactive
            autoUV = bpy.context.scene.sautouv
            ob = bpy.context.active_object
            for x in ob.material_slots: #For all of the materials in the selected object:
                ob.active_material_index = 0 #select the top material
                bpy.ops.object.material_slot_remove() #delete it
            mat = bpy.data.materials.new(name=ob.name+"_Baked")
            bpy.context.scene.use_nodes = True
            tree = bpy.context.scene.node_tree
            # Assign it to object
            if ob.data.materials:
                # assign to 1st material slot
                ob.data.materials[0] = mat
            else:
                # no slots
                ob.data.materials.append(mat)
            if SelectedToActive:
                bpy.context.scene.render.bake.use_selected_to_active = True
            else:
                bpy.context.scene.render.bake.use_selected_to_active = False
            for node in tree.nodes:
                tree.nodes.remove(node)
            bpy.ops.outliner.orphans_purge(do_local_ids=True, do_linked_ids=True, do_recursive=True)
            if autoUV:
                bpy.ops.object.editmode_toggle()
                bpy.ops.mesh.select_all(action='SELECT')
                bpy.ops.uv.smart_project()
                bpy.ops.uvpackmaster2.uv_pack()
                bpy.ops.object.editmode_toggle()
            pass # PreBake Script End
            pass # combined baking Script Start
            mat = bpy.context.active_object.active_material
            mat.use_nodes = True
            nodes = mat.node_tree.nodes
            Resolution = bpy.context.scene.sresolution
            CSamples = bpy.context.scene.scsamples
            bpy.context.scene.render.bake.use_pass_direct = True
            bpy.context.scene.render.bake.use_pass_indirect = True
            combined_tex = bpy.data.images.new('Combined_tex',Resolution,Resolution)
            texImage = mat.node_tree.nodes.new('ShaderNodeTexImage')
            texImage.location = -300,240
            texImage.select = True
            mat.node_tree.nodes.active = texImage
            texImage.name = 'CBake_node'
            texImage.image = combined_tex
            bpy.context.scene.cycles.samples = CSamples
            bsdf = nodes.get("Principled BSDF")
            mat.node_tree.links.new(bsdf.inputs['Base Color'], texImage.outputs['Color'])
            #bpy.ops.object.bake(type='COMBINED') 
            pass # combined baking Script End
            bpy.ops.object.bake('INVOKE_DEFAULT' if True else 'EXEC_DEFAULT',type=sn_cast_enum(r"COMBINED", [("COMBINED","Combined",""),("AO","Ambient Occlusion",""),("SHADOW","Shadow",""),("NORMAL","Normal",""),("UV","UV",""),("ROUGHNESS","ROUGHNESS",""),("EMIT","Emit",""),("ENVIRONMENT","Environment",""),("DIFFUSE","Diffuse",""),("GLOSSY","Glossy",""),("TRANSMISSION","Transmission",""),]),use_selected_to_active=bpy.context.scene.sselectedtoactive,)
            bpy.context.scene.denoise = True
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of Start")
        return self.execute(context)


###############   REGISTER ICONS
def sn_register_icons():
    icons = []
    bpy.types.Scene.baking_icons = bpy.utils.previews.new()
    icons_dir = os.path.join( os.path.dirname( __file__ ), "icons" )
    for icon in icons:
        bpy.types.Scene.baking_icons.load( icon, os.path.join( icons_dir, icon + ".png" ), 'IMAGE' )

def sn_unregister_icons():
    bpy.utils.previews.remove( bpy.types.Scene.baking_icons )


###############   REGISTER PROPERTIES
def sn_register_properties():
    bpy.types.Scene.sresolution = bpy.props.IntProperty(name='sResolution',description='',subtype='NONE',options=set(),default=0)
    bpy.types.Scene.scsamples = bpy.props.IntProperty(name='sCSamples',description='',subtype='NONE',options=set(),default=0)
    bpy.types.Scene.ssetalpha = bpy.props.BoolProperty(name='sSetAlpha',description='',options=set(),default=False)
    bpy.types.Scene.sselectedtoactive = bpy.props.BoolProperty(name='sSelectedToActive',description='',options=set(),default=True)
    bpy.types.Scene.scleanup = bpy.props.BoolProperty(name='scleanup',description='',options=set(),default=True)
    bpy.types.Scene.sautouv = bpy.props.BoolProperty(name='sautoUV',description='',options=set(),default=False)
    bpy.types.Scene.margin = bpy.props.IntProperty(name='Margin',description='',subtype='NONE',options=set(),default=0)
    bpy.types.Scene.resolutionenum = bpy.props.EnumProperty(name='ResolutionEnum',description='',options=set(),update=update_resolutionenum,items=[('1024', '1024', 'This is my enum item'), ('2048', '2048', 'This is my enum item'), ('4096', '4096', 'This is my enum item'), ('8192', '8192', 'This is my enum item'), ('16384', '16384', 'This is my enum item')])
    bpy.types.Scene.sampleenum = bpy.props.EnumProperty(name='SampleEnum',description='',options=set(),update=update_sampleenum,items=[('2', '2', 'This is my enum item'), ('32', '32', 'This is my enum item'), ('64', '64', 'This is my enum item'), ('128', '128', 'This is my enum item')])
    bpy.types.Scene.denoise = bpy.props.BoolProperty(name='Denoise',description='',options=set(),default=False)

def sn_unregister_properties():
    del bpy.types.Scene.sresolution
    del bpy.types.Scene.scsamples
    del bpy.types.Scene.ssetalpha
    del bpy.types.Scene.sselectedtoactive
    del bpy.types.Scene.scleanup
    del bpy.types.Scene.sautouv
    del bpy.types.Scene.margin
    del bpy.types.Scene.resolutionenum
    del bpy.types.Scene.sampleenum
    del bpy.types.Scene.denoise


###############   REGISTER ADDON
def register():
    sn_register_icons()
    sn_register_properties()
    bpy.utils.register_class(SNA_PT_Baking_9303B)
    bpy.utils.register_class(SNA_OT_Denoise)
    bpy.utils.register_class(SNA_OT_Start)


###############   UNREGISTER ADDON
def unregister():
    sn_unregister_icons()
    sn_unregister_properties()
    bpy.utils.unregister_class(SNA_OT_Start)
    bpy.utils.unregister_class(SNA_OT_Denoise)
    bpy.utils.unregister_class(SNA_PT_Baking_9303B)