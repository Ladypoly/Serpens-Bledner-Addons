# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.
#
# This addon was created with the Serpens - Visual Scripting Addon.
# This code is generated from nodes and is not intended for manual editing.
# You can find out more about Serpens at <https://blendermarket.com/products/serpens>.


bl_info = {
    "name": "Agilent - Stack builder",
    "description": "",
    "author": "Creapolis",
    "version": (1, 0, 1),
    "blender": (2, 93, 0),
    "location": "Properties Panel -> Agilent",
    "warning": "",
    "wiki_url": "",
    "tracker_url": "",
    "category": "3D View"
}


###############   IMPORTS
import bpy
from bpy.utils import previews
import os
import math


###############   INITALIZE VARIABLES
###############   SERPENS FUNCTIONS
def exec_line(line):
    exec(line)

def sn_print(tree_name, *args):
    if tree_name in bpy.data.node_groups:
        item = bpy.data.node_groups[tree_name].sn_graphs[0].prints.add()
        for arg in args:
            item.value += str(arg) + ";;;"
        if bpy.context and bpy.context.screen:
            for area in bpy.context.screen.areas:
                area.tag_redraw()
    print(*args)

def sn_cast_string(value):
    return str(value)

def sn_cast_boolean(value):
    if type(value) == tuple:
        for data in value:
            if bool(data):
                return True
        return False
    return bool(value)

def sn_cast_float(value):
    if type(value) == str:
        try:
            value = float(value)
            return value
        except:
            return float(bool(value))
    elif type(value) == tuple:
        return float(value[0])
    elif type(value) == list:
        return float(len(value))
    elif not type(value) in [float, int, bool]:
        try:
            value = len(value)
            return float(value)
        except:
            return float(bool(value))
    return float(value)

def sn_cast_int(value):
    return int(sn_cast_float(value))

def sn_cast_boolean_vector(value, size):
    if type(value) in [str, bool, int, float]:
        return_value = []
        for i in range(size):
            return_value.append(bool(value))
        return tuple(return_value)
    elif type(value) == tuple:
        return_value = []
        for i in range(size):
            return_value.append(bool(value[i]) if len(value) > i else bool(value[0]))
        return tuple(return_value)
    elif type(value) == list:
        return sn_cast_boolean_vector(tuple(value), size)
    else:
        try:
            value = tuple(value)
            return sn_cast_boolean_vector(value, size)
        except:
            return sn_cast_boolean_vector(bool(value), size)

def sn_cast_float_vector(value, size):
    if type(value) in [str, bool, int, float]:
        return_value = []
        for i in range(size):
            return_value.append(sn_cast_float(value))
        return tuple(return_value)
    elif type(value) == tuple:
        return_value = []
        for i in range(size):
            return_value.append(sn_cast_float(value[i]) if len(value) > i else sn_cast_float(value[0]))
        return tuple(return_value)
    elif type(value) == list:
        return sn_cast_float_vector(tuple(value), size)
    else:
        try:
            value = tuple(value)
            return sn_cast_float_vector(value, size)
        except:
            return sn_cast_float_vector(sn_cast_float(value), size)

def sn_cast_int_vector(value, size):
    return tuple(map(int, sn_cast_float_vector(value, size)))

def sn_cast_color(value, use_alpha):
    length = 4 if use_alpha else 3
    value = sn_cast_float_vector(value, length)
    tuple_list = []
    for data in range(length):
        data = value[data] if len(value) > data else value[0]
        tuple_list.append(sn_cast_float(min(1, max(0, data))))
    return tuple(tuple_list)

def sn_cast_list(value):
    if type(value) in [str, tuple, list]:
        return list(value)
    elif type(value) in [int, float, bool]:
        return [value]
    else:
        try:
            value = list(value)
            return value
        except:
            return [value]

def sn_cast_blend_data(value):
    if hasattr(value, "bl_rna"):
        return value
    elif type(value) in [tuple, bool, int, float, list]:
        return None
    elif type(value) == str:
        try:
            value = eval(value)
            return value
        except:
            return None
    else:
        return None

def sn_cast_enum(string, enum_values):
    for item in enum_values:
        if item[1] == string:
            return item[0]
        elif item[0] == string.upper():
            return item[0]
    return string


###############   IMPERATIVE CODE
###############   EVALUATED CODE
#######   Agilent - Stack builder
class SNA_PT_Stack_Builder_B0816(bpy.types.Panel):
    bl_label = "Stack Builder"
    bl_idname = "SNA_PT_Stack_Builder_B0816"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = 'Agilent'
    bl_order = 0


    @classmethod
    def poll(cls, context):
        return True

    def draw_header(self, context):
        try:
            layout = self.layout
            layout.label(text=r"",icon_value=bpy.context.scene.agilent__stack_builder_icons['STACK64'].icon_id)
        except Exception as exc:
            print(str(exc) + " | Error in Stack Builder panel header")

    def draw(self, context):
        try:
            layout = self.layout
            col = layout.column(align=False)
            col.enabled = True
            col.alert = False
            col.scale_x = 1.0
            col.scale_y = 1.0
            col.label(text=r"Instrument:",icon_value=727)
            col = col.column(align=True)
            col.enabled = True
            col.alert = not sn_cast_boolean(sn_cast_blend_data(bpy.context.scene).instrument)
            col.scale_x = 1.0
            col.scale_y = 1.0
            col.prop(sn_cast_blend_data(bpy.context.scene),'instrument',icon_value=0,text=r"",emboss=True,)
            col.separator(factor=1.0)
            if sn_cast_boolean(sn_cast_blend_data(bpy.context.scene).instrument):
                col = col.column(align=True)
                col.enabled = True
                col.alert = False
                col.scale_x = 1.0
                col.scale_y = 1.0
                col.label(text=r"Setups:",icon_value=181)
                col.prop(sn_cast_blend_data(bpy.context.scene),'setupcount',text=r"SetupCount",emboss=True,slider=False,)
                if sn_cast_blend_data(bpy.context.scene).setupcount > 0:
                    col.prop(sn_cast_blend_data(bpy.context.scene),'setup01',icon_value=0,text=r"Setup 1",emboss=True,)
                    if sn_cast_blend_data(bpy.context.scene).setupcount > 1:
                        col.prop(sn_cast_blend_data(bpy.context.scene),'setup02',icon_value=0,text=r"Setup 2",emboss=True,)
                        if sn_cast_blend_data(bpy.context.scene).setupcount > 2:
                            col.prop(sn_cast_blend_data(bpy.context.scene),'setup03',icon_value=0,text=r"Setup 3",emboss=True,)
                            if sn_cast_blend_data(bpy.context.scene).setupcount > 3:
                                col.prop(sn_cast_blend_data(bpy.context.scene),'setup04',icon_value=0,text=r"Setup 4",emboss=True,)
                                if sn_cast_blend_data(bpy.context.scene).setupcount > 4:
                                    col.prop(sn_cast_blend_data(bpy.context.scene),'setup05',icon_value=0,text=r"Setup 5",emboss=True,)
                                    if sn_cast_blend_data(bpy.context.scene).setupcount > 5:
                                        col.prop(sn_cast_blend_data(bpy.context.scene),'setup06',icon_value=0,text=r"Setup 6",emboss=True,)
                                        if sn_cast_blend_data(bpy.context.scene).setupcount == 6:
                                            pass
                                        else:
                                            pass
                                    else:
                                        pass
                                else:
                                    pass
                            else:
                                pass
                        else:
                            pass
                    else:
                        pass
                else:
                    pass
                col = col.column(align=True)
                col.enabled = True
                col.alert = False
                col.scale_x = 1.0
                col.scale_y = 1.5
                op = col.operator("sna.loadsystem",text=r"Load System",emboss=True,depress=False,icon_value=444)
            else:
                pass
        except Exception as exc:
            print(str(exc) + " | Error in Stack Builder panel")


class SNA_OT_Loadsystem(bpy.types.Operator):
    bl_idname = "sna.loadsystem"
    bl_label = "LoadSystem"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in execute function of LoadSystem")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            sn_cast_blend_data(bpy.context.scene).instrument = bpy.path.abspath(sn_cast_blend_data(bpy.context.scene).instrument)
            sn_cast_blend_data(bpy.context.scene).setup01 = bpy.path.abspath(sn_cast_blend_data(bpy.context.scene).setup01)
            sn_cast_blend_data(bpy.context.scene).setup02 = bpy.path.abspath(sn_cast_blend_data(bpy.context.scene).setup02)
            sn_cast_blend_data(bpy.context.scene).setup03 = bpy.path.abspath(sn_cast_blend_data(bpy.context.scene).setup03)
            sn_cast_blend_data(bpy.context.scene).setup04 = bpy.path.abspath(sn_cast_blend_data(bpy.context.scene).setup04)
            sn_cast_blend_data(bpy.context.scene).setup05 = bpy.path.abspath(sn_cast_blend_data(bpy.context.scene).setup05)
            sn_cast_blend_data(bpy.context.scene).setup05 = bpy.path.abspath(sn_cast_blend_data(bpy.context.scene).setup06)
            pass # BuildStack Script Start


            class SNA_OT_Buildsystem(bpy.types.Operator):
                bl_idname = "sna.buildsystem"
                bl_label = "BuildSystem"
                bl_description = ""
                bl_options = {"REGISTER", "UNDO"}

                def agilent_load_file(myfile):
                    print("Loading File: " + str(myfile))
                    #bpy.ops.wm.append(filepath=selectedModulePath, autoselect=False)
                    with bpy.data.libraries.load(myfile) as (data_from, data_to):
                        files = []
                        for obj in data_from.objects:
                            files.append({'name' : obj})
                        bpy.ops.wm.append(directory=myfile+'\\Object\\', files=files, autoselect=True)

                def load_instrument(instrumentPath):
                    print("Loading Instrument...")
                    returnDummies = []
                    if os.path.exists(instrumentPath):
                        print("Instrument File exist check passed. Appending to scene now:")
                        SNA_OT_Buildsystem.agilent_load_file(instrumentPath)
                        # now we search for the main dummy of appended instrument
                        SEL_OBJS = bpy.context.selected_objects
                        for _obj in SEL_OBJS:
                            hasMain = _obj.name.find("Main")
                            hasSecondTop = _obj.name.find("Second_Top")
                            if hasMain > 0:
                                #print("Found Main Dummy in merged objects: " + _obj.name)
                                returnDummies.append(_obj)
                                #bpy.ops.object.select_all(action='DESELECT')
                            elif hasSecondTop > 0:
                                returnDummies.append(_obj)
                        bpy.ops.object.select_all(action='DESELECT')
                        return returnDummies
                    else:
                        print("Error - Instrument file does not exist!")
                        bpy.ops.object.select_all(action='DESELECT')
                        return False

                def load_setups(setupsPathArray):
                    print("Loading Setups...")
                    mainDummiesVar = []
                    for setup in setupsPathArray:
                        SNA_OT_Buildsystem.agilent_load_file(setup)
                        SEL_OBJS = bpy.context.selected_objects
                        #print("Selceted objects count: " + str(len(SEL_OBJS)) + ">")
                        for _obj in SEL_OBJS:
                            #print("iterating obj: " + _obj.name)
                            hasMain = _obj.name.find("Main")
                            hasDummy = _obj.name.find("Dummy_")
                            if hasMain > 0:
                                #print("Found Main Dummy in merged objects: " + _obj.name)
                                #bpy.ops.object.select_all(action='DESELECT')
                                mainDummiesVar.append(_obj)
                            elif hasDummy >= 0:
                                #print("Found Dummy_ in merged object: " + _obj.name)
                                #bpy.ops.object.select_all(action='DESELECT')
                                mainDummiesVar.append(_obj)
                    return mainDummiesVar

                def main_func():
                    print("_--------------------------------------------------------------------------_")
                    print("Building Module! with: " + bpy.context.scene.instrument)
                    # check if second Top Dummy is Selectend
                    beforeScriptObjects = bpy.context.active_object
                    beforeScriptDummy = beforeScriptObjects
            #        for obi in beforeScriptObjects:
            #            if obi.name.find("Second_Top") > 0:
            #                beforeScriptDummy = obi
                    if beforeScriptDummy != None:
                        print("<<<<<<<<<<<< Second Top Dummy selected to move to: " + beforeScriptDummy.name)
                    else:
                        print("<<<<<<<<<<<< No Second Top Dummy or selected dummy Found, creating at 0,0,0")
                    # Deselect all objects after looking for second top dummy
                    bpy.ops.object.select_all(action='DESELECT')
                    bpy.context.view_layer.objects.active = None
                    # first create new Main Dummy for Instrument AND Setup:
                    bpy.ops.object.empty_add(type='PLAIN_AXES', align='WORLD', location=(0, 0, 0), scale=(1, 1, 1))
                    SEL_OBJS = bpy.context.selected_objects
                    createdEmpty = SEL_OBJS[0]
                    temp = bpy.context.scene.instrument.split("\\")
                    withExt = temp[len(temp)-1]
                    theNameOnly = (withExt.split("."))[0]
                    createdEmpty.name = theNameOnly
                    # initialize dummies array
                    array_Main_Dummies = []
                    array_instrument_Dummy = []
                    # safe second Top
                    secondTopDummy = ""
                    # first we load the instrument
                    instrumentMainDummy = SNA_OT_Buildsystem.load_instrument(bpy.context.scene.instrument)
                    # append main dummy of instrument
                    array_instrument_Dummy = instrumentMainDummy
                    bpy.ops.object.select_all(action='DESELECT')
                    createdEmpty.select_set(True)
                    bpy.context.view_layer.objects.active = createdEmpty
                    # link instrument main dummy to new helpr dummy
                    for dum in array_instrument_Dummy:
                        dum.select_set(True)
                        #dum.parent = createdEmpty
                        bpy.ops.object.parent_set(type='OBJECT', keep_transform=True)
                        dum.select_set(False)
                        #dum.matrix_parent_inverse = createdEmpty.matrix_world.inverted()
                        if dum.name.find("Second") > 0:
                            print("Saved Second Top Dummy" + dum.name)
                            secondTopDummy = dum
                    #instrumentMainDummy.parent = createdEmpty
                    #instrumentMainDummy.matrix_parent_inverse = createdEmpty.matrix_world.inverted()
                    #return True
                    # create array of choosen setups
                    setupsArray = []
                    print("There are " + str(bpy.context.scene.setupcount) + " Setups choosen. Validating....")
                    #for setup in setupsArray
                    for i in range(bpy.context.scene.setupcount):
                        sNameBase = "setup0"
                        try:
                            _cSetup = bpy.context.scene[(sNameBase + str(i+1))]
                            print(_cSetup)
                            if os.path.exists(_cSetup):
                                #print(_cSetup + " --- EXISTS!")
                                setupsArray.append(_cSetup)
                                bpy.context.scene[(sNameBase + str(i+1))] = ""
                        except Exception as exc:
                            print("Catched error")
                    print("Validated Setups. " + str(len(setupsArray)) + " valid setup files found")
                    # now load the setups
                    setupsDummies = SNA_OT_Buildsystem.load_setups(setupsArray)
                    # append main dummies of setups
                    for dX in setupsDummies:
                        array_Main_Dummies.append(dX)
                    # Deselect all objects
                    bpy.ops.object.select_all(action='DESELECT')
                    createdEmpty.select_set(True)
                    bpy.context.view_layer.objects.active = createdEmpty
                    # finally select all main Dummies
                    #print(array_Main_Dummies)
                    for dum in array_Main_Dummies:            
                        dum.select_set(True)
                        if dum.parent == None:
                            bpy.ops.object.parent_set(type='OBJECT', keep_transform=True)
                    bpy.context.scene.setupcount = 0
                    bpy. context.scene.instrument = ""
                    bpy.ops.object.select_all(action='DESELECT')
                    if beforeScriptDummy != None:
                        # first we need to duplicate it
                        beforeScriptDummy.select_set(True)
                        bpy.ops.object.duplicate()
                        clonedDum = bpy.context.selected_objects[0]
                        bpy.ops.object.select_all(action='DESELECT')
                        clonedDum.select_set(True)
                        bpy.ops.object.parent_clear(type='CLEAR_KEEP_TRANSFORM')
                        #bpy.ops.object.parent_set(type='OBJECT', keep_transform=True)
                        createdEmpty.location = clonedDum.location
                    bpy.ops.object.select_all(action='DESELECT')
                    secondTopDummy.select_set(True)
                    bpy.context.view_layer.objects.active = secondTopDummy


                @classmethod
                def poll(cls, context):
                    return True

                def execute(self, context):
                    try:
                        pass
                    except Exception as exc:
                        print(str(exc) + " | Error in execute function of BuildSystem")
                    return {"FINISHED"}

                def invoke(self, context, event):
                    try:
                        print("Lets Go")
                        print(bpy.context.scene.instrument)
                        SNA_OT_Buildsystem.main_func()
                        print("done")
                    except Exception as exc:
                        print(str(exc) + " | Error in invoke function of BuildSystem")
                    return self.execute(context)
            SNA_OT_Buildsystem.main_func()
            pass # BuildStack Script End
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of LoadSystem")
        return self.execute(context)


###############   REGISTER ICONS
def sn_register_icons():
    icons = ["STACK64",]
    bpy.types.Scene.agilent__stack_builder_icons = bpy.utils.previews.new()
    icons_dir = os.path.join( os.path.dirname( __file__ ), "icons" )
    for icon in icons:
        bpy.types.Scene.agilent__stack_builder_icons.load( icon, os.path.join( icons_dir, icon + ".png" ), 'IMAGE' )

def sn_unregister_icons():
    bpy.utils.previews.remove( bpy.types.Scene.agilent__stack_builder_icons )


###############   REGISTER PROPERTIES
def sn_register_properties():
    bpy.types.Scene.instrument = bpy.props.StringProperty(name='Instrument',description='',subtype='FILE_PATH',options=set(),default='')
    bpy.types.Scene.setupcount = bpy.props.IntProperty(name='SetupCount',description='',subtype='NONE',options=set(),default=1,min=0,max=6)
    bpy.types.Scene.setup01 = bpy.props.StringProperty(name='Setup01',description='',subtype='FILE_PATH',options=set(),default='')
    bpy.types.Scene.setup02 = bpy.props.StringProperty(name='Setup02',description='',subtype='FILE_PATH',options=set(),default='')
    bpy.types.Scene.setup03 = bpy.props.StringProperty(name='Setup03',description='',subtype='FILE_PATH',options=set(),default='')
    bpy.types.Scene.setup04 = bpy.props.StringProperty(name='Setup04',description='',subtype='FILE_PATH',options=set(),default='')
    bpy.types.Scene.setup05 = bpy.props.StringProperty(name='Setup05',description='',subtype='FILE_PATH',options=set(),default='')
    bpy.types.Scene.setup06 = bpy.props.StringProperty(name='Setup06',description='',subtype='FILE_PATH',options=set(),default='')

def sn_unregister_properties():
    del bpy.types.Scene.instrument
    del bpy.types.Scene.setupcount
    del bpy.types.Scene.setup01
    del bpy.types.Scene.setup02
    del bpy.types.Scene.setup03
    del bpy.types.Scene.setup04
    del bpy.types.Scene.setup05
    del bpy.types.Scene.setup06


###############   REGISTER ADDON
def register():
    sn_register_icons()
    sn_register_properties()
    bpy.utils.register_class(SNA_PT_Stack_Builder_B0816)
    bpy.utils.register_class(SNA_OT_Loadsystem)


###############   UNREGISTER ADDON
def unregister():
    sn_unregister_icons()
    sn_unregister_properties()
    bpy.utils.unregister_class(SNA_OT_Loadsystem)
    bpy.utils.unregister_class(SNA_PT_Stack_Builder_B0816)