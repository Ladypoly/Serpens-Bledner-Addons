# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.
#
# This addon was created with the Serpens - Visual Scripting Addon.
# This code is generated from nodes and is not intended for manual editing.
# You can find out more about Serpens at <https://blendermarket.com/products/serpens>.


bl_info = {
    "name": "Quest Homes Baking Tools",
    "description": "",
    "author": "Elin",
    "version": (1, 0, 0),
    "blender": (2, 93, 0),
    "location": "Toolshelf",
    "warning": "",
    "wiki_url": "",
    "tracker_url": "",
    "category": "3D View"
}


###############   IMPORTS
import bpy
from bpy.utils import previews
import os
import math


###############   INITALIZE VARIABLES
quest_homes_baking_tools = {
    "bakingtexnode": None, 
    "bakemargin": 0, 
    "bakingsamples": 0, 
    "combinedtex": None, 
    "diffusetex": None, 
    "normaltex": None, 
    "roughnesstex": None, 
    "bakingtexnodelist": [], 
    "none": None, 
    }


###############   SERPENS FUNCTIONS
def exec_line(line):
    exec(line)

def sn_print(tree_name, *args):
    if tree_name in bpy.data.node_groups:
        item = bpy.data.node_groups[tree_name].sn_graphs[0].prints.add()
        for arg in args:
            item.value += str(arg) + ";;;"
        if bpy.context and bpy.context.screen:
            for area in bpy.context.screen.areas:
                area.tag_redraw()
    print(*args)

def sn_cast_string(value):
    return str(value)

def sn_cast_boolean(value):
    if type(value) == tuple:
        for data in value:
            if bool(data):
                return True
        return False
    return bool(value)

def sn_cast_float(value):
    if type(value) == str:
        try:
            value = float(value)
            return value
        except:
            return float(bool(value))
    elif type(value) == tuple:
        return float(value[0])
    elif type(value) == list:
        return float(len(value))
    elif not type(value) in [float, int, bool]:
        try:
            value = len(value)
            return float(value)
        except:
            return float(bool(value))
    return float(value)

def sn_cast_int(value):
    return int(sn_cast_float(value))

def sn_cast_boolean_vector(value, size):
    if type(value) in [str, bool, int, float]:
        return_value = []
        for i in range(size):
            return_value.append(bool(value))
        return tuple(return_value)
    elif type(value) == tuple:
        return_value = []
        for i in range(size):
            return_value.append(bool(value[i]) if len(value) > i else bool(value[0]))
        return tuple(return_value)
    elif type(value) == list:
        return sn_cast_boolean_vector(tuple(value), size)
    else:
        try:
            value = tuple(value)
            return sn_cast_boolean_vector(value, size)
        except:
            return sn_cast_boolean_vector(bool(value), size)

def sn_cast_float_vector(value, size):
    if type(value) in [str, bool, int, float]:
        return_value = []
        for i in range(size):
            return_value.append(sn_cast_float(value))
        return tuple(return_value)
    elif type(value) == tuple:
        return_value = []
        for i in range(size):
            return_value.append(sn_cast_float(value[i]) if len(value) > i else sn_cast_float(value[0]))
        return tuple(return_value)
    elif type(value) == list:
        return sn_cast_float_vector(tuple(value), size)
    else:
        try:
            value = tuple(value)
            return sn_cast_float_vector(value, size)
        except:
            return sn_cast_float_vector(sn_cast_float(value), size)

def sn_cast_int_vector(value, size):
    return tuple(map(int, sn_cast_float_vector(value, size)))

def sn_cast_color(value, use_alpha):
    length = 4 if use_alpha else 3
    value = sn_cast_float_vector(value, length)
    tuple_list = []
    for data in range(length):
        data = value[data] if len(value) > data else value[0]
        tuple_list.append(sn_cast_float(min(1, max(0, data))))
    return tuple(tuple_list)

def sn_cast_list(value):
    if type(value) in [str, tuple, list]:
        return list(value)
    elif type(value) in [int, float, bool]:
        return [value]
    else:
        try:
            value = list(value)
            return value
        except:
            return [value]

def sn_cast_blend_data(value):
    if hasattr(value, "bl_rna"):
        return value
    elif type(value) in [tuple, bool, int, float, list]:
        return None
    elif type(value) == str:
        try:
            value = eval(value)
            return value
        except:
            return None
    else:
        return None

def sn_cast_enum(string, enum_values):
    for item in enum_values:
        if item[1] == string:
            return item[0]
        elif item[0] == string.upper():
            return item[0]
    return string


###############   IMPERATIVE CODE
#######   Quest Homes Baking Tools
def prebake():
    try:
        function_return_7EF07 = setresolution()
        function_return_03580 = setbakingsamples()
        run_function_on_A176A = bpy.context.active_object.active_material.node_tree.nodes.new(type=r"ShaderNodeTexImage", )
        quest_homes_baking_tools["bakingtexnode"] = run_function_on_A176A
        bpy.context.active_object.active_material.node_tree.nodes.active=run_function_on_A176A
        quest_homes_baking_tools["bakingtexnodelist"].append(run_function_on_A176A)
    except Exception as exc:
        print(str(exc) + " | Error in function PreBake")

def update_sn_1k(self, context):
    if self.sn_1k:
        self.sn_2k = False
        self.sn_4k = False
        self.sn_8k = False
        self.sn_16k = False
    else:
        pass

def update_sn_2k(self, context):
    if self.sn_2k:
        self.sn_1k = False
        self.sn_4k = False
        self.sn_8k = False
        self.sn_16k = False
    else:
        pass

def update_sn_4k(self, context):
    if self.sn_4k:
        self.sn_1k = False
        self.sn_2k = False
        self.sn_8k = False
        self.sn_16k = False
    else:
        pass

def update_sn_16k(self, context):
    if self.sn_16k:
        self.sn_1k = False
        self.sn_2k = False
        self.sn_4k = False
        self.sn_8k = False
    else:
        pass

def update_sn_8k(self, context):
    if self.sn_8k:
        self.sn_1k = False
        self.sn_2k = False
        self.sn_4k = False
        self.sn_16k = False
    else:
        pass

def update_sn_128samples(self, context):
    if self.sn_128samples:
        self.sn_64samples = False
        self.sn_256samples = False
        self.sn_2samples = False
    else:
        pass

def update_sn_256samples(self, context):
    if self.sn_256samples:
        self.sn_64samples = False
        self.sn_128samples = False
        self.sn_2samples = False
    else:
        pass

def update_sn_64samples(self, context):
    if self.sn_64samples:
        self.sn_128samples = False
        self.sn_256samples = False
        self.sn_2samples = False
    else:
        pass

def update_sn_2samples(self, context):
    if self.sn_2samples:
        self.sn_64samples = False
        self.sn_128samples = False
        self.sn_256samples = False
    else:
        pass

def setresolution():
    try:
        if sn_cast_blend_data(bpy.context.scene).sn_1k:
            sn_cast_blend_data(bpy.context.scene).resolution = 1024
            quest_homes_baking_tools["bakemargin"] = 8
            print(r"1024")
        else:
            pass
        if sn_cast_blend_data(bpy.context.scene).sn_2k:
            sn_cast_blend_data(bpy.context.scene).resolution = 2048
            quest_homes_baking_tools["bakemargin"] = 16
            print(r"2048")
        else:
            pass
        if sn_cast_blend_data(bpy.context.scene).sn_4k:
            sn_cast_blend_data(bpy.context.scene).resolution = 4096
            quest_homes_baking_tools["bakemargin"] = 32
            print(r"4096")
        else:
            pass
        if sn_cast_blend_data(bpy.context.scene).sn_8k:
            sn_cast_blend_data(bpy.context.scene).resolution = 8192
            quest_homes_baking_tools["bakemargin"] = 64
            print(r"8192")
        else:
            pass
        if sn_cast_blend_data(bpy.context.scene).sn_16k:
            sn_cast_blend_data(bpy.context.scene).resolution = 16384
            quest_homes_baking_tools["bakemargin"] = 128
            print(r"16384")
        else:
            pass
    except Exception as exc:
        print(str(exc) + " | Error in function SetResolution")

def setbakingsamples():
    try:
        if sn_cast_blend_data(bpy.context.scene).sn_64samples:
            quest_homes_baking_tools["bakingsamples"] = 64
        else:
            pass
        if sn_cast_blend_data(bpy.context.scene).sn_128samples:
            quest_homes_baking_tools["bakingsamples"] = 128
        else:
            pass
        if sn_cast_blend_data(bpy.context.scene).sn_256samples:
            quest_homes_baking_tools["bakingsamples"] = 256
        else:
            pass
        if sn_cast_blend_data(bpy.context.scene).sn_2samples:
            quest_homes_baking_tools["bakingsamples"] = 2
        else:
            pass
    except Exception as exc:
        print(str(exc) + " | Error in function SetBakingSamples")

def sn_handle_script_line_exception(exc, line):
    print("# # # # # # # # SCRIPT LINE ERROR # # # # # # # #")
    print("Line:", line)
    raise exc

def bakealbedo():
    try:
        new_return_13521 = bpy.data.images.new(name=(r"003_D_" + sn_cast_string(bpy.context.scene.resolution) + r"_Baked"), width=sn_cast_int(bpy.context.scene.resolution), height=sn_cast_int(bpy.context.scene.resolution), alpha=True, float_buffer=False, stereo3d=False, is_data=False, tiled=False, )
        quest_homes_baking_tools["bakingtexnode"].parent=quest_homes_baking_tools["bakingtexnode"]
        quest_homes_baking_tools["bakingtexnode"].image=new_return_13521
        quest_homes_baking_tools["diffusetex"] = new_return_13521
        sn_cast_blend_data(sn_cast_blend_data(bpy.context.scene).render.bake).use_selected_to_active=sn_cast_blend_data(bpy.context.scene).selectedtoactive
        sn_cast_blend_data(sn_cast_blend_data(bpy.context.scene).render.bake).use_clear=False
        sn_cast_blend_data(sn_cast_blend_data(bpy.context.scene).render.bake).use_split_materials=False
        sn_cast_blend_data(sn_cast_blend_data(bpy.context.scene).render.bake).use_automatic_name=False
        sn_cast_blend_data(sn_cast_blend_data(bpy.context.scene).render.bake).use_cage=False
        sn_cast_blend_data(sn_cast_blend_data(bpy.context.scene).render.bake).use_pass_ambient_occlusion=False
        sn_cast_blend_data(sn_cast_blend_data(bpy.context.scene).render.bake).use_pass_emit=False
        sn_cast_blend_data(sn_cast_blend_data(bpy.context.scene).render.bake).use_pass_direct=False
        sn_cast_blend_data(sn_cast_blend_data(bpy.context.scene).render.bake).use_pass_indirect=False
        sn_cast_blend_data(sn_cast_blend_data(bpy.context.scene).render.bake).use_pass_color=True
        sn_cast_blend_data(sn_cast_blend_data(bpy.context.scene).render.bake).use_pass_diffuse=False
        sn_cast_blend_data(sn_cast_blend_data(bpy.context.scene).render.bake).use_pass_glossy=False
        sn_cast_blend_data(sn_cast_blend_data(bpy.context.scene).render.bake).use_pass_transmission=False
        try: exec(r"bpy.context.scene.cycles.samples = 4")
        except Exception as exc: sn_handle_script_line_exception(exc, r"bpy.context.scene.cycles.samples = 4")
        bpy.ops.object.bake('INVOKE_DEFAULT' if True else 'EXEC_DEFAULT',type=sn_cast_enum(r"DIFFUSE", [("COMBINED","Combined",""),("AO","Ambient Occlusion",""),("SHADOW","Shadow",""),("NORMAL","Normal",""),("UV","UV",""),("ROUGHNESS","ROUGHNESS",""),("EMIT","Emit",""),("ENVIRONMENT","Environment",""),("DIFFUSE","Diffuse",""),("GLOSSY","Glossy",""),("TRANSMISSION","Transmission",""),]),margin=quest_homes_baking_tools["bakemargin"],use_clear=True,)
    except Exception as exc:
        print(str(exc) + " | Error in function BakeAlbedo")

def bakecombined():
    try:
        new_return_EB590 = bpy.data.images.new(name=(r"001_C_" + sn_cast_string(bpy.context.scene.resolution) + r"_Baked"), width=bpy.context.scene.resolution, height=bpy.context.scene.resolution, alpha=True, float_buffer=False, stereo3d=False, is_data=False, tiled=False, )
        quest_homes_baking_tools["bakingtexnode"].parent=quest_homes_baking_tools["bakingtexnode"]
        quest_homes_baking_tools["bakingtexnode"].image=new_return_EB590
        quest_homes_baking_tools["combinedtex"] = new_return_EB590
        sn_cast_blend_data(bpy.context.scene).render.bake.use_selected_to_active=sn_cast_blend_data(bpy.context.scene).selectedtoactive
        sn_cast_blend_data(bpy.context.scene).render.bake.use_clear=True
        sn_cast_blend_data(bpy.context.scene).render.bake.use_split_materials=False
        sn_cast_blend_data(bpy.context.scene).render.bake.use_automatic_name=False
        sn_cast_blend_data(bpy.context.scene).render.bake.use_cage=False
        sn_cast_blend_data(bpy.context.scene).render.bake.use_pass_ambient_occlusion=True
        sn_cast_blend_data(bpy.context.scene).render.bake.use_pass_emit=True
        sn_cast_blend_data(bpy.context.scene).render.bake.use_pass_direct=True
        sn_cast_blend_data(bpy.context.scene).render.bake.use_pass_indirect=True
        sn_cast_blend_data(bpy.context.scene).render.bake.use_pass_color=True
        sn_cast_blend_data(bpy.context.scene).render.bake.use_pass_diffuse=True
        sn_cast_blend_data(bpy.context.scene).render.bake.use_pass_glossy=True
        sn_cast_blend_data(bpy.context.scene).render.bake.use_pass_transmission=True
        try: exec((r"bpy.context.scene.cycles.samples = " + sn_cast_string(quest_homes_baking_tools["bakingsamples"])))
        except Exception as exc: sn_handle_script_line_exception(exc, (r"bpy.context.scene.cycles.samples = " + sn_cast_string(quest_homes_baking_tools["bakingsamples"])))
        bpy.ops.object.bake('INVOKE_DEFAULT' if True else 'EXEC_DEFAULT',type=sn_cast_enum(r"COMBINED", [("COMBINED","Combined",""),("AO","Ambient Occlusion",""),("SHADOW","Shadow",""),("NORMAL","Normal",""),("UV","UV",""),("ROUGHNESS","ROUGHNESS",""),("EMIT","Emit",""),("ENVIRONMENT","Environment",""),("DIFFUSE","Diffuse",""),("GLOSSY","Glossy",""),("TRANSMISSION","Transmission",""),]),margin=quest_homes_baking_tools["bakemargin"],save_mode=sn_cast_enum(r"INTERNAL", [("INTERNAL","Internal","Save the baking map in an internal image data-block"),("EXTERNAL","External","Save the baking map in an external file"),]),use_clear=True,use_automatic_name=False,)
    except Exception as exc:
        print(str(exc) + " | Error in function BakeCombined")

def bakenormal():
    try:
        new_return_5EFF9 = bpy.data.images.new(name=(r"002_N_" + sn_cast_string(bpy.context.scene.resolution) + r"_Baked"), width=sn_cast_int(bpy.context.scene.resolution), height=sn_cast_int(bpy.context.scene.resolution), alpha=True, float_buffer=False, stereo3d=False, is_data=False, tiled=False, )
        quest_homes_baking_tools["bakingtexnode"].parent=quest_homes_baking_tools["bakingtexnode"]
        quest_homes_baking_tools["bakingtexnode"].image=new_return_5EFF9
        quest_homes_baking_tools["normaltex"] = new_return_5EFF9
        sn_cast_blend_data(sn_cast_blend_data(bpy.context.scene).render.bake).use_selected_to_active=sn_cast_blend_data(bpy.context.scene).selectedtoactive
        sn_cast_blend_data(sn_cast_blend_data(bpy.context.scene).render.bake).use_clear=False
        sn_cast_blend_data(sn_cast_blend_data(bpy.context.scene).render.bake).use_split_materials=False
        sn_cast_blend_data(sn_cast_blend_data(bpy.context.scene).render.bake).use_automatic_name=False
        sn_cast_blend_data(sn_cast_blend_data(bpy.context.scene).render.bake).use_cage=False
        sn_cast_blend_data(sn_cast_blend_data(bpy.context.scene).render.bake).use_pass_ambient_occlusion=True
        sn_cast_blend_data(sn_cast_blend_data(bpy.context.scene).render.bake).use_pass_emit=True
        sn_cast_blend_data(sn_cast_blend_data(bpy.context.scene).render.bake).use_pass_direct=True
        sn_cast_blend_data(sn_cast_blend_data(bpy.context.scene).render.bake).use_pass_indirect=True
        sn_cast_blend_data(sn_cast_blend_data(bpy.context.scene).render.bake).use_pass_color=True
        sn_cast_blend_data(sn_cast_blend_data(bpy.context.scene).render.bake).use_pass_diffuse=True
        sn_cast_blend_data(sn_cast_blend_data(bpy.context.scene).render.bake).use_pass_glossy=True
        sn_cast_blend_data(sn_cast_blend_data(bpy.context.scene).render.bake).use_pass_transmission=True
        try: exec(r"bpy.context.scene.cycles.samples = 4")
        except Exception as exc: sn_handle_script_line_exception(exc, r"bpy.context.scene.cycles.samples = 4")
        bpy.ops.object.bake('INVOKE_DEFAULT' if True else 'EXEC_DEFAULT',type=sn_cast_enum(r"NORMAL", [("COMBINED","Combined",""),("AO","Ambient Occlusion",""),("SHADOW","Shadow",""),("NORMAL","Normal",""),("UV","UV",""),("ROUGHNESS","ROUGHNESS",""),("EMIT","Emit",""),("ENVIRONMENT","Environment",""),("DIFFUSE","Diffuse",""),("GLOSSY","Glossy",""),("TRANSMISSION","Transmission",""),]),margin=quest_homes_baking_tools["bakemargin"],use_clear=True,)
    except Exception as exc:
        print(str(exc) + " | Error in function BakeNormal")

def bakeroughness():
    try:
        new_return_AF8D1 = bpy.data.images.new(name=(r"000_A_" + sn_cast_string(bpy.context.scene.resolution) + r"_Baked"), width=sn_cast_int(bpy.context.scene.resolution), height=sn_cast_int(bpy.context.scene.resolution), alpha=True, float_buffer=False, stereo3d=False, is_data=False, tiled=False, )
        quest_homes_baking_tools["bakingtexnode"].parent=quest_homes_baking_tools["bakingtexnode"]
        quest_homes_baking_tools["bakingtexnode"].image=new_return_AF8D1
        quest_homes_baking_tools["roughnesstex"] = new_return_AF8D1
        sn_cast_blend_data(sn_cast_blend_data(bpy.context.scene).render.bake).use_selected_to_active=sn_cast_blend_data(bpy.context.scene).selectedtoactive
        sn_cast_blend_data(sn_cast_blend_data(bpy.context.scene).render.bake).use_clear=False
        sn_cast_blend_data(sn_cast_blend_data(bpy.context.scene).render.bake).use_split_materials=False
        sn_cast_blend_data(sn_cast_blend_data(bpy.context.scene).render.bake).use_automatic_name=False
        sn_cast_blend_data(sn_cast_blend_data(bpy.context.scene).render.bake).use_cage=False
        sn_cast_blend_data(sn_cast_blend_data(bpy.context.scene).render.bake).use_pass_ambient_occlusion=False
        sn_cast_blend_data(sn_cast_blend_data(bpy.context.scene).render.bake).use_pass_emit=False
        sn_cast_blend_data(sn_cast_blend_data(bpy.context.scene).render.bake).use_pass_direct=False
        sn_cast_blend_data(sn_cast_blend_data(bpy.context.scene).render.bake).use_pass_indirect=False
        sn_cast_blend_data(sn_cast_blend_data(bpy.context.scene).render.bake).use_pass_color=True
        sn_cast_blend_data(sn_cast_blend_data(bpy.context.scene).render.bake).use_pass_diffuse=False
        sn_cast_blend_data(sn_cast_blend_data(bpy.context.scene).render.bake).use_pass_glossy=False
        sn_cast_blend_data(sn_cast_blend_data(bpy.context.scene).render.bake).use_pass_transmission=False
        try: exec(r"bpy.context.scene.cycles.samples = 4")
        except Exception as exc: sn_handle_script_line_exception(exc, r"bpy.context.scene.cycles.samples = 4")
        bpy.ops.object.bake('INVOKE_DEFAULT' if True else 'EXEC_DEFAULT',type=sn_cast_enum(r"GLOSSY", [("COMBINED","Combined",""),("AO","Ambient Occlusion",""),("SHADOW","Shadow",""),("NORMAL","Normal",""),("UV","UV",""),("ROUGHNESS","ROUGHNESS",""),("EMIT","Emit",""),("ENVIRONMENT","Environment",""),("DIFFUSE","Diffuse",""),("GLOSSY","Glossy",""),("TRANSMISSION","Transmission",""),]),margin=quest_homes_baking_tools["bakemargin"],use_clear=True,)
    except Exception as exc:
        print(str(exc) + " | Error in function BakeRoughness")

def setcompswitch(nodename, switch, ):
    try:
        for_node_37890 = 0
        for_node_index_37890 = 0
        for for_node_index_37890, for_node_37890 in enumerate(bpy.context.scene.node_tree.nodes):
            if for_node_37890.name == nodename:
                for_node_37890.check = switch
            else:
                pass
    except Exception as exc:
        print(str(exc) + " | Error in function SetCompSwitch")

def assigntexturestocomp(nodename, bakedtexture, ):
    try:
        for_node_0E629 = 0
        for_node_index_0E629 = 0
        for for_node_index_0E629, for_node_0E629 in enumerate(bpy.context.scene.node_tree.nodes):
            if for_node_0E629.name == nodename:
                for_node_0E629.parent=for_node_0E629
                for_node_0E629.image=sn_cast_blend_data(bakedtexture)
            else:
                pass
    except Exception as exc:
        print(str(exc) + " | Error in function AssignTexturesToComp")

def removenodes(node, ):
    try:
        run_function_on_E9A31 = sn_cast_blend_data(bpy.context.active_object.active_material.node_tree.nodes).remove(node=node, )
    except Exception as exc:
        print(str(exc) + " | Error in function RemoveNodes")

def creatematifnomat():
    try:
        if len(sn_cast_list(bpy.context.active_object.material_slots)) == 0:
            new_return_6425E = bpy.data.materials.new(name=r"BakeMat", )
            bpy.context.active_object.data=None
            bpy.context.active_object.parent=None
            bpy.context.active_object.active_material=new_return_6425E
            bpy.context.active_object.instance_collection=None
            bpy.context.active_object.pose_library=None
        else:
            pass
    except Exception as exc:
        print(str(exc) + " | Error in function CreateMatIfNoMat")


#######   Prepare
def sn_handle_script_line_exception(exc, line):
    print("# # # # # # # # SCRIPT LINE ERROR # # # # # # # #")
    print("Line:", line)
    raise exc


###############   EVALUATED CODE
#######   Quest Homes Baking Tools
class SNA_OT_Bakecombined(bpy.types.Operator):
    bl_idname = "sna.bakecombined"
    bl_label = "BakeCombined"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            function_return_05803 = prebake()
            function_return_39598 = bakecombined()
        except Exception as exc:
            print(str(exc) + " | Error in execute function of BakeCombined")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of BakeCombined")
        return self.execute(context)


class SNA_OT_Bakenormaloperator(bpy.types.Operator):
    bl_idname = "sna.bakenormaloperator"
    bl_label = "BakeNormalOperator"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            function_return_DA823 = prebake()
            function_return_76F68 = bakenormal()
        except Exception as exc:
            print(str(exc) + " | Error in execute function of BakeNormalOperator")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of BakeNormalOperator")
        return self.execute(context)


class SNA_OT_Bakealbedooperator(bpy.types.Operator):
    bl_idname = "sna.bakealbedooperator"
    bl_label = "BakeAlbedoOperator"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            function_return_87410 = prebake()
            function_return_962E8 = bakealbedo()
        except Exception as exc:
            print(str(exc) + " | Error in execute function of BakeAlbedoOperator")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of BakeAlbedoOperator")
        return self.execute(context)


class SNA_OT_Bakeroughnessoperator(bpy.types.Operator):
    bl_idname = "sna.bakeroughnessoperator"
    bl_label = "BakeRoughnessOperator"
    bl_description = "Set specular to min 0.01"
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            if sn_cast_blend_data(bpy.context.scene).hasalpha:
                function_return_F93F1 = prebake()
                function_return_6E886 = bakeroughness()
            else:
                pass
        except Exception as exc:
            print(str(exc) + " | Error in execute function of BakeRoughnessOperator")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of BakeRoughnessOperator")
        return self.execute(context)


class SNA_OT_Denoise(bpy.types.Operator):
    bl_idname = "sna.denoise"
    bl_label = "Denoise"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            function_return_37846 = assigntexturestocomp(r"Combined", quest_homes_baking_tools["combinedtex"], )
            function_return_FF95D = assigntexturestocomp(r"Normal", quest_homes_baking_tools["normaltex"], )
            function_return_E2A77 = assigntexturestocomp(r"Diffuse", quest_homes_baking_tools["diffusetex"], )
            if sn_cast_blend_data(bpy.context.scene).hasalpha:
                function_return_6DFAC = assigntexturestocomp(r"Alpha", quest_homes_baking_tools["roughnesstex"], )
                function_return_37635 = setcompswitch(r"SetAlpha", True, )
            else:
                pass
            function_return_AE49D = setcompswitch(r"Render", True, )
        except Exception as exc:
            print(str(exc) + " | Error in execute function of Denoise")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of Denoise")
        return self.execute(context)


class SNA_OT_Clean(bpy.types.Operator):
    bl_idname = "sna.clean"
    bl_label = "Clean"
    bl_description = "Clean Texture Slots"
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            for_node_4E7E1 = 0
            for_node_index_4E7E1 = 0
            for for_node_index_4E7E1, for_node_4E7E1 in enumerate(quest_homes_baking_tools["bakingtexnodelist"]):
                if sn_cast_blend_data(for_node_4E7E1) == None:
                    pass
                else:
                    function_return_ABFC6 = removenodes(sn_cast_blend_data(for_node_4E7E1), )
            pass # SetViewerNode Script Start
            import bpy
            for area in bpy.context.screen.areas:
                if area.type == 'IMAGE_EDITOR':
                    area.spaces.active.image = bpy.data.images['Viewer Node']
            pass # SetViewerNode Script End
            function_return_E25AC = setcompswitch(r"Render", False, )
            function_return_345FA = assigntexturestocomp(r"Combined", "", )
            function_return_84648 = assigntexturestocomp(r"Normal", "", )
            function_return_8784A = assigntexturestocomp(r"Diffuse", "", )
            try: exec(r"bpy.ops.outliner.orphans_purge(do_local_ids=True, do_linked_ids=True, do_recursive=True)")
            except Exception as exc: sn_handle_script_line_exception(exc, r"bpy.ops.outliner.orphans_purge(do_local_ids=True, do_linked_ids=True, do_recursive=True)")
        except Exception as exc:
            print(str(exc) + " | Error in execute function of Clean")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of Clean")
        return self.execute(context)


#######   UserInterface
class SNA_PT_Texture_Baking_D93E9(bpy.types.Panel):
    bl_label = "Texture Baking"
    bl_idname = "SNA_PT_Texture_Baking_D93E9"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = 'Quest Homes'
    bl_order = 0


    @classmethod
    def poll(cls, context):
        return True

    def draw_header(self, context):
        try:
            layout = self.layout
        except Exception as exc:
            print(str(exc) + " | Error in Texture Baking panel header")

    def draw(self, context):
        try:
            layout = self.layout
            box = layout.box()
            box.enabled = True
            box.alert = False
            box.scale_x = 1.0
            box.scale_y = 1.0
            row = box.row(align=True)
            row.enabled = True
            row.alert = False
            row.scale_x = 1.0
            row.scale_y = 1.0
            row.prop(bpy.context.scene,'selectedtoactive',icon_value=614,text=r"Selected To Active",emboss=True,toggle=True,invert_checkbox=False,)
            col = box.column(align=False)
            col.enabled = True
            col.alert = False
            col.scale_x = 1.0
            col.scale_y = 1.0
            row = col.row(align=True)
            row.enabled = True
            row.alert = False
            row.scale_x = 1.0
            row.scale_y = 1.0
            row.prop(bpy.context.scene,'sn_1k',icon_value=0,text=r"1k",emboss=True,toggle=True,invert_checkbox=False,)
            row.prop(bpy.context.scene,'sn_2k',icon_value=0,text=r"2k",emboss=True,toggle=True,invert_checkbox=False,)
            row.prop(bpy.context.scene,'sn_4k',icon_value=0,text=r"4k",emboss=True,toggle=True,invert_checkbox=False,)
            row.prop(bpy.context.scene,'sn_8k',icon_value=0,text=r"8k",emboss=True,toggle=True,invert_checkbox=False,)
            row.prop(bpy.context.scene,'sn_16k',icon_value=0,text=r"16k",emboss=True,toggle=True,invert_checkbox=False,)
            row = col.row(align=True)
            row.enabled = True
            row.alert = False
            row.scale_x = 1.0
            row.scale_y = 1.0
            row.prop(bpy.context.scene,'sn_2samples',icon_value=58,text=r"2",emboss=True,toggle=True,invert_checkbox=False,)
            row.prop(bpy.context.scene,'sn_64samples',icon_value=0,text=r"64",emboss=True,toggle=True,invert_checkbox=False,)
            row.prop(bpy.context.scene,'sn_128samples',icon_value=0,text=r"128",emboss=True,toggle=True,invert_checkbox=False,)
            row.prop(bpy.context.scene,'sn_256samples',icon_value=0,text=r"256",emboss=True,toggle=True,invert_checkbox=False,)
            col = col.column(align=False)
            col.enabled = True
            col.alert = False
            col.scale_x = 1.0
            col.scale_y = 1.0
            if bpy.context.preferences.addons.find(r"uvpackmaster2") != -1:
                op = col.operator("sna.prepare",text=r"SmartUV + Pack",emboss=True,depress=False,icon_value=128)
            else:
                pass
            row = col.row(align=True)
            row.enabled = True
            row.alert = False
            row.scale_x = 1.0
            row.scale_y = 2.0
            op = row.operator("sna.bakecombined",text=r"Bake Combined",emboss=True,depress=False,icon_value=183)
            row = col.row(align=True)
            row.enabled = True
            row.alert = False
            row.scale_x = 1.0
            row.scale_y = 2.0
            op = row.operator("sna.bakenormaloperator",text=r"Normal",emboss=True,depress=False,icon_value=622)
            op = row.operator("sna.bakealbedooperator",text=r"Diffuse",emboss=True,depress=False,icon_value=249)
            row = row.row(align=True)
            row.enabled = True
            row.alert = False
            row.scale_x = 1.0
            row.scale_y = 1.0
            op = row.operator("sna.bakeroughnessoperator",text=r"Alpha",emboss=bpy.context.scene.hasalpha,depress=False,icon_value=0)
            row.prop(bpy.context.scene,'hasalpha',icon_value=36,text=r"",emboss=True,toggle=True,invert_checkbox=False,)
            row = col.row(align=True)
            row.enabled = True
            row.alert = False
            row.scale_x = 1.0
            row.scale_y = 1.0
            op = row.operator("sna.denoise",text=r"Denoise",emboss=True,depress=False,icon_value=0)
            op = row.operator("sna.clean",text=r"",emboss=True,depress=False,icon_value=182)
        except Exception as exc:
            print(str(exc) + " | Error in Texture Baking panel")


#######   Prepare
class SNA_OT_Prepare(bpy.types.Operator):
    bl_idname = "sna.prepare"
    bl_label = "Prepare"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in execute function of Prepare")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            bpy.ops.object.mode_set('INVOKE_DEFAULT' if True else 'EXEC_DEFAULT',mode=sn_cast_enum(r"EDIT", [("OBJECT","Object Mode",""),("EDIT","Edit Mode",""),("POSE","Pose Mode",""),("SCULPT","Sculpt Mode",""),("VERTEX_PAINT","Vertex Paint",""),("WEIGHT_PAINT","Weight Paint",""),("TEXTURE_PAINT","Texture Paint",""),("PARTICLE_EDIT","Particle Edit",""),("EDIT_GPENCIL","Edit Mode","Edit Grease Pencil Strokes"),("SCULPT_GPENCIL","Sculpt Mode","Sculpt Grease Pencil Strokes"),("PAINT_GPENCIL","Draw","Paint Grease Pencil Strokes"),("WEIGHT_GPENCIL","Weight Paint","Grease Pencil Weight Paint Strokes"),("VERTEX_GPENCIL","Vertex Paint","Grease Pencil Vertex Paint Strokes"),]),toggle=False,)
            try: exec(r"bpy.ops.mesh.select_all(action='SELECT')")
            except Exception as exc: sn_handle_script_line_exception(exc, r"bpy.ops.mesh.select_all(action='SELECT')")
            try: exec(r"bpy.ops.uv.smart_project()")
            except Exception as exc: sn_handle_script_line_exception(exc, r"bpy.ops.uv.smart_project()")
            try: exec(r"bpy.ops.uv.select_all(action='SELECT')")
            except Exception as exc: sn_handle_script_line_exception(exc, r"bpy.ops.uv.select_all(action='SELECT')")
            bpy.context.scene.uvp2_props.heuristic_enable = True
            bpy.context.scene.uvp2_props["advanced_heuristic"] = True
            bpy.context.scene.uvp2_props.heuristic_max_wait_time = 5
            bpy.ops.uvpackmaster2.uv_pack('INVOKE_DEFAULT' if True else 'EXEC_DEFAULT',)
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of Prepare")
        return self.execute(context)


###############   REGISTER ICONS
def sn_register_icons():
    icons = []
    bpy.types.Scene.quest_homes_baking_tools_icons = bpy.utils.previews.new()
    icons_dir = os.path.join( os.path.dirname( __file__ ), "icons" )
    for icon in icons:
        bpy.types.Scene.quest_homes_baking_tools_icons.load( icon, os.path.join( icons_dir, icon + ".png" ), 'IMAGE' )

def sn_unregister_icons():
    bpy.utils.previews.remove( bpy.types.Scene.quest_homes_baking_tools_icons )


###############   REGISTER PROPERTIES
def sn_register_properties():
    bpy.types.Scene.selectedtoactive = bpy.props.BoolProperty(name='SelectedToActive',description='',options=set(),default=False)
    bpy.types.Scene.resolution = bpy.props.IntProperty(name='Resolution',description='',subtype='NONE',options=set(),default=0)
    bpy.types.Scene.hasalpha = bpy.props.BoolProperty(name='HasAlpha',description='',options=set(),default=False)
    bpy.types.Scene.sn_1k = bpy.props.BoolProperty(name='1k',description='Set Resoltution to 1024',options=set(),update=update_sn_1k,default=False)
    bpy.types.Scene.sn_2k = bpy.props.BoolProperty(name='2k',description='Set Resoltution to 2048',options=set(),update=update_sn_2k,default=False)
    bpy.types.Scene.sn_4k = bpy.props.BoolProperty(name='4k',description='Set Resoltution to 4096',options=set(),update=update_sn_4k,default=True)
    bpy.types.Scene.sn_8k = bpy.props.BoolProperty(name='8k',description='Set Resoltution to 8192',options=set(),update=update_sn_8k,default=False)
    bpy.types.Scene.sn_16k = bpy.props.BoolProperty(name='16k',description='Set Resoltution to 16384',options=set(),update=update_sn_16k,default=False)
    bpy.types.Scene.sn_2samples = bpy.props.BoolProperty(name='2Samples',description='Set baking Samples to 2',options=set(),update=update_sn_2samples,default=False)
    bpy.types.Scene.sn_64samples = bpy.props.BoolProperty(name='64Samples',description='Set baking Samples to 64',options=set(),update=update_sn_64samples,default=True)
    bpy.types.Scene.sn_128samples = bpy.props.BoolProperty(name='128Samples',description='Set baking Samples to 128',options=set(),update=update_sn_128samples,default=False)
    bpy.types.Scene.sn_256samples = bpy.props.BoolProperty(name='256Samples',description='Set baking Samples to 256',options=set(),update=update_sn_256samples,default=False)
    bpy.types.Scene.progress = bpy.props.FloatProperty(name='Progress',description='',subtype='PERCENTAGE',unit='NONE',options={'HIDDEN'},precision=0, default=0.0,min=0.0,max=100.0)

def sn_unregister_properties():
    del bpy.types.Scene.selectedtoactive
    del bpy.types.Scene.resolution
    del bpy.types.Scene.hasalpha
    del bpy.types.Scene.sn_1k
    del bpy.types.Scene.sn_2k
    del bpy.types.Scene.sn_4k
    del bpy.types.Scene.sn_8k
    del bpy.types.Scene.sn_16k
    del bpy.types.Scene.sn_2samples
    del bpy.types.Scene.sn_64samples
    del bpy.types.Scene.sn_128samples
    del bpy.types.Scene.sn_256samples
    del bpy.types.Scene.progress


###############   REGISTER ADDON
def register():
    sn_register_icons()
    sn_register_properties()
    bpy.utils.register_class(SNA_OT_Bakecombined)
    bpy.utils.register_class(SNA_OT_Bakenormaloperator)
    bpy.utils.register_class(SNA_OT_Bakealbedooperator)
    bpy.utils.register_class(SNA_OT_Bakeroughnessoperator)
    bpy.utils.register_class(SNA_OT_Denoise)
    bpy.utils.register_class(SNA_OT_Clean)
    bpy.utils.register_class(SNA_PT_Texture_Baking_D93E9)
    bpy.utils.register_class(SNA_OT_Prepare)


###############   UNREGISTER ADDON
def unregister():
    sn_unregister_icons()
    sn_unregister_properties()
    bpy.utils.unregister_class(SNA_OT_Prepare)
    bpy.utils.unregister_class(SNA_PT_Texture_Baking_D93E9)
    bpy.utils.unregister_class(SNA_OT_Clean)
    bpy.utils.unregister_class(SNA_OT_Denoise)
    bpy.utils.unregister_class(SNA_OT_Bakeroughnessoperator)
    bpy.utils.unregister_class(SNA_OT_Bakealbedooperator)
    bpy.utils.unregister_class(SNA_OT_Bakenormaloperator)
    bpy.utils.unregister_class(SNA_OT_Bakecombined)