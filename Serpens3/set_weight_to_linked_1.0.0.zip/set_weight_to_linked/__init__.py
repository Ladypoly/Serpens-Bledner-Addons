# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

bl_info = {
    "name" : "Set weight to Linked",
    "author" : "EH", 
    "description" : "",
    "blender" : (3, 0, 0),
    "version" : (1, 0, 0),
    "location" : "",
    "warning" : "",
    "doc_url": "", 
    "tracker_url": "", 
    "category" : "3D View" 
}


import bpy
import bpy.utils.previews
import blf
import os


addon_keymaps = {}
_icons = None
nodetree = {'sna_inweightedit': False, }
class dotdict(dict):
    __getattr__ = dict.get
    __setattr__ = dict.__setitem__
    __delattr__ = dict.__delitem__


def find_user_keyconfig(key):
    km, kmi = addon_keymaps[key]
    for item in bpy.context.window_manager.keyconfigs.user.keymaps[km.name].keymap_items:
        found_item = False
        if kmi.idname == item.idname:
            found_item = True
            for name in dir(kmi.properties):
                if not name in ["bl_rna", "rna_type"] and not name[0] == "_":
                    if not kmi.properties[name] == item.properties[name]:
                        found_item = False
        if found_item:
            return item
    print(f"Couldn't find keymap item for {key}, using addon keymap instead. This won't be saved across sessions!")
    return kmi


_6F152_running = False
class SNA_OT_Setlinkedweight_Modal_6F152(bpy.types.Operator):
    bl_idname = "sna.setlinkedweight_modal_6f152"
    bl_label = "SetLinkedWeight_Modal"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}
    cursor = "DEFAULT"
    _handle = None
    _event = {}

    @classmethod
    def poll(cls, context):
        if not True or context.area.spaces[0].bl_rna.identifier == 'SpaceView3D':
            return not False
        return False

    def save_event(self, event):
        event_options = ["type", "value", "alt", "shift", "ctrl", "oskey", "mouse_region_x", "mouse_region_y", "mouse_x", "mouse_y", "pressure", "tilt"]
        if bpy.app.version >= (3, 2, 1):
            event_options += ["type_prev", "value_prev"]
        for option in event_options: self._event[option] = getattr(event, option)

    def draw_callback_px(self, context):
        event = self._event
        if event.keys():
            event = dotdict(event)
            try:
                font_id = 0
                if r'' and os.path.exists(r''):
                    font_id = blf.load(r'')
                if font_id == -1:
                    print("Couldn't load font!")
                else:
                    blf.position(font_id, (131, 100)[0], (131, 100)[1], 0)
                    blf.size(font_id, 25.309999465942383, 72)
                    clr = (1.0, 1.0, 1.0, 1.0)
                    blf.color(font_id, clr[0], clr[1], clr[2], clr[3])
                    if 0:
                        blf.enable(font_id, blf.WORD_WRAP)
                        blf.word_wrap(font_id, 0)
                    blf.draw(font_id, 'Select Linked meshes ')
                    blf.disable(font_id, blf.WORD_WRAP)
            except Exception as error:
                print(error)

    def execute(self, context):
        global _6F152_running
        _6F152_running = False
        context.window.cursor_set("DEFAULT")
        bpy.types.SpaceView3D.draw_handler_remove(self._handle, 'WINDOW')
        bpy.context.view_layer.objects.active.data.use_paint_mask = False
        exec('bpy.ops.wm.tool_set_by_id(name="builtin_brush.Draw")')
        nodetree['sna_inweightedit'] = False
        for area in context.screen.areas:
            area.tag_redraw()
        return {"FINISHED"}

    def modal(self, context, event):
        global _6F152_running
        if not context.area or not _6F152_running:
            self.execute(context)
            return {'CANCELLED'}
        self.save_event(event)
        context.area.tag_redraw()
        context.window.cursor_set('DEFAULT')
        try:
            bpy.ops.paint.face_select_linked('INVOKE_DEFAULT', )
            bpy.ops.paint.weight_set('INVOKE_DEFAULT', )
        except Exception as error:
            print(error)
        if event.type in ['RIGHTMOUSE', 'ESC']:
            self.execute(context)
            return {'CANCELLED'}
        return {'PASS_THROUGH'}

    def invoke(self, context, event):
        global _6F152_running
        if _6F152_running:
            _6F152_running = False
            return {'FINISHED'}
        else:
            self.save_event(event)
            self.start_pos = (event.mouse_x, event.mouse_y)
            bpy.context.view_layer.objects.active.data.use_paint_mask = True
            bpy.ops.paint.face_select_all('INVOKE_DEFAULT', action='DESELECT')
            exec('bpy.ops.wm.tool_set_by_id(name="builtin.select_box")')
            nodetree['sna_inweightedit'] = True
            args = (context,)
            self._handle = bpy.types.SpaceView3D.draw_handler_add(self.draw_callback_px, args, 'WINDOW', 'POST_PIXEL')
            context.window_manager.modal_handler_add(self)
            _6F152_running = True
            return {'RUNNING_MODAL'}


class SNA_OT_Setlinkedweight_Bf573(bpy.types.Operator):
    bl_idname = "sna.setlinkedweight_bf573"
    bl_label = "SetLinkedWeight"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        if 'PAINT_WEIGHT'==bpy.context.mode:
            bpy.ops.sna.setlinkedweight_modal_6f152('INVOKE_DEFAULT', )
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_AddonPreferences_1772F(bpy.types.AddonPreferences):
    bl_idname = 'set_weight_to_linked'

    def draw(self, context):
        if not (False):
            layout = self.layout 
            row_3646A = layout.row(heading='', align=False)
            row_3646A.alert = False
            row_3646A.enabled = True
            row_3646A.active = True
            row_3646A.use_property_split = False
            row_3646A.use_property_decorate = False
            row_3646A.scale_x = 1.0
            row_3646A.scale_y = 1.0
            row_3646A.alignment = 'Expand'.upper()
            row_3646A.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            row_3646A.label(text='Set Shortcut', icon_value=0)
            row_3646A.prop(find_user_keyconfig('9F645'), 'type', text='', full_event=True)


def sna_add_to_view3d_mt_editor_menus_A8D48(self, context):
    if not (False):
        layout = self.layout
        if 'PAINT_WEIGHT'==bpy.context.mode:
            op = layout.operator('sna.setlinkedweight_modal_6f152', text='', icon_value=583, emboss=True, depress=nodetree['sna_inweightedit'])


def register():
    global _icons
    _icons = bpy.utils.previews.new()
    bpy.utils.register_class(SNA_OT_Setlinkedweight_Modal_6F152)
    bpy.utils.register_class(SNA_OT_Setlinkedweight_Bf573)
    bpy.utils.register_class(SNA_AddonPreferences_1772F)
    bpy.types.VIEW3D_MT_editor_menus.prepend(sna_add_to_view3d_mt_editor_menus_A8D48)
    kc = bpy.context.window_manager.keyconfigs.addon
    km = kc.keymaps.new(name='3D View', space_type='VIEW_3D')
    kmi = km.keymap_items.new('sna.setlinkedweight_bf573', 'Y', 'PRESS',
        ctrl=False, alt=False, shift=False, repeat=False)
    addon_keymaps['9F645'] = (km, kmi)


def unregister():
    global _icons
    bpy.utils.previews.remove(_icons)
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    for km, kmi in addon_keymaps.values():
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()
    bpy.utils.unregister_class(SNA_OT_Setlinkedweight_Modal_6F152)
    bpy.utils.unregister_class(SNA_OT_Setlinkedweight_Bf573)
    bpy.utils.unregister_class(SNA_AddonPreferences_1772F)
    bpy.types.VIEW3D_MT_editor_menus.remove(sna_add_to_view3d_mt_editor_menus_A8D48)
