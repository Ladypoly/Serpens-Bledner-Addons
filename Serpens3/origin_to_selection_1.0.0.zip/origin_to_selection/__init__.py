# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

bl_info = {
    "name" : "Origin To Selection",
    "author" : "Elin", 
    "description" : "Set the origin with one click to center or selection",
    "blender" : (3, 0, 0),
    "version" : (1, 0, 0),
    "location" : "3D View",
    "warning" : "",
    "doc_url": "", 
    "tracker_url": "", 
    "category" : "3D View" 
}


import bpy
import bpy.utils.previews


addon_keymaps = {}
_icons = None
origintoselection = {'sna_cursorpos': [], }
class SNA_OT_Eh_Origintoselection_07F81(bpy.types.Operator):
    bl_idname = "sna.eh_origintoselection_07f81"
    bl_label = "EH_OriginToSelection"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        if 'OBJECT'==bpy.context.mode:
            bpy.ops.object.origin_set('INVOKE_DEFAULT', type='ORIGIN_GEOMETRY', center='BOUNDS')
        else:
            if 'EDIT_MESH'==bpy.context.mode:
                origintoselection['sna_cursorpos'] = list(bpy.context.scene.cursor.location)
                bpy.ops.view3d.snap_cursor_to_selected('INVOKE_DEFAULT', )
                bpy.ops.object.mode_set('INVOKE_DEFAULT', mode='OBJECT', toggle=True)
                bpy.ops.object.origin_set('INVOKE_DEFAULT', type='ORIGIN_CURSOR', center='MEDIAN')
                bpy.context.scene.cursor.location = origintoselection['sna_cursorpos']
            else:
                print('')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_add_to_view3d_ht_tool_header_59674(self, context):
    if not (False):
        layout = self.layout
        if ('OBJECT'==bpy.context.mode or 'EDIT_MESH'==bpy.context.mode):
            op = layout.operator('sna.eh_origintoselection_07f81', text='', icon_value=592, emboss=True, depress=False)


def register():
    global _icons
    _icons = bpy.utils.previews.new()
    bpy.utils.register_class(SNA_OT_Eh_Origintoselection_07F81)
    bpy.types.VIEW3D_HT_tool_header.append(sna_add_to_view3d_ht_tool_header_59674)


def unregister():
    global _icons
    bpy.utils.previews.remove(_icons)
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    for km, kmi in addon_keymaps.values():
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()
    bpy.utils.unregister_class(SNA_OT_Eh_Origintoselection_07F81)
    bpy.types.VIEW3D_HT_tool_header.remove(sna_add_to_view3d_ht_tool_header_59674)
