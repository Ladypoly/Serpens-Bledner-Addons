# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

bl_info = {
    "name" : "QuestHomesGLTFExport",
    "author" : "EH", 
    "description" : "",
    "blender" : (3, 0, 0),
    "version" : (1, 0, 0),
    "location" : "",
    "warning" : "",
    "doc_url": "", 
    "tracker_url": "", 
    "category" : "Import-Export" 
}


import bpy
import bpy.utils.previews
import os


addon_keymaps = {}
_icons = None
questhomesgltfexport = {'sna_has_no_export': False, }
class SNA_AddonPreferences_6574F(bpy.types.AddonPreferences):
    bl_idname = 'questhomesgltfexport'

    def draw(self, context):
        if not (False):
            layout = self.layout 
            row_2038C = layout.row(heading='', align=False)
            row_2038C.alert = False
            row_2038C.enabled = True
            row_2038C.active = True
            row_2038C.use_property_split = False
            row_2038C.use_property_decorate = False
            row_2038C.scale_x = 1.0
            row_2038C.scale_y = 1.0
            row_2038C.alignment = 'Expand'.upper()
            row_2038C.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            row_2038C.label(text='Build Folder:', icon_value=0)
            row_2038C.prop(bpy.context.scene, 'sna_buildfolder', text='', icon_value=0, emboss=True)


def sna_add_to_view3d_mt_editor_menus_6B9EA(self, context):
    if not (False):
        layout = self.layout
        op = layout.operator('sna.exportgltf_ae495', text='', icon_value=_icons['QuestHomes_logo_transparent_BG.png'].icon_id, emboss=True, depress=False)


class SNA_OT_Exportgltf_Ae495(bpy.types.Operator):
    bl_idname = "sna.exportgltf_ae495"
    bl_label = "ExportGLTF"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        questhomesgltfexport['sna_has_no_export'] = False
        for i_640F8 in range(len(bpy.context.view_layer.layer_collection.children)):
            if (bpy.context.view_layer.layer_collection.children[i_640F8].name == 'NO_EXPORT'):
                questhomesgltfexport['sna_has_no_export'] = True
        if questhomesgltfexport['sna_has_no_export']:
            bpy.ops.object.select_all('INVOKE_DEFAULT', action='DESELECT')
            for i_68891 in range(len(bpy.context.view_layer.layer_collection.children['NO_EXPORT'].collection.all_objects)):
                bpy.context.view_layer.layer_collection.children['NO_EXPORT'].collection.all_objects[i_68891].select_set(state=True, )
            bpy.ops.object.select_all('INVOKE_DEFAULT', action='INVERT')
            bpy.ops.export_scene.gltf(filepath=bpy.context.scene.sna_buildfolder + os.path.basename(bpy.context.blend_data.filepath).split('.')[0], export_format='GLTF_SEPARATE', ui_tab='GENERAL', use_selection=True)
        else:
            bpy.ops.export_scene.gltf(filepath=bpy.context.scene.sna_buildfolder + os.path.basename(bpy.context.blend_data.filepath).split('.')[0], export_format='GLTF_SEPARATE', ui_tab='GENERAL', use_selection=True)
        return {"FINISHED"}

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)


def register():
    global _icons
    _icons = bpy.utils.previews.new()
    bpy.types.Scene.sna_buildfolder = bpy.props.StringProperty(name='BuildFolder', description='', default='', subtype='DIR_PATH', maxlen=0)
    bpy.utils.register_class(SNA_AddonPreferences_6574F)
    bpy.types.VIEW3D_MT_editor_menus.append(sna_add_to_view3d_mt_editor_menus_6B9EA)
    if not 'QuestHomes_logo_transparent_BG.png' in _icons: _icons.load('QuestHomes_logo_transparent_BG.png', os.path.join(os.path.dirname(__file__), 'icons', 'QuestHomes_logo_transparent_BG.png'), "IMAGE")
    bpy.utils.register_class(SNA_OT_Exportgltf_Ae495)


def unregister():
    global _icons
    bpy.utils.previews.remove(_icons)
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    for km, kmi in addon_keymaps.values():
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()
    del bpy.types.Scene.sna_buildfolder
    bpy.utils.unregister_class(SNA_AddonPreferences_6574F)
    bpy.types.VIEW3D_MT_editor_menus.remove(sna_add_to_view3d_mt_editor_menus_6B9EA)
    bpy.utils.unregister_class(SNA_OT_Exportgltf_Ae495)
