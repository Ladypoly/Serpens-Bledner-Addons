# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.
#
# This addon was created with the Serpens - Visual Scripting Addon.
# This code is generated from nodes and is not intended for manual editing.
# You can find out more about Serpens at <https://blendermarket.com/products/serpens>.


bl_info = {
    "name": "Physics Dropper",
    "description": "",
    "author": "Elin",
    "version": (1, 0, 5),
    "blender": (2, 93, 5),
    "location": "Tool",
    "warning": "",
    "wiki_url": "",
    "tracker_url": "",
    "category": "3D View"
}


###############   IMPORTS
import bpy
from bpy.utils import previews
import os
import math


###############   INITALIZE VARIABLES
physics_dropper = {
    "active": [], 
    "passive": [], 
    "dropped": False, 
    "wordsettings": [], 
    }


###############   SERPENS FUNCTIONS
def exec_line(line):
    exec(line)

def sn_print(tree_name, *args):
    if tree_name in bpy.data.node_groups:
        item = bpy.data.node_groups[tree_name].sn_graphs[0].prints.add()
        for arg in args:
            item.value += str(arg) + ";;;"
        if bpy.context and bpy.context.screen:
            for area in bpy.context.screen.areas:
                area.tag_redraw()
    print(*args)

def sn_cast_string(value):
    return str(value)

def sn_cast_boolean(value):
    if type(value) == tuple:
        for data in value:
            if bool(data):
                return True
        return False
    return bool(value)

def sn_cast_float(value):
    if type(value) == str:
        try:
            value = float(value)
            return value
        except:
            return float(bool(value))
    elif type(value) == tuple:
        return float(value[0])
    elif type(value) == list:
        return float(len(value))
    elif not type(value) in [float, int, bool]:
        try:
            value = len(value)
            return float(value)
        except:
            return float(bool(value))
    return float(value)

def sn_cast_int(value):
    return int(sn_cast_float(value))

def sn_cast_boolean_vector(value, size):
    if type(value) in [str, bool, int, float]:
        return_value = []
        for i in range(size):
            return_value.append(bool(value))
        return tuple(return_value)
    elif type(value) == tuple:
        return_value = []
        for i in range(size):
            return_value.append(bool(value[i]) if len(value) > i else bool(value[0]))
        return tuple(return_value)
    elif type(value) == list:
        return sn_cast_boolean_vector(tuple(value), size)
    else:
        try:
            value = tuple(value)
            return sn_cast_boolean_vector(value, size)
        except:
            return sn_cast_boolean_vector(bool(value), size)

def sn_cast_float_vector(value, size):
    if type(value) in [str, bool, int, float]:
        return_value = []
        for i in range(size):
            return_value.append(sn_cast_float(value))
        return tuple(return_value)
    elif type(value) == tuple:
        return_value = []
        for i in range(size):
            return_value.append(sn_cast_float(value[i]) if len(value) > i else sn_cast_float(value[0]))
        return tuple(return_value)
    elif type(value) == list:
        return sn_cast_float_vector(tuple(value), size)
    else:
        try:
            value = tuple(value)
            return sn_cast_float_vector(value, size)
        except:
            return sn_cast_float_vector(sn_cast_float(value), size)

def sn_cast_int_vector(value, size):
    return tuple(map(int, sn_cast_float_vector(value, size)))

def sn_cast_color(value, use_alpha):
    length = 4 if use_alpha else 3
    value = sn_cast_float_vector(value, length)
    tuple_list = []
    for data in range(length):
        data = value[data] if len(value) > data else value[0]
        tuple_list.append(sn_cast_float(min(1, max(0, data))))
    return tuple(tuple_list)

def sn_cast_list(value):
    if type(value) in [str, tuple, list]:
        return list(value)
    elif type(value) in [int, float, bool]:
        return [value]
    else:
        try:
            value = list(value)
            return value
        except:
            return [value]

def sn_cast_blend_data(value):
    if hasattr(value, "bl_rna"):
        return value
    elif type(value) in [tuple, bool, int, float, list]:
        return None
    elif type(value) == str:
        try:
            value = eval(value)
            return value
        except:
            return None
    else:
        return None

def sn_cast_enum(string, enum_values):
    for item in enum_values:
        if item[1] == string:
            return item[0]
        elif item[0] == string.upper():
            return item[0]
    return string


###############   IMPERATIVE CODE
#######   Physics Dropper
def sn_handle_script_line_exception(exc, line):
    print("# # # # # # # # SCRIPT LINE ERROR # # # # # # # #")
    print("Line:", line)
    raise exc

def set_worldsettings():
    try:
        physics_dropper["wordsettings"] = []
        physics_dropper["wordsettings"].append(bpy.context.scene.rigidbody_world.point_cache.frame_start)
        physics_dropper["wordsettings"].append(bpy.context.scene.rigidbody_world.point_cache.frame_end)
        physics_dropper["wordsettings"].append(bpy.context.scene.rigidbody_world.substeps_per_frame)
        physics_dropper["wordsettings"].append(bpy.context.scene.rigidbody_world.solver_iterations)
        physics_dropper["wordsettings"].append(bpy.context.scene.rigidbody_world.enabled)
        physics_dropper["wordsettings"].append(bpy.context.scene.rigidbody_world.use_split_impulse)
        physics_dropper["wordsettings"].append(bpy.context.scene.frame_end)
        bpy.context.scene.rigidbody_world.substeps_per_frame=bpy.context.scene.w_subframes
        bpy.context.scene.rigidbody_world.solver_iterations=10
        bpy.context.scene.rigidbody_world.point_cache.frame_start=1
        bpy.context.scene.rigidbody_world.point_cache.frame_end=bpy.context.scene.w_endframe
        bpy.context.scene.rigidbody_world.point_cache.frame_step=0
        bpy.context.scene.rigidbody_world.point_cache.index=0
        bpy.context.scene.rigidbody_world.enabled=True
        bpy.context.scene.rigidbody_world.use_split_impulse=bpy.context.scene.w_split_impulse
        bpy.context.scene.frame_current=1
        bpy.context.scene.frame_start=1
        bpy.context.scene.frame_end=bpy.context.scene.w_endframe
        bpy.context.scene.frame_step=1
        bpy.context.scene.frame_preview_start=0
        bpy.context.scene.frame_preview_end=0
        bpy.context.scene.vr_landmarks_selected=0
        bpy.context.scene.vr_landmarks_active=0
        bpy.context.scene.NWSourceSocket=0
        bpy.context.scene.measureit_font_size=14
        bpy.context.scene.measureit_gl_precision=2
        bpy.context.scene.measureit_scale_font=14
        bpy.context.scene.measureit_scale_pos_x=5
        bpy.context.scene.measureit_scale_pos_y=5
        bpy.context.scene.measureit_scale_precision=0
        bpy.context.scene.measureit_ovr_font=14
        bpy.context.scene.measureit_ovr_width=1
        bpy.context.scene.measureit_ovr_font_rotation=0
        bpy.context.scene.measureit_rf_border=10
        bpy.context.scene.measureit_rf_line=1
        bpy.context.scene.measureit_glarrow_s=15
        bpy.context.scene.measureit_debug_font=14
        bpy.context.scene.measureit_debug_width=2
        bpy.context.scene.measureit_debug_precision=1
        bpy.context.scene.measureit_font_rotation=0
        bpy.context.scene.sresolution=0
        bpy.context.scene.scsamples=0
        bpy.context.scene.margin=0
        bpy.context.scene.randomize_factor=100
        bpy.context.scene.fadein=25
        bpy.context.scene.fadeout=25
        bpy.context.scene.selectiterations=150
        bpy.context.scene.selectiterationsdone=0
        bpy.context.scene.w_endframe=250
        bpy.context.scene.w_subframes=10
        bpy.context.scene.w_solver_iterations=10
    except Exception as exc:
        print(str(exc) + " | Error in function Set_WorldSettings")

def revert_worldsettings():
    try:
        bpy.context.scene.rigidbody_world.substeps_per_frame=sn_cast_int(physics_dropper["wordsettings"][2])
        bpy.context.scene.rigidbody_world.solver_iterations=sn_cast_int(physics_dropper["wordsettings"][3])
        bpy.context.scene.rigidbody_world.point_cache.frame_start=sn_cast_int(physics_dropper["wordsettings"][0])
        bpy.context.scene.rigidbody_world.point_cache.frame_end=sn_cast_int(physics_dropper["wordsettings"][1])
        bpy.context.scene.rigidbody_world.point_cache.frame_step=0
        bpy.context.scene.rigidbody_world.point_cache.index=0
        bpy.context.scene.rigidbody_world.enabled=sn_cast_boolean(physics_dropper["wordsettings"][4])
        bpy.context.scene.rigidbody_world.use_split_impulse=sn_cast_boolean(physics_dropper["wordsettings"][5])
        bpy.context.scene.frame_current=1
        bpy.context.scene.frame_start=1
        bpy.context.scene.frame_end=sn_cast_int(physics_dropper["wordsettings"][6])
        bpy.context.scene.frame_step=1
        bpy.context.scene.frame_preview_start=0
        bpy.context.scene.frame_preview_end=0
        bpy.context.scene.vr_landmarks_selected=0
        bpy.context.scene.vr_landmarks_active=0
        bpy.context.scene.NWSourceSocket=0
        bpy.context.scene.measureit_font_size=14
        bpy.context.scene.measureit_gl_precision=2
        bpy.context.scene.measureit_scale_font=14
        bpy.context.scene.measureit_scale_pos_x=5
        bpy.context.scene.measureit_scale_pos_y=5
        bpy.context.scene.measureit_scale_precision=0
        bpy.context.scene.measureit_ovr_font=14
        bpy.context.scene.measureit_ovr_width=1
        bpy.context.scene.measureit_ovr_font_rotation=0
        bpy.context.scene.measureit_rf_border=10
        bpy.context.scene.measureit_rf_line=1
        bpy.context.scene.measureit_glarrow_s=15
        bpy.context.scene.measureit_debug_font=14
        bpy.context.scene.measureit_debug_width=2
        bpy.context.scene.measureit_debug_precision=1
        bpy.context.scene.measureit_font_rotation=0
        bpy.context.scene.sresolution=0
        bpy.context.scene.scsamples=0
        bpy.context.scene.margin=0
        bpy.context.scene.randomize_factor=100
        bpy.context.scene.fadein=25
        bpy.context.scene.fadeout=25
        bpy.context.scene.selectiterations=150
        bpy.context.scene.selectiterationsdone=0
        bpy.context.scene.w_endframe=250
        bpy.context.scene.w_subframes=10
        bpy.context.scene.w_solver_iterations=10
    except Exception as exc:
        print(str(exc) + " | Error in function Revert_WorldSettings")
addon_keymaps = []


###############   EVALUATED CODE
#######   Physics Dropper
class SNA_PT_Active_Settings_1C85D(bpy.types.Panel):
    bl_label = "Active Settings"
    bl_idname = "SNA_PT_Active_Settings_1C85D"
    bl_parent_id = "SNA_PT_Physics_Dropper_4B116"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_options = {"DEFAULT_CLOSED",}


    @classmethod
    def poll(cls, context):
        return not physics_dropper["dropped"]

    def draw_header(self, context):
        try:
            layout = self.layout
            layout.label(text=r"",icon_value=37)
        except Exception as exc:
            print(str(exc) + " | Error in Active Settings subpanel header")

    def draw(self, context):
        try:
            layout = self.layout
            col = layout.column(align=True)
            col.enabled = True
            col.alert = False
            col.scale_x = 1.0
            col.scale_y = 1.0
            col.prop(bpy.context.scene,'a_shape',icon_value=0,text=r"Shape",emboss=True,expand=False,)
            col.prop(bpy.context.scene,'a_mass',text=r"Mass",emboss=True,slider=False,)
            col.prop(bpy.context.scene,'a_friction',text=r"Friction",emboss=True,slider=True,)
            col.prop(bpy.context.scene,'a_bunciness',text=r"Bunciness",emboss=True,slider=True,)
            col.prop(bpy.context.scene,'a_margin',text=r"Margin",emboss=True,slider=True,)
            col.prop(bpy.context.scene,'a_tra_damp',text=r"Damping Translation",emboss=True,slider=True,)
            col.prop(bpy.context.scene,'a_rot_damp',text=r"Damping  Rotation",emboss=True,slider=True,)
        except Exception as exc:
            print(str(exc) + " | Error in Active Settings subpanel")


class SNA_OT_Pausesim(bpy.types.Operator):
    bl_idname = "sna.pausesim"
    bl_label = "PauseSim"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in execute function of PauseSim")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            bpy.ops.screen.animation_play('INVOKE_DEFAULT' if True else 'EXEC_DEFAULT',reverse=False,sync=False,)
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of PauseSim")
        return self.execute(context)


class SNA_PT_Physics_Dropper_4B116(bpy.types.Panel):
    bl_label = "Physics Dropper"
    bl_idname = "SNA_PT_Physics_Dropper_4B116"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = 'Tool'
    bl_order = 0


    @classmethod
    def poll(cls, context):
        return True

    def draw_header(self, context):
        try:
            layout = self.layout
            layout.label(text=r"",icon_value=bpy.context.scene.physics_dropper_icons['DROPBOX'].icon_id)
        except Exception as exc:
            print(str(exc) + " | Error in Physics Dropper panel header")

    def draw(self, context):
        try:
            layout = self.layout
            row = layout.row(align=True)
            row.enabled = True
            row.alert = False
            row.scale_x = 1.0
            row.scale_y = 2.0
            op = row.operator("sna.drop",text=r"Drop",emboss=True,depress=False,icon_value=bpy.context.scene.physics_dropper_icons['DROPBOX'].icon_id)
            col = row.column(align=True)
            col.enabled = True
            col.alert = physics_dropper["dropped"]
            col.scale_x = 1.0
            col.scale_y = 1.0
            op = col.operator("sna.apply",text=r"Apply",emboss=True,depress=False,icon_value=43)
            col = layout.column(align=True)
            col.enabled = True
            col.alert = False
            col.scale_x = 1.0
            col.scale_y = 1.5
            if physics_dropper["dropped"]:
                op = col.operator("sna.pausesim",text=r"Pause/Play Simulation",emboss=True,depress=False,icon_value=498)
            else:
                pass
        except Exception as exc:
            print(str(exc) + " | Error in Physics Dropper panel")


class SNA_PT_Passive_Settings_76F70(bpy.types.Panel):
    bl_label = "Passive Settings"
    bl_idname = "SNA_PT_Passive_Settings_76F70"
    bl_parent_id = "SNA_PT_Physics_Dropper_4B116"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_options = {"DEFAULT_CLOSED",}


    @classmethod
    def poll(cls, context):
        return not physics_dropper["dropped"]

    def draw_header(self, context):
        try:
            layout = self.layout
            layout.label(text=r"",icon_value=66)
        except Exception as exc:
            print(str(exc) + " | Error in Passive Settings subpanel header")

    def draw(self, context):
        try:
            layout = self.layout
            col = layout.column(align=True)
            col.enabled = True
            col.alert = False
            col.scale_x = 1.0
            col.scale_y = 1.0
            col.prop(bpy.context.scene,'p_shape',icon_value=0,text=r"Shape",emboss=True,expand=False,)
            col.prop(bpy.context.scene,'p_friction',text=r"Friction",emboss=True,slider=True,)
            col.prop(bpy.context.scene,'p_bunciness',text=r"Bunciness",emboss=True,slider=True,)
            col.prop(bpy.context.scene,'p_margin',text=r"Margin",emboss=True,slider=True,)
        except Exception as exc:
            print(str(exc) + " | Error in Passive Settings subpanel")


class SNA_PT_Word_Settings_65161(bpy.types.Panel):
    bl_label = "Word Settings"
    bl_idname = "SNA_PT_Word_Settings_65161"
    bl_parent_id = "SNA_PT_Physics_Dropper_4B116"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_options = {"DEFAULT_CLOSED",}


    @classmethod
    def poll(cls, context):
        return not physics_dropper["dropped"]

    def draw_header(self, context):
        try:
            layout = self.layout
            layout.label(text=r"",icon_value=117)
        except Exception as exc:
            print(str(exc) + " | Error in Word Settings subpanel header")

    def draw(self, context):
        try:
            layout = self.layout
            col = layout.column(align=True)
            col.enabled = True
            col.alert = False
            col.scale_x = 1.0
            col.scale_y = 1.0
            col.prop(bpy.context.scene,'w_endframe',text=r"Simulation Length",emboss=True,slider=False,)
            col.prop(bpy.context.scene,'w_subframes',text=r"Substeps Per Frame",emboss=True,slider=False,)
            col.prop(bpy.context.scene,'w_solver_iterations',text=r"Solver Iterations",emboss=True,slider=False,)
            col.prop(bpy.context.scene,'w_split_impulse',icon_value=0,text=r"Split Impulse",emboss=True,toggle=False,invert_checkbox=False,)
        except Exception as exc:
            print(str(exc) + " | Error in Word Settings subpanel")

def sn_append_menu_1F1BD(self,context):
    try:
        layout = self.layout
    except Exception as exc:
        print(str(exc) + " | Error in View3D Mt Editor Menus when adding to menu")


class SNA_OT_Test(bpy.types.Operator):
    bl_idname = "sna.test"
    bl_label = "Test"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in execute function of Test")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of Test")
        return self.execute(context)


class SNA_OT_Drop(bpy.types.Operator):
    bl_idname = "sna.drop"
    bl_label = "Drop"
    bl_description = "All selected meshes will start dropping with the provided settings"
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in execute function of Drop")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            function_return_AB06E = set_worldsettings()
            physics_dropper["dropped"] = True
            physics_dropper["active"] = []
            physics_dropper["passive"] = []
            for_node_26609 = 0
            for_node_index_26609 = 0
            for for_node_index_26609, for_node_26609 in enumerate(bpy.context.selected_objects):
                if for_node_26609.type=="MESH":
                    physics_dropper["active"].append(for_node_26609)
                    bpy.context.view_layer.objects.active=for_node_26609
                else:
                    pass
            bpy.ops.object.select_all('INVOKE_DEFAULT' if True else 'EXEC_DEFAULT',action=sn_cast_enum(r"INVERT", [("TOGGLE","Toggle","Toggle selection for all elements"),("SELECT","Select","Select all elements"),("DESELECT","Deselect","Deselect all elements"),("INVERT","Invert","Invert selection of all elements"),]),)
            for_node_9F021 = 0
            for_node_index_9F021 = 0
            for for_node_index_9F021, for_node_9F021 in enumerate(bpy.context.selected_objects):
                if for_node_9F021.type=="MESH":
                    physics_dropper["passive"].append(for_node_9F021)
                else:
                    pass
            bpy.ops.object.select_all('INVOKE_DEFAULT' if True else 'EXEC_DEFAULT',action=sn_cast_enum(r"DESELECT", [("TOGGLE","Toggle","Toggle selection for all elements"),("SELECT","Select","Select all elements"),("DESELECT","Deselect","Deselect all elements"),("INVERT","Invert","Invert selection of all elements"),]),)
            for_node_34A0A = 0
            for_node_index_34A0A = 0
            for for_node_index_34A0A, for_node_34A0A in enumerate(physics_dropper["passive"]):
                run_function_on_56CA5 = sn_cast_blend_data(for_node_34A0A).select_set(state=True, view_layer=None, )
            bpy.ops.rigidbody.objects_add('INVOKE_DEFAULT' if True else 'EXEC_DEFAULT',type=sn_cast_enum(r"PASSIVE", [("ACTIVE","Active","Object is directly controlled by simulation results"),("PASSIVE","Passive","Object is directly controlled by animation system"),]),)
            for_node_6637B = 0
            for_node_index_6637B = 0
            for for_node_index_6637B, for_node_6637B in enumerate(physics_dropper["passive"]):
                sn_cast_blend_data(for_node_6637B).rigid_body.collision_shape = bpy.context.scene.p_shape
                sn_cast_blend_data(for_node_6637B).rigid_body.friction = sn_cast_float(bpy.context.scene.p_friction)
                sn_cast_blend_data(for_node_6637B).rigid_body.restitution = sn_cast_float(bpy.context.scene.p_bunciness)
                sn_cast_blend_data(for_node_6637B).rigid_body.use_margin = True
                sn_cast_blend_data(for_node_6637B).rigid_body.collision_margin = bpy.context.scene.p_margin
                sn_cast_blend_data(for_node_6637B).rigid_body.mass = bpy.context.scene.a_mass
            bpy.ops.object.select_all('INVOKE_DEFAULT' if True else 'EXEC_DEFAULT',action=sn_cast_enum(r"DESELECT", [("TOGGLE","Toggle","Toggle selection for all elements"),("SELECT","Select","Select all elements"),("DESELECT","Deselect","Deselect all elements"),("INVERT","Invert","Invert selection of all elements"),]),)
            for_node_FD1BF = 0
            for_node_index_FD1BF = 0
            for for_node_index_FD1BF, for_node_FD1BF in enumerate(physics_dropper["active"]):
                run_function_on_79D76 = sn_cast_blend_data(for_node_FD1BF).select_set(state=True, view_layer=None, )
            bpy.ops.object.origin_set('INVOKE_DEFAULT' if True else 'EXEC_DEFAULT',type=sn_cast_enum(r"ORIGIN_CENTER_OF_VOLUME", [("GEOMETRY_ORIGIN","Geometry to Origin","Move object geometry to object origin"),("ORIGIN_GEOMETRY","Origin to Geometry","Calculate the center of geometry based on the current pivot point (median, otherwise bounding box)"),("ORIGIN_CURSOR","Origin to 3D Cursor","Move object origin to position of the 3D cursor"),("ORIGIN_CENTER_OF_MASS","Origin to Center of Mass (Surface)","Calculate the center of mass from the surface area"),("ORIGIN_CENTER_OF_VOLUME","Origin to Center of Mass (Volume)","Calculate the center of mass from the volume (must be manifold geometry with consistent normals)"),]),center=sn_cast_enum(r"MEDIAN", [("MEDIAN","Median Center",""),("BOUNDS","Bounds Center",""),]),)
            bpy.ops.rigidbody.objects_add('INVOKE_DEFAULT' if True else 'EXEC_DEFAULT',type=sn_cast_enum(r"ACTIVE", [("ACTIVE","Active","Object is directly controlled by simulation results"),("PASSIVE","Passive","Object is directly controlled by animation system"),]),)
            for_node_BC30A = 0
            for_node_index_BC30A = 0
            for for_node_index_BC30A, for_node_BC30A in enumerate(physics_dropper["active"]):
                sn_cast_blend_data(for_node_BC30A).rigid_body.collision_shape = bpy.context.scene.a_shape
                sn_cast_blend_data(for_node_BC30A).rigid_body.friction = sn_cast_float(bpy.context.scene.a_friction)
                sn_cast_blend_data(for_node_BC30A).rigid_body.restitution = sn_cast_float(bpy.context.scene.a_bunciness)
                sn_cast_blend_data(for_node_BC30A).rigid_body.use_margin = True
                sn_cast_blend_data(for_node_BC30A).rigid_body.collision_margin = bpy.context.scene.a_margin
                sn_cast_blend_data(for_node_BC30A).rigid_body.linear_damping = sn_cast_float(bpy.context.scene.a_tra_damp)
                sn_cast_blend_data(for_node_BC30A).rigid_body.angular_damping = sn_cast_float(bpy.context.scene.a_rot_damp)
                sn_cast_blend_data(for_node_BC30A).rigid_body.mesh_source = sn_cast_enum(r"FINAL", [("BASE","Base","Base mesh"),("DEFORM","Deform","Deformations (shape keys, deform modifiers)"),("FINAL","Final","All modifiers"),])
            bpy.ops.screen.animation_play('INVOKE_DEFAULT' if True else 'EXEC_DEFAULT',reverse=False,sync=False,)
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of Drop")
        return self.execute(context)


class SNA_OT_Apply(bpy.types.Operator):
    bl_idname = "sna.apply"
    bl_label = "Apply"
    bl_description = "Apply the current state of the dropped objects"
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in execute function of Apply")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            bpy.ops.object.select_all('INVOKE_DEFAULT' if True else 'EXEC_DEFAULT',action=sn_cast_enum(r"DESELECT", [("TOGGLE","Toggle","Toggle selection for all elements"),("SELECT","Select","Select all elements"),("DESELECT","Deselect","Deselect all elements"),("INVERT","Invert","Invert selection of all elements"),]),)
            for_node_80937 = 0
            for_node_index_80937 = 0
            for for_node_index_80937, for_node_80937 in enumerate(physics_dropper["active"]):
                run_function_on_5F235 = sn_cast_blend_data(for_node_80937).select_set(state=True, view_layer=None, )
            bpy.ops.object.visual_transform_apply('INVOKE_DEFAULT' if True else 'EXEC_DEFAULT',)
            bpy.ops.object.select_all('INVOKE_DEFAULT' if True else 'EXEC_DEFAULT',action=sn_cast_enum(r"SELECT", [("TOGGLE","Toggle","Toggle selection for all elements"),("SELECT","Select","Select all elements"),("DESELECT","Deselect","Deselect all elements"),("INVERT","Invert","Invert selection of all elements"),]),)
            bpy.ops.rigidbody.objects_remove('INVOKE_DEFAULT' if True else 'EXEC_DEFAULT',)
            bpy.ops.object.select_all('INVOKE_DEFAULT' if True else 'EXEC_DEFAULT',action=sn_cast_enum(r"DESELECT", [("TOGGLE","Toggle","Toggle selection for all elements"),("SELECT","Select","Select all elements"),("DESELECT","Deselect","Deselect all elements"),("INVERT","Invert","Invert selection of all elements"),]),)
            for_node_5C101 = 0
            for_node_index_5C101 = 0
            for for_node_index_5C101, for_node_5C101 in enumerate(physics_dropper["active"]):
                run_function_on_2C174 = sn_cast_blend_data(for_node_5C101).select_set(state=True, view_layer=None, )
            physics_dropper["active"] = []
            physics_dropper["passive"] = []
            try: exec(r"bpy.context.scene.frame_current = 1")
            except Exception as exc: sn_handle_script_line_exception(exc, r"bpy.context.scene.frame_current = 1")
            function_return_26F75 = revert_worldsettings()
            physics_dropper["dropped"] = False
            try: self.report({'INFO'}, message=r"DONE")
            except: print("Serpens - Can't report in this context!")
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of Apply")
        return self.execute(context)


class SNA_AddonPreferences_E5569(bpy.types.AddonPreferences):
    bl_idname = 'physics_dropper'

    def draw(self, context):
        try:
            layout = self.layout
            col = layout.column(align=False)
            col.enabled = True
            col.alert = False
            col.scale_x = 1.25
            col.scale_y = 1.0
            if "Window" in bpy.context.window_manager.keyconfigs.addon.keymaps:
                if "sna.drop" in bpy.context.window_manager.keyconfigs.addon.keymaps["Window"].keymap_items:
                    kmi = bpy.context.window_manager.keyconfigs.addon.keymaps["Window"].keymap_items["sna.drop"]
                    col.prop(kmi, "type", text=r"Drop Shortcut", full_event=True, toggle=False)
                else:
                    col.label(text="Couldn't find keymap item!", icon="ERROR")
            else:
                col.label(text="Couldn't find keymap!", icon="ERROR")
            if "Window" in bpy.context.window_manager.keyconfigs.addon.keymaps:
                if "sna.apply" in bpy.context.window_manager.keyconfigs.addon.keymaps["Window"].keymap_items:
                    kmi = bpy.context.window_manager.keyconfigs.addon.keymaps["Window"].keymap_items["sna.apply"]
                    col.prop(kmi, "type", text=r"Apply Shortcut", full_event=True, toggle=False)
                else:
                    col.label(text="Couldn't find keymap item!", icon="ERROR")
            else:
                col.label(text="Couldn't find keymap!", icon="ERROR")
        except Exception as exc:
            print(str(exc) + " | Error in addon preferences")

def register_key_4814A():
    kc = bpy.context.window_manager.keyconfigs.addon
    if kc:
        km = kc.keymaps.new(name="Window", space_type="EMPTY")
        kmi = km.keymap_items.new("sna.drop",
                                    type= "V",
                                    value= "PRESS",
                                    repeat= False,
                                    ctrl=False,
                                    alt=False,
                                    shift=False)
        addon_keymaps.append((km, kmi))

def register_key_4A4D6():
    kc = bpy.context.window_manager.keyconfigs.addon
    if kc:
        km = kc.keymaps.new(name="Window", space_type="EMPTY")
        kmi = km.keymap_items.new("sna.apply",
                                    type= "V",
                                    value= "PRESS",
                                    repeat= False,
                                    ctrl=False,
                                    alt=False,
                                    shift=True)
        addon_keymaps.append((km, kmi))


###############   REGISTER ICONS
def sn_register_icons():
    icons = ["DROPBOX",]
    bpy.types.Scene.physics_dropper_icons = bpy.utils.previews.new()
    icons_dir = os.path.join( os.path.dirname( __file__ ), "icons" )
    for icon in icons:
        bpy.types.Scene.physics_dropper_icons.load( icon, os.path.join( icons_dir, icon + ".png" ), 'IMAGE' )

def sn_unregister_icons():
    bpy.utils.previews.remove( bpy.types.Scene.physics_dropper_icons )


###############   REGISTER PROPERTIES
def sn_register_properties():
    bpy.types.Scene.a_shape = bpy.props.EnumProperty(name='A_Shape',description='Set the shape type for all active objects',options=set(),items=[('CONVEX_HULL', 'CONVEX_HULL', 'This is my enum item'), ('MESH', 'MESH', 'This is my enum item'), ('BOX', 'BOX', 'This is my enum item'), ('SPHERE', 'SPHERE', 'This is my enum item'), ('CAPSULE', 'CAPSULE', 'This is my enum item'), ('CYLINDER', 'CYLINDER', 'This is my enum item'), ('CONE', 'CONE', 'This is my enum item'), ('COMPOUND', 'COMPOUND', 'This is my enum item')])
    bpy.types.Scene.a_friction = bpy.props.FloatProperty(name='A_Friction',description='',subtype='NONE',unit='NONE',options=set(),precision=2, default=1.0,min=0.0,max=1.0)
    bpy.types.Scene.a_bunciness = bpy.props.FloatProperty(name='A_Bunciness',description='',subtype='NONE',unit='NONE',options=set(),precision=2, default=0.0,min=0.0,max=1.0)
    bpy.types.Scene.a_margin = bpy.props.FloatProperty(name='A_Margin',description='',subtype='NONE',unit='NONE',options=set(),precision=3, default=0.0010000000474974513,min=0.0010000000474974513,max=0.10000000149011612)
    bpy.types.Scene.a_tra_damp = bpy.props.FloatProperty(name='A_Tra_Damp',description='',subtype='NONE',unit='NONE',options=set(),precision=3, default=0.03999999910593033,min=0.0010000000474974513,max=1.0)
    bpy.types.Scene.a_rot_damp = bpy.props.FloatProperty(name='A_Rot_Damp',description='',subtype='NONE',unit='NONE',options=set(),precision=3, default=0.10000000149011612,min=0.009999999776482582,max=1.0)
    bpy.types.Scene.p_shape = bpy.props.EnumProperty(name='P_Shape',description='Set the shape type for all passive objects',options=set(),items=[('MESH', 'MESH', 'This is my enum item'), ('CONVEX_HULL', 'CONVEX_HULL', 'This is my enum item'), ('BOX', 'BOX', 'This is my enum item'), ('SPHERE', 'SPHERE', 'This is my enum item'), ('CAPSULE', 'CAPSULE', 'This is my enum item'), ('CYLINDER', 'CYLINDER', 'This is my enum item'), ('CONE', 'CONE', 'This is my enum item'), ('COMPOUND', 'COMPOUND', 'This is my enum item')])
    bpy.types.Scene.p_friction = bpy.props.FloatProperty(name='P_Friction',description='',subtype='NONE',unit='NONE',options=set(),precision=2, default=1.0,min=0.0,max=1.0)
    bpy.types.Scene.p_bunciness = bpy.props.FloatProperty(name='P_Bunciness',description='',subtype='NONE',unit='NONE',options=set(),precision=2, default=0.0,min=0.0,max=1.0)
    bpy.types.Scene.p_margin = bpy.props.FloatProperty(name='P_Margin',description='',subtype='NONE',unit='NONE',options=set(),precision=3, default=0.0010000000474974513,min=0.0010000000474974513,max=0.10000000149011612)
    bpy.types.Scene.w_endframe = bpy.props.IntProperty(name='W_EndFrame',description='Length of the simulation in frames',subtype='NONE',options=set(),default=250)
    bpy.types.Scene.w_split_impulse = bpy.props.BoolProperty(name='W_Split_Impulse',description='Reducing extra velocity that can build up when objects collide (lowers the simulation stability a little so use only when necessary)',options=set(),default=False)
    bpy.types.Scene.w_subframes = bpy.props.IntProperty(name='W_Subframes',description='Number of simulation steps made per second (higher values are more accurate but slower). This only influences the accuracy and not the speed of the simulation.',subtype='NONE',options=set(),default=10)
    bpy.types.Scene.w_solver_iterations = bpy.props.IntProperty(name='W_Solver_Iterations',description='Amount of constraint solver iterations made per simulation step (higher values are more accurate but slower). Increasing this makes constraints and object stacking more stable.',subtype='NONE',options=set(),default=10)
    bpy.types.Scene.bool_rigid = bpy.props.EnumProperty(name='Bool_Rigid',description='',options=set(),items=[('Rigidbody', 'Rigidbody', 'Use a rigidbody Simulation'), ('Softbody', 'Softbody', 'Use a softbody Simulation')])
    bpy.types.Scene.a_mass = bpy.props.FloatProperty(name='A_Mass',description='',subtype='NONE',unit='NONE',options=set(),precision=2, default=1.0)

def sn_unregister_properties():
    del bpy.types.Scene.a_shape
    del bpy.types.Scene.a_friction
    del bpy.types.Scene.a_bunciness
    del bpy.types.Scene.a_margin
    del bpy.types.Scene.a_tra_damp
    del bpy.types.Scene.a_rot_damp
    del bpy.types.Scene.p_shape
    del bpy.types.Scene.p_friction
    del bpy.types.Scene.p_bunciness
    del bpy.types.Scene.p_margin
    del bpy.types.Scene.w_endframe
    del bpy.types.Scene.w_split_impulse
    del bpy.types.Scene.w_subframes
    del bpy.types.Scene.w_solver_iterations
    del bpy.types.Scene.bool_rigid
    del bpy.types.Scene.a_mass


###############   REGISTER ADDON
def register():
    sn_register_icons()
    sn_register_properties()
    bpy.utils.register_class(SNA_OT_Pausesim)
    bpy.utils.register_class(SNA_PT_Physics_Dropper_4B116)
    bpy.utils.register_class(SNA_OT_Test)
    bpy.utils.register_class(SNA_OT_Drop)
    bpy.utils.register_class(SNA_OT_Apply)
    bpy.utils.register_class(SNA_AddonPreferences_E5569)
    register_key_4814A()
    register_key_4A4D6()
    bpy.utils.register_class(SNA_PT_Active_Settings_1C85D)
    bpy.utils.register_class(SNA_PT_Passive_Settings_76F70)
    bpy.utils.register_class(SNA_PT_Word_Settings_65161)
    bpy.types.VIEW3D_MT_editor_menus.append(sn_append_menu_1F1BD)


###############   UNREGISTER ADDON
def unregister():
    sn_unregister_icons()
    sn_unregister_properties()
    bpy.types.VIEW3D_MT_editor_menus.remove(sn_append_menu_1F1BD)
    bpy.utils.unregister_class(SNA_PT_Word_Settings_65161)
    bpy.utils.unregister_class(SNA_PT_Passive_Settings_76F70)
    bpy.utils.unregister_class(SNA_PT_Active_Settings_1C85D)
    for km,kmi in addon_keymaps:
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()
    bpy.utils.unregister_class(SNA_AddonPreferences_E5569)
    bpy.utils.unregister_class(SNA_OT_Apply)
    bpy.utils.unregister_class(SNA_OT_Drop)
    bpy.utils.unregister_class(SNA_OT_Test)
    bpy.utils.unregister_class(SNA_PT_Physics_Dropper_4B116)
    bpy.utils.unregister_class(SNA_OT_Pausesim)