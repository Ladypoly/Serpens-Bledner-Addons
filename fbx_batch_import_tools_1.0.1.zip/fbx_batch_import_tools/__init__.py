# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.
#
# This addon was created with the Serpens - Visual Scripting Addon.
# This code is generated from nodes and is not intended for manual editing.
# You can find out more about Serpens at <https://blendermarket.com/products/serpens>.


bl_info = {
    "name": "FBX Batch import tools",
    "description": "",
    "author": "EH & SW",
    "version": (1, 0, 1),
    "blender": (2, 93, 0),
    "location": "3D View -> Tools",
    "warning": "",
    "wiki_url": "",
    "tracker_url": "",
    "category": "3D View"
}


###############   IMPORTS
import bpy
from bpy.utils import previews
import os
import math


###############   INITALIZE VARIABLES
fbx_batch_import_tools = {
    "new_variable": None, 
    }
import_material_fromclipboard = {
    "selectedobjectname": "", 
    "importedobjectname": "", 
    "selectedobjects": None, 
    }
clean_duplimaterials = {
    "new_variable": "", 
    }


###############   SERPENS FUNCTIONS
def exec_line(line):
    exec(line)

def sn_print(tree_name, *args):
    if tree_name in bpy.data.node_groups:
        item = bpy.data.node_groups[tree_name].sn_graphs[0].prints.add()
        for arg in args:
            item.value += str(arg) + ";;;"
        if bpy.context and bpy.context.screen:
            for area in bpy.context.screen.areas:
                area.tag_redraw()
    print(*args)

def sn_cast_string(value):
    return str(value)

def sn_cast_boolean(value):
    if type(value) == tuple:
        for data in value:
            if bool(data):
                return True
        return False
    return bool(value)

def sn_cast_float(value):
    if type(value) == str:
        try:
            value = float(value)
            return value
        except:
            return float(bool(value))
    elif type(value) == tuple:
        return float(value[0])
    elif type(value) == list:
        return float(len(value))
    elif not type(value) in [float, int, bool]:
        try:
            value = len(value)
            return float(value)
        except:
            return float(bool(value))
    return float(value)

def sn_cast_int(value):
    return int(sn_cast_float(value))

def sn_cast_boolean_vector(value, size):
    if type(value) in [str, bool, int, float]:
        return_value = []
        for i in range(size):
            return_value.append(bool(value))
        return tuple(return_value)
    elif type(value) == tuple:
        return_value = []
        for i in range(size):
            return_value.append(bool(value[i]) if len(value) > i else bool(value[0]))
        return tuple(return_value)
    elif type(value) == list:
        return sn_cast_boolean_vector(tuple(value), size)
    else:
        try:
            value = tuple(value)
            return sn_cast_boolean_vector(value, size)
        except:
            return sn_cast_boolean_vector(bool(value), size)

def sn_cast_float_vector(value, size):
    if type(value) in [str, bool, int, float]:
        return_value = []
        for i in range(size):
            return_value.append(sn_cast_float(value))
        return tuple(return_value)
    elif type(value) == tuple:
        return_value = []
        for i in range(size):
            return_value.append(sn_cast_float(value[i]) if len(value) > i else sn_cast_float(value[0]))
        return tuple(return_value)
    elif type(value) == list:
        return sn_cast_float_vector(tuple(value), size)
    else:
        try:
            value = tuple(value)
            return sn_cast_float_vector(value, size)
        except:
            return sn_cast_float_vector(sn_cast_float(value), size)

def sn_cast_int_vector(value, size):
    return tuple(map(int, sn_cast_float_vector(value, size)))

def sn_cast_color(value, use_alpha):
    length = 4 if use_alpha else 3
    value = sn_cast_float_vector(value, length)
    tuple_list = []
    for data in range(length):
        data = value[data] if len(value) > data else value[0]
        tuple_list.append(sn_cast_float(min(1, max(0, data))))
    return tuple(tuple_list)

def sn_cast_list(value):
    if type(value) in [str, tuple, list]:
        return list(value)
    elif type(value) in [int, float, bool]:
        return [value]
    else:
        try:
            value = list(value)
            return value
        except:
            return [value]

def sn_cast_blend_data(value):
    if hasattr(value, "bl_rna"):
        return value
    elif type(value) in [tuple, bool, int, float, list]:
        return None
    elif type(value) == str:
        try:
            value = eval(value)
            return value
        except:
            return None
    else:
        return None

def sn_cast_enum(string, enum_values):
    for item in enum_values:
        if item[1] == string:
            return item[0]
        elif item[0] == string.upper():
            return item[0]
    return string


###############   IMPERATIVE CODE
#######   Import Material fromClipboard
def sn_handle_script_line_exception(exc, line):
    print("# # # # # # # # SCRIPT LINE ERROR # # # # # # # #")
    print("Line:", line)
    raise exc


#######   Clean DupliMaterials
def sn_handle_script_line_exception(exc, line):
    print("# # # # # # # # SCRIPT LINE ERROR # # # # # # # #")
    print("Line:", line)
    raise exc


#######   Finalize
def sn_handle_script_line_exception(exc, line):
    print("# # # # # # # # SCRIPT LINE ERROR # # # # # # # #")
    print("Line:", line)
    raise exc


###############   EVALUATED CODE
#######   FBX Batch import tools
class SNA_PT_FBX_Batch_Import_tools_7D304(bpy.types.Panel):
    bl_label = "FBX Batch Import tools"
    bl_idname = "SNA_PT_FBX_Batch_Import_tools_7D304"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = 'Tool'
    bl_order = 0


    @classmethod
    def poll(cls, context):
        return True

    def draw_header(self, context):
        try:
            layout = self.layout
        except Exception as exc:
            print(str(exc) + " | Error in FBX Batch Import tools panel header")

    def draw(self, context):
        try:
            layout = self.layout
            box = layout.box()
            box.enabled = True
            box.alert = False
            box.scale_x = 1.0
            box.scale_y = 1.0
            col = box.column(align=True)
            col.enabled = True
            col.alert = False
            col.scale_x = 1.0
            col.scale_y = 1.0
            col.prop(bpy.context.scene,'matfilepath',icon_value=0,text=r"Material FIle",emboss=True,)
            col.prop(bpy.context.scene,'fbxdirpath',icon_value=0,text=r"FBX Path",emboss=True,)
            col = box.column(align=True)
            col.enabled = True
            col.alert = False
            col.scale_x = 1.0
            col.scale_y = 1.5
            op = col.operator("sna.fbxbatchimport",text=r"Batch Import",emboss=True,depress=False,icon_value=706)
            box = layout.box()
            box.enabled = True
            box.alert = False
            box.scale_x = 1.0
            box.scale_y = 1.0
            box.label(text=r"Material Utilitys",icon_value=0)
            col = box.column(align=True)
            col.enabled = True
            col.alert = False
            col.scale_x = 1.0
            col.scale_y = 1.0
            op = col.operator("sna.",text=r"Paste Material",emboss=True,depress=False,icon_value=127)
            row = col.row(align=True)
            row.enabled = True
            row.alert = False
            row.scale_x = 1.0
            row.scale_y = 1.0
            op = row.operator("sna.selectlinked",text=r"Select Linked",emboss=True,depress=False,icon_value=256)
            op = row.operator("sna.linkmaterials",text=r"Link Materials",emboss=True,depress=False,icon_value=56)
            row = box.row(align=True)
            row.enabled = True
            row.alert = False
            row.scale_x = 1.0
            row.scale_y = 1.0
            op = row.operator("sna.cleanmaterialslots",text=r"Clean Slots",emboss=True,depress=False,icon_value=627)
            op = row.operator("sna.clean_duplimaterials",text=r"Clean Dupli Mats",emboss=True,depress=False,icon_value=629)
            op = row.operator("sna.clean_up",text=r"",emboss=True,depress=False,icon_value=182)
            box = layout.box()
            box.enabled = True
            box.alert = False
            box.scale_x = 1.0
            box.scale_y = 1.0
            box.label(text=r"Convert and collect textures",icon_value=0)
            col = box.column(align=False)
            col.enabled = True
            col.alert = False
            col.scale_x = 1.0
            col.scale_y = 1.5
            op = col.operator("sna.finalize",text=r"Finalize",emboss=True,depress=False,icon_value=687)
        except Exception as exc:
            print(str(exc) + " | Error in FBX Batch Import tools panel")


#######   Import Material fromClipboard
class SNA_OT_(bpy.types.Operator):
    bl_idname = "sna."
    bl_label = "ImportMaterial"
    bl_description = "Import the material crom the object in the clipboard and apply it to the selected object"
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in execute function of ImportMaterial")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            import_material_fromclipboard["selectedobjects"] = bpy.context.selected_objects
            import_material_fromclipboard["selectedobjectname"] = bpy.context.active_object.name
            try: exec(r"bpy.ops.view3d.pastebuffer()")
            except Exception as exc: sn_handle_script_line_exception(exc, r"bpy.ops.view3d.pastebuffer()")
            for_node_5A513 = 0
            for_node_index_5A513 = 0
            for for_node_index_5A513, for_node_5A513 in enumerate(bpy.context.selected_objects):
                bpy.context.view_layer.objects.active=for_node_5A513
                import_material_fromclipboard["importedobjectname"] = bpy.context.active_object.name
                for_node_6C13F = 0
                for_node_index_6C13F = 0
                for for_node_index_6C13F, for_node_6C13F in enumerate(sn_cast_list(import_material_fromclipboard["selectedobjects"])):
                    pass
                try: exec(r"bpy.ops.object.make_links_data(type='MATERIAL')")
                except Exception as exc: sn_handle_script_line_exception(exc, r"bpy.ops.object.make_links_data(type='MATERIAL')")
                for_node_6EB5E = 0
                for_node_index_6EB5E = 0
                for for_node_index_6EB5E, for_node_6EB5E in enumerate(sn_cast_list(import_material_fromclipboard["selectedobjects"])):
                    run_function_on_B9791 = sn_cast_blend_data(for_node_6EB5E).select_set(state=False, view_layer=None, )
                try: exec(r"bpy.ops.object.delete(use_global=False)")
                except Exception as exc: sn_handle_script_line_exception(exc, r"bpy.ops.object.delete(use_global=False)")
                run_function_on_8ED27 = bpy.data.objects[import_material_fromclipboard["selectedobjectname"]].select_set(state=True, view_layer=None, )
                for_node_F4225 = 0
                for_node_index_F4225 = 0
                for for_node_index_F4225, for_node_F4225 in enumerate(sn_cast_list(import_material_fromclipboard["selectedobjects"])):
                    run_function_on_4464D = sn_cast_blend_data(for_node_F4225).select_set(state=True, view_layer=None, )
                for_node_B5898 = 0
                for_node_index_B5898 = 0
                for for_node_index_B5898, for_node_B5898 in enumerate(bpy.context.selected_objects):
                    bpy.context.view_layer.objects.active=for_node_B5898
                try: exec(r"bpy.ops.outliner.orphans_purge(do_local_ids=True, do_linked_ids=True, do_recursive=True)")
                except Exception as exc: sn_handle_script_line_exception(exc, r"bpy.ops.outliner.orphans_purge(do_local_ids=True, do_linked_ids=True, do_recursive=True)")
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of ImportMaterial")
        return self.execute(context)


class SNA_OT_Selectlinked(bpy.types.Operator):
    bl_idname = "sna.selectlinked"
    bl_label = "SelectLinked"
    bl_description = "Select all Objects with the same Material"
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in execute function of SelectLinked")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            try: exec(r"bpy.ops.object.select_linked(type='MATERIAL')")
            except Exception as exc: sn_handle_script_line_exception(exc, r"bpy.ops.object.select_linked(type='MATERIAL')")
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of SelectLinked")
        return self.execute(context)


class SNA_OT_Linkmaterials(bpy.types.Operator):
    bl_idname = "sna.linkmaterials"
    bl_label = "LinkMaterials"
    bl_description = "Copa Material from active Object to all selected Objects"
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in execute function of LinkMaterials")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            try: exec(r"bpy.ops.object.make_links_data(type='MATERIAL')")
            except Exception as exc: sn_handle_script_line_exception(exc, r"bpy.ops.object.make_links_data(type='MATERIAL')")
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of LinkMaterials")
        return self.execute(context)


#######   FBX_BatchImport
class SNA_OT_Fbxbatchimport(bpy.types.Operator):
    bl_idname = "sna.fbxbatchimport"
    bl_label = "FbxBatchImport"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in execute function of FbxBatchImport")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            pass # FbxBatchImport Script Start
            import bpy
            props = self.properties
            scene = context.scene
            Name = "Default"
            MaterialFile = context.scene.matfilepath
            ImportFile = ""
            SavePath = ""
            folderPath = context.scene.fbxdirpath
            #Merge Materials Preperation

            def replace_material(bad_mat, good_mat):
                bad_mat.user_remap(good_mat)
                bpy.data.materials.remove(bad_mat)

            def get_duplicate_materials(og_material):
                common_name = og_material.name
                if common_name[-3:].isnumeric():
                    common_name = common_name[:-4]
                duplicate_materials = []
                for material in bpy.data.materials:
                    if material is not og_material:
                        name = material.name
                        if name[-3:].isnumeric() and name[-4] == ".":
                            name = name[:-4]
                        if name == common_name:
                            duplicate_materials.append(material)
                text = "{} duplicate materials found"
                print(text.format(len(duplicate_materials)))
                return duplicate_materials

            def remove_all_duplicate_materials():
                i = 0
                while i < len(bpy.data.materials):
                    og_material = bpy.data.materials[i]
                    print("og material: " + og_material.name)
                    # get duplicate materials
                    duplicate_materials = get_duplicate_materials(og_material)
                    # replace all duplicates
                    for duplicate_material in duplicate_materials:
                        replace_material(duplicate_material, og_material)
                    # adjust name to no trailing numbers
                    if og_material.name[-3:].isnumeric() and og_material.name[-4] == ".":
                        og_material.name = og_material.name[:-4]
                    i = i+1

            def replace_material(bad_mat, good_mat):
                bad_mat.user_remap(good_mat)
                bpy.data.materials.remove(bad_mat)

            def get_duplicate_materials(og_material):
                common_name = og_material.name
                if common_name[-3:].isnumeric():
                    common_name = common_name[:-4]
                duplicate_materials = []
                for material in bpy.data.materials:
                    if material is not og_material:
                        name = material.name
                        if name[-3:].isnumeric() and name[-4] == ".":
                            name = name[:-4]
                        if name == common_name:
                            duplicate_materials.append(material)
                text = "{} duplicate materials found"
                #print(text.format(len(duplicate_materials)))
                return duplicate_materials

            def remove_all_duplicate_materials():
                i = 0
                while i < len(bpy.data.materials):
                    og_material = bpy.data.materials[i]
                    #print("og material: " + og_material.name)
                    # get duplicate materials
                    duplicate_materials = get_duplicate_materials(og_material)
                    # replace all duplicates
                    for duplicate_material in duplicate_materials:
                        replace_material(duplicate_material, og_material)
                    # adjust name to no trailing numbers
                    if og_material.name[-3:].isnumeric() and og_material.name[-4] == ".":
                        og_material.name = og_material.name[:-4]
                    i = i+1

            def exec_script_block(theFile):
                #append all materials from blend
                filepath = MaterialFile
                ImportFile = (folderPath + theFile)
                xTemp = theFile.split(".")
                theFileClean = xTemp[0]
                SavePath = (folderPath + theFileClean + ".blend")
                print("Importing " + str(ImportFile))
                print("Saving " + str(SavePath))
                with bpy.data.libraries.load(filepath, link=False) as (data_from, data_to):
                    data_to.materials = data_from.materials 
                remove_all_duplicate_materials()
                startMats = []
                i = 0
                while i < len(bpy.data.materials):
                    startMats.append(bpy.data.materials[i])
                    i = i+1
                print("startMats contains " + str(len(startMats)) + " materials!")
                #Import FBX  
                bpy.ops.import_scene.fbx(filepath= ImportFile, bake_space_transform=True, use_prepost_rot=True, use_custom_normals=True, use_anim=False, use_subsurf=True, use_custom_props=True, use_custom_props_enum_as_string=True)   
                #Merge Materials 
                remove_all_duplicate_materials()
                # new mat section to delet eoutput node for pink color
                allMats = bpy.data.materials
                newMaterials = []
                print("a " + str(len(allMats)) + " --- " + "s " + str(len(startMats)))
                for aMaterial in allMats:
                    aMaterialNew = True
                    for sMaterial in startMats:
                        #print("Comparing " + str(sMaterial.name) + " with " + str(aMaterial.name))
                        if sMaterial is aMaterial:
                            aMaterialNew = False
                            #print(str(sMaterial.name) + " == " + str(aMaterial.name))
                    if aMaterialNew == True:
                        newMaterials.append(aMaterial)
                        print("Found new material: " +  str(aMaterial.name))
                for newMaterial in newMaterials:
                    #print("found New Material " + str(newMaterial.name))
                    # delete output node
                    nodeDelete = bpy.data.materials[newMaterial.name].node_tree.nodes['Material Output']
                    bpy.data.materials[newMaterial.name].node_tree.nodes.remove(nodeDelete)
            #----------Clean unused Material Slots
                #Create_000_TEMP_HIDE_Collection():
                bpy.ops.object.select_by_type(type='EMPTY')
                for x in bpy.context.selected_objects:
                    bpy.context.view_layer.objects.active = x
                obj = bpy.context.object
                obj_old_coll = obj.users_collection #list of all collection the obj is in
                temp_coll = bpy.data.collections.new(name="000_TEMP_HIDE") #create new coll in data
                bpy.context.scene.collection.children.link(temp_coll) #add new coll to the scene
                for obj in bpy.context.selected_objects:
                    temp_coll.objects.link(obj) #link obj to scene
                print ("000_TEMP_HIDE erstellt")
                for obj in bpy.context.selected_objects:
                    for ob in obj_old_coll: #unlink from all  precedent obj collections
                        ob.objects.unlink(obj)
                #Recursivly transverse layer_collection for a particular name

                def recurLayerCollection(layerColl, collName):
                    found = None
                    if (layerColl.name == collName):
                        return layerColl
                    for layer in layerColl.children:
                        found = recurLayerCollection(layer, collName)
                        if found:
                            return found
                ###Set 000_TEMP_HIDE Collection Active
                layer_collection = bpy.context.view_layer.layer_collection
                layerColl = recurLayerCollection(layer_collection, '000_TEMP_HIDE')
                bpy.context.view_layer.active_layer_collection = layerColl
                #Disable_000_TEMP_HIDE():    
                bpy.context.view_layer.active_layer_collection.exclude = True
                #RemoveDupliMaterials(): 
                bpy.ops.object.select_by_type(type='MESH')
                for x in bpy.context.selected_objects:
                    bpy.context.view_layer.objects.active = x
                bpy.ops.object.material_slot_remove_unused(
                        {"object" : scene.objects[0],
                        "selected_objects" : scene.objects
                            }
                        )
                bpy.ops.object.select_all(action='DESELECT')    
                #Reenable_000_TEMP_HIDE():
                print ("To excluded")
                bpy.context.view_layer.active_layer_collection.exclude = False
                print ("excluded")    
                #Emptys_back_to_scene_coll():
                scene_coll = bpy.context.scene.collection
                to_unlink =[]
                for ob in temp_coll.objects:
                    try:
                        scene_coll.objects.link(ob)
                    except RuntimeError:
                        pass
                    to_unlink.append(ob)
                for ob in to_unlink:
                    temp_coll.objects.unlink(ob)  
                #Remove_000_TEMP_HIDE_Collection():
                bpy.data.collections.remove(temp_coll)
                bpy.ops.object.select_all(action='DESELECT')    
                #Cleanup
                bpy.ops.outliner.orphans_purge(do_local_ids=True, do_linked_ids=True, do_recursive=True)
                bpy.ops.outliner.orphans_purge(do_linked_ids=True, do_recursive=True)
                #Save File
                bpy.ops.wm.save_as_mainfile(filepath=SavePath)
                #Select all and delete it
                bpy.ops.object.select_all(action='SELECT')
                bpy.ops.object.delete(use_global=False)
                #Clean unused Data 
                bpy.ops.outliner.orphans_purge(do_local_ids=True, do_linked_ids=True, do_recursive=True)
                bpy.ops.outliner.orphans_purge(do_linked_ids=True, do_recursive=True)
            ### Script Block ###
            allFiles = os.listdir(folderPath)
            #print(allFiles)
            for file in allFiles:
                exec_script_block(file)
            winsound.Beep(1500, 1000)
            self.report({'INFO'}, "DONE!")
            pass # FbxBatchImport Script End
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of FbxBatchImport")
        return self.execute(context)


#######   CleanMaterialSlots
class SNA_OT_Cleanmaterialslots(bpy.types.Operator):
    bl_idname = "sna.cleanmaterialslots"
    bl_label = "CleanMaterialSlots"
    bl_description = "Remove Unused Mat Slots"
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in execute function of CleanMaterialSlots")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            pass # CleanMaterialSlots Script Start
            import bpy
            props = self.properties
            scene = context.scene 
            #----------Clean unused Material Slots
            #Create_000_TEMP_HIDE_Collection():
            bpy.ops.object.select_by_type(type='EMPTY')
            for x in bpy.context.selected_objects:
                bpy.context.view_layer.objects.active = x
            obj = bpy.context.object
            obj_old_coll = obj.users_collection #list of all collection the obj is in
            temp_coll = bpy.data.collections.new(name="000_TEMP_HIDE") #create new coll in data
            bpy.context.scene.collection.children.link(temp_coll) #add new coll to the scene
            for obj in bpy.context.selected_objects:
                temp_coll.objects.link(obj) #link obj to scene
            print ("000_TEMP_HIDE erstellt")
            for obj in bpy.context.selected_objects:
                for ob in obj_old_coll: #unlink from all  precedent obj collections
                    ob.objects.unlink(obj)
            #Recursivly transverse layer_collection for a particular name

            def recurLayerCollection(layerColl, collName):
                found = None
                if (layerColl.name == collName):
                    return layerColl
                for layer in layerColl.children:
                    found = recurLayerCollection(layer, collName)
                    if found:
                        return found
            ###Set 000_TEMP_HIDE Collection Active
            layer_collection = bpy.context.view_layer.layer_collection
            layerColl = recurLayerCollection(layer_collection, '000_TEMP_HIDE')
            bpy.context.view_layer.active_layer_collection = layerColl
            #Disable_000_TEMP_HIDE():    
            bpy.context.view_layer.active_layer_collection.exclude = True
            #RemoveDupliMaterials(): 
            bpy.ops.object.select_by_type(type='MESH')
            for x in bpy.context.selected_objects:
                bpy.context.view_layer.objects.active = x
            bpy.ops.object.material_slot_remove_unused(
                    {"object" : scene.objects[0],
                    "selected_objects" : scene.objects
                        }
                    )
            bpy.ops.object.select_all(action='DESELECT')    
            #Reenable_000_TEMP_HIDE():
            print ("To excluded")
            bpy.context.view_layer.active_layer_collection.exclude = False
            print ("excluded")    
            #Emptys_back_to_scene_coll():
            scene_coll = bpy.context.scene.collection
            to_unlink =[]
            for ob in temp_coll.objects:
                try:
                    scene_coll.objects.link(ob)
                except RuntimeError:
                    pass
                to_unlink.append(ob)
            for ob in to_unlink:
                temp_coll.objects.unlink(ob)  
            #Remove_000_TEMP_HIDE_Collection():
            bpy.data.collections.remove(temp_coll)
            bpy.ops.object.select_all(action='DESELECT')    
            #Cleanup
            bpy.ops.outliner.orphans_purge(do_local_ids=True, do_linked_ids=True, do_recursive=True)
            bpy.ops.outliner.orphans_purge(do_linked_ids=True, do_recursive=True)
            self.report({'INFO'}, "DONE!") 
            pass # CleanMaterialSlots Script End
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of CleanMaterialSlots")
        return self.execute(context)


#######   Clean DupliMaterials
class SNA_OT_Clean_Duplimaterials(bpy.types.Operator):
    bl_idname = "sna.clean_duplimaterials"
    bl_label = "Clean DupliMaterials"
    bl_description = "Remove Duplicated Materials"
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in execute function of Clean DupliMaterials")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            pass # Clean DupliMaterials Script Start
            import bpy
            props = self.properties
            scene = context.scene 

            def replace_material(bad_mat, good_mat):
                bad_mat.user_remap(good_mat)
                bpy.data.materials.remove(bad_mat)

            def get_duplicate_materials(og_material):
                common_name = og_material.name
                if common_name[-3:].isnumeric():
                    common_name = common_name[:-4]
                duplicate_materials = []
                for material in bpy.data.materials:
                    if material is not og_material:
                        name = material.name
                        if name[-3:].isnumeric() and name[-4] == ".":
                            name = name[:-4]
                        if name == common_name:
                            duplicate_materials.append(material)
                text = "{} duplicate materials found"
                print(text.format(len(duplicate_materials)))
                return duplicate_materials

            def remove_all_duplicate_materials():
                i = 0
                while i < len(bpy.data.materials):
                    og_material = bpy.data.materials[i]
                    print("og material: " + og_material.name)
                    # get duplicate materials
                    duplicate_materials = get_duplicate_materials(og_material)
                    # replace all duplicates
                    for duplicate_material in duplicate_materials:
                        replace_material(duplicate_material, og_material)
                    # adjust name to no trailing numbers
                    if og_material.name[-3:].isnumeric() and og_material.name[-4] == ".":
                        og_material.name = og_material.name[:-4]
                    i = i+1
            remove_all_duplicate_materials()

            def replace_material(bad_mat, good_mat):
                bad_mat.user_remap(good_mat)
                bpy.data.materials.remove(bad_mat)

            def get_duplicate_materials(og_material):
                common_name = og_material.name
                if common_name[-3:].isnumeric():
                    common_name = common_name[:-4]
                duplicate_materials = []
                for material in bpy.data.materials:
                    if material is not og_material:
                        name = material.name
                        if name[-3:].isnumeric() and name[-4] == ".":
                            name = name[:-4]
                        if name == common_name:
                            duplicate_materials.append(material)
                text = "{} duplicate materials found"
                print(text.format(len(duplicate_materials)))
                return duplicate_materials

            def remove_all_duplicate_materials():
                i = 0
                while i < len(bpy.data.materials):
                    og_material = bpy.data.materials[i]
                    print("og material: " + og_material.name)
                    # get duplicate materials
                    duplicate_materials = get_duplicate_materials(og_material)
                    # replace all duplicates
                    for duplicate_material in duplicate_materials:
                        replace_material(duplicate_material, og_material)
                    # adjust name to no trailing numbers
                    if og_material.name[-3:].isnumeric() and og_material.name[-4] == ".":
                        og_material.name = og_material.name[:-4]
                    i = i+1
            remove_all_duplicate_materials()
            bpy.ops.outliner.orphans_purge(do_local_ids=True, do_linked_ids=True, do_recursive=True)
            self.report({'INFO'}, "DONE!")
            pass # Clean DupliMaterials Script End
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of Clean DupliMaterials")
        return self.execute(context)


class SNA_OT_Clean_Up(bpy.types.Operator):
    bl_idname = "sna.clean_up"
    bl_label = "Clean Up"
    bl_description = "Remove local and linked Data"
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in execute function of Clean Up")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            try: exec(r"bpy.ops.outliner.orphans_purge(do_local_ids=True, do_linked_ids=True, do_recursive=True)")
            except Exception as exc: sn_handle_script_line_exception(exc, r"bpy.ops.outliner.orphans_purge(do_local_ids=True, do_linked_ids=True, do_recursive=True)")
            try: exec(r"bpy.ops.outliner.orphans_purge(do_linked_ids=True, do_recursive=True)")
            except Exception as exc: sn_handle_script_line_exception(exc, r"bpy.ops.outliner.orphans_purge(do_linked_ids=True, do_recursive=True)")
            try: exec(r"self.report({'INFO'}, 'CLEANED!')")
            except Exception as exc: sn_handle_script_line_exception(exc, r"self.report({'INFO'}, 'CLEANED!')")
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of Clean Up")
        return self.execute(context)


#######   Finalize
class SNA_OT_Packtoblend(bpy.types.Operator):
    bl_idname = "sna.packtoblend"
    bl_label = "PackToBlend"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in execute function of PackToBlend")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            if bpy.context.scene.ispacktoblend:
                pass
            else:
                bpy.context.scene.ispacktoblend = True
                print(sn_cast_string(bpy.context.scene.ispacktoblend))
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of PackToBlend")
        return self.execute(context)


class SNA_OT_Packtotexturefolder(bpy.types.Operator):
    bl_idname = "sna.packtotexturefolder"
    bl_label = "PackToTextureFolder"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in execute function of PackToTextureFolder")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            if bpy.context.scene.ispacktoblend:
                bpy.context.scene.ispacktoblend = False
                print(sn_cast_string(bpy.context.scene.ispacktoblend))
            else:
                pass
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of PackToTextureFolder")
        return self.execute(context)


class SNA_OT_Finalize(bpy.types.Operator):
    bl_idname = "sna.finalize"
    bl_label = "Finalize"
    bl_description = "Collect all Textures and save them to //textures"
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            if bpy.context.scene.ispacktoblend:
                try: exec(r"bpy.ops.file.pack_all()")
                except Exception as exc: sn_handle_script_line_exception(exc, r"bpy.ops.file.pack_all()")
                try: exec(r"self.report({'INFO'}, 'DONE!')")
                except Exception as exc: sn_handle_script_line_exception(exc, r"self.report({'INFO'}, 'DONE!')")
            else:
                try: exec(r"bpy.ops.file.pack_all()")
                except Exception as exc: sn_handle_script_line_exception(exc, r"bpy.ops.file.pack_all()")
                try: exec(r"bpy.ops.file.unpack_all(method='WRITE_LOCAL')")
                except Exception as exc: sn_handle_script_line_exception(exc, r"bpy.ops.file.unpack_all(method='WRITE_LOCAL')")
                try: exec(r"bpy.ops.outliner.orphans_purge(do_local_ids=True, do_linked_ids=True, do_recursive=True)")
                except Exception as exc: sn_handle_script_line_exception(exc, r"bpy.ops.outliner.orphans_purge(do_local_ids=True, do_linked_ids=True, do_recursive=True)")
                try: exec(r"bpy.ops.outliner.orphans_purge(do_linked_ids=True, do_recursive=True)")
                except Exception as exc: sn_handle_script_line_exception(exc, r"bpy.ops.outliner.orphans_purge(do_linked_ids=True, do_recursive=True)")
                try: exec(r"bpy.ops.file.make_paths_relative()")
                except Exception as exc: sn_handle_script_line_exception(exc, r"bpy.ops.file.make_paths_relative()")
                try: exec(r"self.report({'INFO'}, 'DONE!')")
                except Exception as exc: sn_handle_script_line_exception(exc, r"self.report({'INFO'}, 'DONE!')")
        except Exception as exc:
            print(str(exc) + " | Error in execute function of Finalize")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of Finalize")
        return context.window_manager.invoke_props_dialog(self, width=300)

    def draw(self, context):
        layout = self.layout
        try:
            row = layout.row(align=True)
            row.enabled = True
            row.alert = False
            row.scale_x = 1.0
            row.scale_y = 1.0
            op = row.operator("sna.packtoblend",text=r"Pack to Blend file",emboss=True,depress=bpy.context.scene.ispacktoblend,icon_value=695)
            op = row.operator("sna.packtotexturefolder",text=r"Pack to Texture Folder",emboss=True,depress=not bpy.context.scene.ispacktoblend,icon_value=693)
        except Exception as exc:
            print(str(exc) + " | Error in draw function of Finalize")


###############   REGISTER ICONS
def sn_register_icons():
    icons = []
    bpy.types.Scene.fbx_batch_import_tools_icons = bpy.utils.previews.new()
    icons_dir = os.path.join( os.path.dirname( __file__ ), "icons" )
    for icon in icons:
        bpy.types.Scene.fbx_batch_import_tools_icons.load( icon, os.path.join( icons_dir, icon + ".png" ), 'IMAGE' )

def sn_unregister_icons():
    bpy.utils.previews.remove( bpy.types.Scene.fbx_batch_import_tools_icons )


###############   REGISTER PROPERTIES
def sn_register_properties():
    bpy.types.Scene.fbxdirpath = bpy.props.StringProperty(name='FbxDirPath',description='',subtype='DIR_PATH',options=set(),default='')
    bpy.types.Scene.matfilepath = bpy.props.StringProperty(name='MatFilePath',description='',subtype='FILE_PATH',options=set(),default='C:/Users/EH/Desktop/Agilent/3D_Library/Vorlagen/Materials.blend')
    bpy.types.Scene.ispacktoblend = bpy.props.BoolProperty(name='IsPackToBlend',description='',options=set(),default=True)

def sn_unregister_properties():
    del bpy.types.Scene.fbxdirpath
    del bpy.types.Scene.matfilepath
    del bpy.types.Scene.ispacktoblend


###############   REGISTER ADDON
def register():
    sn_register_icons()
    sn_register_properties()
    bpy.utils.register_class(SNA_PT_FBX_Batch_Import_tools_7D304)
    bpy.utils.register_class(SNA_OT_)
    bpy.utils.register_class(SNA_OT_Selectlinked)
    bpy.utils.register_class(SNA_OT_Linkmaterials)
    bpy.utils.register_class(SNA_OT_Fbxbatchimport)
    bpy.utils.register_class(SNA_OT_Cleanmaterialslots)
    bpy.utils.register_class(SNA_OT_Clean_Duplimaterials)
    bpy.utils.register_class(SNA_OT_Clean_Up)
    bpy.utils.register_class(SNA_OT_Packtoblend)
    bpy.utils.register_class(SNA_OT_Packtotexturefolder)
    bpy.utils.register_class(SNA_OT_Finalize)


###############   UNREGISTER ADDON
def unregister():
    sn_unregister_icons()
    sn_unregister_properties()
    bpy.utils.unregister_class(SNA_OT_Finalize)
    bpy.utils.unregister_class(SNA_OT_Packtotexturefolder)
    bpy.utils.unregister_class(SNA_OT_Packtoblend)
    bpy.utils.unregister_class(SNA_OT_Clean_Up)
    bpy.utils.unregister_class(SNA_OT_Clean_Duplimaterials)
    bpy.utils.unregister_class(SNA_OT_Cleanmaterialslots)
    bpy.utils.unregister_class(SNA_OT_Fbxbatchimport)
    bpy.utils.unregister_class(SNA_OT_Linkmaterials)
    bpy.utils.unregister_class(SNA_OT_Selectlinked)
    bpy.utils.unregister_class(SNA_OT_)
    bpy.utils.unregister_class(SNA_PT_FBX_Batch_Import_tools_7D304)