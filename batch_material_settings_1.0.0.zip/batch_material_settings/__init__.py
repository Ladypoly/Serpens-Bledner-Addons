# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.
#
# This addon was created with the Serpens - Visual Scripting Addon.
# This code is generated from nodes and is not intended for manual editing.
# You can find out more about Serpens at <https://blendermarket.com/products/serpens>.


bl_info = {
    "name": "Batch Material Settings",
    "description": "Batch Material Settings",
    "author": "Elin",
    "version": (1, 0, 0),
    "blender": (2, 90, 3),
    "location": "Material Properties",
    "warning": "",
    "wiki_url": "",
    "tracker_url": "",
    "category": "Material"
}


###############   IMPORTS
import bpy
from bpy.utils import previews
import os
import math


###############   INITALIZE VARIABLES
batch_material_settings = {
    "toggelopaque": True, 
    "toggleablend": False, 
    "toggleaclip": False, 
    "toggleahashed": False, 
    }


###############   SERPENS FUNCTIONS
def exec_line(line):
    exec(line)

def sn_print(tree_name, *args):
    if tree_name in bpy.data.node_groups:
        item = bpy.data.node_groups[tree_name].sn_graphs[0].prints.add()
        for arg in args:
            item.value += str(arg) + ";;;"
        for area in bpy.context.screen.areas:
            area.tag_redraw()
    print(*args)

def sn_cast_string(value):
    return str(value)

def sn_cast_boolean(value):
    if type(value) == tuple:
        for data in value:
            if bool(data):
                return True
        return False
    return bool(value)

def sn_cast_float(value):
    if type(value) == str:
        try:
            value = float(value)
            return value
        except:
            return float(bool(value))
    elif type(value) == tuple:
        return float(value[0])
    elif type(value) == list:
        return float(len(value))
    elif not type(value) in [float, int, bool]:
        try:
            value = len(value)
            return float(value)
        except:
            return float(bool(value))
    return float(value)

def sn_cast_int(value):
    return int(sn_cast_float(value))

def sn_cast_boolean_vector(value, size):
    if type(value) in [str, bool, int, float]:
        return_value = []
        for i in range(size):
            return_value.append(bool(value))
        return tuple(return_value)
    elif type(value) == tuple:
        return_value = []
        for i in range(size):
            return_value.append(bool(value[i]) if len(value) > i else bool(value[0]))
        return tuple(return_value)
    elif type(value) == list:
        return sn_cast_boolean_vector(tuple(value), size)
    else:
        try:
            value = tuple(value)
            return sn_cast_boolean_vector(value, size)
        except:
            return sn_cast_boolean_vector(bool(value), size)

def sn_cast_float_vector(value, size):
    if type(value) in [str, bool, int, float]:
        return_value = []
        for i in range(size):
            return_value.append(sn_cast_float(value))
        return tuple(return_value)
    elif type(value) == tuple:
        return_value = []
        for i in range(size):
            return_value.append(sn_cast_float(value[i]) if len(value) > i else sn_cast_float(value[0]))
        return tuple(return_value)
    elif type(value) == list:
        return sn_cast_float_vector(tuple(value), size)
    else:
        try:
            value = tuple(value)
            return sn_cast_float_vector(value, size)
        except:
            return sn_cast_float_vector(sn_cast_float(value), size)

def sn_cast_int_vector(value, size):
    return tuple(map(int, sn_cast_float_vector(value, size)))

def sn_cast_color(value, use_alpha):
    length = 4 if use_alpha else 3
    value = sn_cast_float_vector(value, length)
    tuple_list = []
    for data in range(length):
        data = value[data] if len(value) > data else value[0]
        tuple_list.append(sn_cast_float(min(1, max(0, data))))
    return tuple(tuple_list)

def sn_cast_list(value):
    if type(value) in [str, tuple, list]:
        return list(value)
    elif type(value) in [int, float, bool]:
        return [value]
    else:
        try:
            value = list(value)
            return value
        except:
            return [value]

def sn_cast_blend_data(value):
    if hasattr(value, "bl_rna"):
        return value
    elif type(value) in [tuple, bool, int, float, list]:
        return None
    elif type(value) == str:
        try:
            value = eval(value)
            return value
        except:
            return None
    else:
        return None

def sn_cast_enum(string, enum_values):
    for item in enum_values:
        if item[1] == string:
            return item[0]
        elif item[0] == string.upper():
            return item[0]
    return string


###############   IMPERATIVE CODE
###############   EVALUATED CODE
#######   Batch Material Settings
class SNA_OT_Setopaque(bpy.types.Operator):
    bl_idname = "sna.setopaque"
    bl_label = "SetOpaque"
    bl_description = "Set shading mode to Opaque"
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in execute function of SetOpaque")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            if batch_material_settings["toggelopaque"]:
                pass
            else:
                batch_material_settings["toggelopaque"] = True
                batch_material_settings["toggleablend"] = False
                batch_material_settings["toggleaclip"] = False
                batch_material_settings["toggleahashed"] = False
                bpy.context.scene.isopaque = True
            bpy.context.scene.isablend = False
            bpy.context.scene.isaclip = False
            bpy.context.scene.isahashed = False
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of SetOpaque")
        return self.execute(context)


class SNA_OT_Setablend(bpy.types.Operator):
    bl_idname = "sna.setablend"
    bl_label = "SetA-Blend"
    bl_description = "Set shading mode to Alpha Blend"
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in execute function of SetA-Blend")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            if batch_material_settings["toggleablend"]:
                pass
            else:
                batch_material_settings["toggleablend"] = True
                batch_material_settings["toggelopaque"] = False
                batch_material_settings["toggleaclip"] = False
                batch_material_settings["toggleahashed"] = False
                bpy.context.scene.isablend = True
            bpy.context.scene.isopaque = False
            bpy.context.scene.isaclip = False
            bpy.context.scene.isahashed = False
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of SetA-Blend")
        return self.execute(context)


class SNA_OT_Setaclip(bpy.types.Operator):
    bl_idname = "sna.setaclip"
    bl_label = "SetA-Clip"
    bl_description = "Set shading mode to Alpha Clip"
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in execute function of SetA-Clip")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            if batch_material_settings["toggleaclip"]:
                pass
            else:
                batch_material_settings["toggleaclip"] = True
                batch_material_settings["toggelopaque"] = False
                batch_material_settings["toggleablend"] = False
                batch_material_settings["toggleahashed"] = False
                bpy.context.scene.isaclip = True
            bpy.context.scene.isopaque = False
            bpy.context.scene.isablend = False
            bpy.context.scene.isahashed = False
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of SetA-Clip")
        return self.execute(context)


class SNA_OT_Setahashed(bpy.types.Operator):
    bl_idname = "sna.setahashed"
    bl_label = "SetA-Hashed"
    bl_description = "Set shading mode to Alpha Hashed"
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in execute function of SetA-Hashed")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            if batch_material_settings["toggleahashed"]:
                pass
            else:
                batch_material_settings["toggleahashed"] = True
                batch_material_settings["toggelopaque"] = False
                batch_material_settings["toggleablend"] = False
                batch_material_settings["toggleaclip"] = False
                bpy.context.scene.isahashed = True
            bpy.context.scene.isopaque = False
            bpy.context.scene.isablend = False
            bpy.context.scene.isaclip = False
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of SetA-Hashed")
        return self.execute(context)


class SNA_OT_Applysettings(bpy.types.Operator):
    bl_idname = "sna.applysettings"
    bl_label = "ApplySettings"
    bl_description = "Apply defined settings to all materials on selected objects"
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in execute function of ApplySettings")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            pass # SetMaterialProperties Script Start
            import bpy
            """Set Variables"""
            context = bpy.context
            scene = context.scene
            #Get original object
            ActiveObjName = context.active_object.name
            MetallicValue = bpy.context.scene.metallicvalue
            Metallic_toggle = bpy.context.scene.metallictoggle
            SpecularValue = bpy.context.scene.specularvalue
            Specular_toggle = bpy.context.scene.speculartoggle
            RoughnessValue = bpy.context.scene.roughnessvalue
            Roughness_toggle = bpy.context.scene.roughnesstoggle
            RemoveNormalMap = bpy.context.scene.removenormalmap
            if bpy.context.scene.allmeshes:
                bpy.ops.object.select_by_type(type='MESH')
            if bpy.context.scene.isopaque:
                for o in context.selected_objects:
                    o.active_material.blend_method = 'OPAQUE'
            if bpy.context.scene.isablend:
                for o in context.selected_objects:
                    o.active_material.blend_method = 'BLEND'    
            if bpy.context.scene.isaclip:        
                for o in context.selected_objects:
                    o.active_material.blend_method = 'CLIP'
            if bpy.context.scene.isahashed:        
                for o in context.selected_objects:
                    o.active_material.blend_method = 'HASHED'    
            """Start Script"""

            #def remove_links(socket: bpy.types.NodeSocket, node_tree: bpy.types.NodeTree):
            #    """Remove all links from or to the given socket"""
            #    for link in socket.links:
            #        node_tree.links.remove(link)

            def fix_node(node: bpy.types.Node, node_tree: bpy.types.NodeTree):
                """Adjust the properties if the node is a Principled BSDF"""
                if node.type == 'BSDF_PRINCIPLED':
                    if Metallic_toggle:
                        node.inputs['Metallic'].default_value = MetallicValue
                    if Specular_toggle:   
                        node.inputs['Specular'].default_value = SpecularValue
                    if Roughness_toggle: 
                        node.inputs['Roughness'].default_value = RoughnessValue
                    #remove_links(node.inputs['Alpha'], node_tree)

            def fix_material(material: bpy.types.Material):
                """Fix the nodes of the given material"""
                for node in material.node_tree.nodes:
                    fix_node(node, material.node_tree)
            """Fix the materials of the selected objects"""
            if bpy.context.scene.allmeshes:
                #bpy.context.area.ui_type = 'VIEW_3D'
                bpy.ops.object.select_by_type(type='MESH')
            for object in bpy.context.selected_objects:
                for material_slot in object.material_slots:
                    fix_material(material_slot.material)
            if RemoveNormalMap:
                mats = set(slot.material for o in bpy.context.selected_objects for slot in o.material_slots)
                # Iterate through all unique materials
                for mat in mats:
                    nodes = mat.node_tree.nodes
                    for node in nodes:
                        if node.name == "Normal Map":
                            node_to_delete =  mat.node_tree.nodes['Normal Map']
                            mat.node_tree.nodes.remove(node_to_delete)    
            #bpy.ops.object.select_all(action='DESELECT')
            if context.scene.allmeshes:
                bpy.ops.object.select_all(action='DESELECT') 
                #select original object again
                bpy.data.objects[ActiveObjName].select_set(True)
                bpy.context.view_layer.objects.active = bpy.data.objects[ActiveObjName]
            pass # SetMaterialProperties Script End
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of ApplySettings")
        return self.execute(context)


class SNA_PT_Batch_Material_Proberties_818FB(bpy.types.Panel):
    bl_label = "Batch Material Proberties"
    bl_idname = "SNA_PT_Batch_Material_Proberties_818FB"
    bl_space_type = "PROPERTIES"
    bl_region_type = "WINDOW"
    bl_context = 'material'
    bl_order = 0


    @classmethod
    def poll(cls, context):
        return True

    def draw_header(self, context):
        try:
            layout = self.layout
        except Exception as exc:
            print(str(exc) + " | Error in Batch Material Proberties panel header")

    def draw(self, context):
        try:
            layout = self.layout
            box = layout.box()
            box.enabled = True
            box.alert = False
            box.scale_x = 1.0
            box.scale_y = 1.0
            box.label(text=r"Set Principled BSDF Proberties",icon_value=0)
            col = box.column(align=True)
            col.enabled = True
            col.alert = False
            col.scale_x = 1.0
            col.scale_y = 1.0
            row = col.row(align=True)
            row.enabled = True
            row.alert = False
            row.scale_x = 1.0
            row.scale_y = 1.0
            row.prop(bpy.context.scene,'metallicvalue',icon_value=0,text=r"Metallic value",emboss=True,slider=True,)
            row.prop(bpy.context.scene,'metallictoggle',icon_value=36,text=r"",emboss=True,toggle=True,invert_checkbox=False,)
            row = col.row(align=True)
            row.enabled = True
            row.alert = False
            row.scale_x = 1.0
            row.scale_y = 1.0
            row.prop(bpy.context.scene,'specularvalue',icon_value=0,text=r"Specular value",emboss=True,slider=True,)
            row.prop(bpy.context.scene,'speculartoggle',icon_value=36,text=r"",emboss=True,toggle=True,invert_checkbox=False,)
            row = col.row(align=True)
            row.enabled = True
            row.alert = False
            row.scale_x = 1.0
            row.scale_y = 1.0
            row.prop(bpy.context.scene,'roughnessvalue',icon_value=0,text=r"Roughness value",emboss=True,slider=True,)
            row.prop(bpy.context.scene,'roughnesstoggle',icon_value=36,text=r"",emboss=True,toggle=False,invert_checkbox=False,)
            col.prop(bpy.context.scene,'removenormalmap',icon_value=3,text=r"Remove Normal Map",emboss=True,toggle=True,invert_checkbox=False,)
            row = box.row(align=True)
            row.enabled = True
            row.alert = False
            row.scale_x = 1.0
            row.scale_y = 1.25
            op = row.operator("sna.setopaque",text=r"Opaque",emboss=batch_material_settings["toggelopaque"],depress=False,icon_value=626)
            op = row.operator("sna.setablend",text=r"A-Blend",emboss=batch_material_settings["toggleablend"],depress=False,icon_value=627)
            op = row.operator("sna.setaclip",text=r"A-Clip",emboss=batch_material_settings["toggleaclip"],depress=False,icon_value=628)
            op = row.operator("sna.setahashed",text=r"A-Hashed",emboss=batch_material_settings["toggleahashed"],depress=False,icon_value=627)
            row = layout.row(align=True)
            row.enabled = True
            row.alert = False
            row.scale_x = 1.0
            row.scale_y = 1.0
            col = row.column(align=True)
            col.enabled = True
            col.alert = False
            col.scale_x = 0.6000000238418579
            col.scale_y = 2.0
            col.prop(bpy.context.scene,'allmeshes',icon_value=130,text=r"All Objects",emboss=True,toggle=True,invert_checkbox=False,)
            row.separator(factor=1.0)
            col = row.column(align=True)
            col.enabled = True
            col.alert = False
            col.scale_x = 1.0
            col.scale_y = 2.0
            op = col.operator("sna.applysettings",text=r"Apply Settings",emboss=True,depress=False,icon_value=495)
        except Exception as exc:
            print(str(exc) + " | Error in Batch Material Proberties panel")


###############   REGISTER ICONS
def sn_register_icons():
    icons = []
    bpy.types.Scene.batch_material_settings_icons = bpy.utils.previews.new()
    icons_dir = os.path.join( os.path.dirname( __file__ ), "icons" )
    for icon in icons:
        bpy.types.Scene.batch_material_settings_icons.load( icon, os.path.join( icons_dir, icon + ".png" ), 'IMAGE' )

def sn_unregister_icons():
    bpy.utils.previews.remove( bpy.types.Scene.batch_material_settings_icons )


###############   REGISTER PROPERTIES
def sn_register_properties():
    bpy.types.Scene.isopaque = bpy.props.BoolProperty(name='isOpaque',description='Set shading mode to opaque',options=set(),default=True)
    bpy.types.Scene.isablend = bpy.props.BoolProperty(name='isA-Blend',description='Set shading mode to Alpha Blend',options=set(),default=False)
    bpy.types.Scene.isaclip = bpy.props.BoolProperty(name='isA-Clip',description='Set shading mode to Alpha Clip',options=set(),default=False)
    bpy.types.Scene.isahashed = bpy.props.BoolProperty(name='isA-Hashed',description='Set shading mode to Alpha Hashed',options=set(),default=False)
    bpy.types.Scene.metallicvalue = bpy.props.FloatProperty(name='MetallicValue',description='Set Metallic value in Principle BSDF Shader',subtype='NONE',unit='NONE',options={'HIDDEN'},precision=2, default=0.009999999776482582,min=0.009999999776482582,max=0.9900000095367432)
    bpy.types.Scene.specularvalue = bpy.props.FloatProperty(name='SpecularValue',description='Set Specular value in Principle BSDF Shader',subtype='NONE',unit='NONE',options=set(),precision=2, default=0.009999999776482582,min=0.009999999776482582,max=0.9900000095367432)
    bpy.types.Scene.roughnessvalue = bpy.props.FloatProperty(name='RoughnessValue',description='Set Roughness value in Principle BSDF Shader',subtype='NONE',unit='NONE',options=set(),precision=2, default=0.9900000095367432,min=0.009999999776482582,max=0.9900000095367432)
    bpy.types.Scene.allmeshes = bpy.props.BoolProperty(name='AllMeshes',description='Apply defined settings to all Meshes',options=set(),default=False)
    bpy.types.Scene.metallictoggle = bpy.props.BoolProperty(name='MetallicToggle',description='Apply Metallic value settings',options=set(),default=True)
    bpy.types.Scene.speculartoggle = bpy.props.BoolProperty(name='SpecularToggle',description='Apply Specular value settings',options=set(),default=True)
    bpy.types.Scene.roughnesstoggle = bpy.props.BoolProperty(name='RoughnessToggle',description='Apply Roughness value settings',options=set(),default=True)
    bpy.types.Scene.removenormalmap = bpy.props.BoolProperty(name='RemoveNormalMap',description='Remove normal map nodes (usefull for imported meshes without normal map textures)',options=set(),default=False)

def sn_unregister_properties():
    del bpy.types.Scene.isopaque
    del bpy.types.Scene.isablend
    del bpy.types.Scene.isaclip
    del bpy.types.Scene.isahashed
    del bpy.types.Scene.metallicvalue
    del bpy.types.Scene.specularvalue
    del bpy.types.Scene.roughnessvalue
    del bpy.types.Scene.allmeshes
    del bpy.types.Scene.metallictoggle
    del bpy.types.Scene.speculartoggle
    del bpy.types.Scene.roughnesstoggle
    del bpy.types.Scene.removenormalmap


###############   REGISTER ADDON
def register():
    sn_register_icons()
    sn_register_properties()
    bpy.utils.register_class(SNA_OT_Setopaque)
    bpy.utils.register_class(SNA_OT_Setablend)
    bpy.utils.register_class(SNA_OT_Setaclip)
    bpy.utils.register_class(SNA_OT_Setahashed)
    bpy.utils.register_class(SNA_OT_Applysettings)
    bpy.utils.register_class(SNA_PT_Batch_Material_Proberties_818FB)


###############   UNREGISTER ADDON
def unregister():
    sn_unregister_icons()
    sn_unregister_properties()
    bpy.utils.unregister_class(SNA_PT_Batch_Material_Proberties_818FB)
    bpy.utils.unregister_class(SNA_OT_Applysettings)
    bpy.utils.unregister_class(SNA_OT_Setahashed)
    bpy.utils.unregister_class(SNA_OT_Setaclip)
    bpy.utils.unregister_class(SNA_OT_Setablend)
    bpy.utils.unregister_class(SNA_OT_Setopaque)