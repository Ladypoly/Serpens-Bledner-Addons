# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.
#
# This addon was created with the Serpens - Visual Scripting Addon.
# This code is generated from nodes and is not intended for manual editing.
# You can find out more about Serpens at <https://blendermarket.com/products/serpens>.


bl_info = {
    "name": "Selection Sets",
    "description": "",
    "author": "Elin",
    "version": (1, 0, 0),
    "blender": (3, 0, 0),
    "location": "Tool",
    "warning": "",
    "wiki_url": "",
    "tracker_url": "",
    "category": "3D View"
}


###############   IMPORTS
import bpy
from bpy.utils import previews
import os
import math


###############   INITALIZE VARIABLES
selection_sets = {
    "selection_01": [], 
    "selection_02": [], 
    "selection_03": [], 
    "selection_04": [], 
    "selection_05": [], 
    "selection_06": [], 
    }


###############   SERPENS FUNCTIONS
def exec_line(line):
    exec(line)

def sn_print(tree_name, *args):
    if tree_name in bpy.data.node_groups:
        item = bpy.data.node_groups[tree_name].sn_graphs[0].prints.add()
        for arg in args:
            item.value += str(arg) + ";;;"
        if bpy.context and bpy.context.screen:
            for area in bpy.context.screen.areas:
                area.tag_redraw()
    print(*args)

def sn_cast_string(value):
    return str(value)

def sn_cast_boolean(value):
    if type(value) == tuple:
        for data in value:
            if bool(data):
                return True
        return False
    return bool(value)

def sn_cast_float(value):
    if type(value) == str:
        try:
            value = float(value)
            return value
        except:
            return float(bool(value))
    elif type(value) == tuple:
        return float(value[0])
    elif type(value) == list:
        return float(len(value))
    elif not type(value) in [float, int, bool]:
        try:
            value = len(value)
            return float(value)
        except:
            return float(bool(value))
    return float(value)

def sn_cast_int(value):
    return int(sn_cast_float(value))

def sn_cast_boolean_vector(value, size):
    if type(value) in [str, bool, int, float]:
        return_value = []
        for i in range(size):
            return_value.append(bool(value))
        return tuple(return_value)
    elif type(value) == tuple:
        return_value = []
        for i in range(size):
            return_value.append(bool(value[i]) if len(value) > i else bool(value[0]))
        return tuple(return_value)
    elif type(value) == list:
        return sn_cast_boolean_vector(tuple(value), size)
    else:
        try:
            value = tuple(value)
            return sn_cast_boolean_vector(value, size)
        except:
            return sn_cast_boolean_vector(bool(value), size)

def sn_cast_float_vector(value, size):
    if type(value) in [str, bool, int, float]:
        return_value = []
        for i in range(size):
            return_value.append(sn_cast_float(value))
        return tuple(return_value)
    elif type(value) == tuple:
        return_value = []
        for i in range(size):
            return_value.append(sn_cast_float(value[i]) if len(value) > i else sn_cast_float(value[0]))
        return tuple(return_value)
    elif type(value) == list:
        return sn_cast_float_vector(tuple(value), size)
    else:
        try:
            value = tuple(value)
            return sn_cast_float_vector(value, size)
        except:
            return sn_cast_float_vector(sn_cast_float(value), size)

def sn_cast_int_vector(value, size):
    return tuple(map(int, sn_cast_float_vector(value, size)))

def sn_cast_color(value, use_alpha):
    length = 4 if use_alpha else 3
    value = sn_cast_float_vector(value, length)
    tuple_list = []
    for data in range(length):
        data = value[data] if len(value) > data else value[0]
        tuple_list.append(sn_cast_float(min(1, max(0, data))))
    return tuple(tuple_list)

def sn_cast_list(value):
    if type(value) in [str, tuple, list]:
        return list(value)
    elif type(value) in [int, float, bool]:
        return [value]
    else:
        try:
            value = list(value)
            return value
        except:
            return [value]

def sn_cast_blend_data(value):
    if hasattr(value, "bl_rna"):
        return value
    elif type(value) in [tuple, bool, int, float, list]:
        return None
    elif type(value) == str:
        try:
            value = eval(value)
            return value
        except:
            return None
    else:
        return None

def sn_cast_enum(string, enum_values):
    for item in enum_values:
        if item[1] == string:
            return item[0]
        elif item[0] == string.upper():
            return item[0]
    return string


###############   IMPERATIVE CODE
###############   EVALUATED CODE
#######   Selection Sets
class SNA_PT_Selection_Sets_9CF98(bpy.types.Panel):
    bl_label = "Selection Sets"
    bl_idname = "SNA_PT_Selection_Sets_9CF98"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = 'Tool'
    bl_order = 0


    @classmethod
    def poll(cls, context):
        return True

    def draw_header(self, context):
        try:
            layout = self.layout
        except Exception as exc:
            print(str(exc) + " | Error in Selection Sets panel header")

    def draw(self, context):
        try:
            layout = self.layout
            col = layout.column(align=False)
            col.enabled = True
            col.alert = False
            col.scale_x = 1.0
            col.scale_y = 1.0
            col.prop(bpy.context.scene,'i_count',text=r"Selection Sets",emboss=True,slider=True,)
            if bpy.context.scene.i_count > 0:
                row = col.row(align=True)
                row.enabled = True
                row.alert = False
                row.scale_x = 2.0
                row.scale_y = 1.0
                op = row.operator("sna.saveselected1",text=r"",emboss=True,depress=False,icon_value=70)
                op = row.operator("sna.restoreselected1",text=r"",emboss=True,depress=False,icon_value=108)
                row.prop(bpy.context.scene,'s_1',icon_value=0,text=r"",emboss=True,)
            else:
                pass
            if bpy.context.scene.i_count > 1:
                row = col.row(align=True)
                row.enabled = True
                row.alert = False
                row.scale_x = 2.0
                row.scale_y = 1.0
                op = row.operator("sna.saveselected2",text=r"",emboss=True,depress=False,icon_value=70)
                op = row.operator("sna.restoreselected2",text=r"",emboss=True,depress=False,icon_value=108)
                row.prop(bpy.context.scene,'s_2',icon_value=0,text=r"",emboss=True,)
            else:
                pass
            if bpy.context.scene.i_count > 2:
                row = col.row(align=True)
                row.enabled = True
                row.alert = False
                row.scale_x = 2.0
                row.scale_y = 1.0
                op = row.operator("sna.saveselected3",text=r"",emboss=True,depress=False,icon_value=70)
                op = row.operator("sna.restoreselected3",text=r"",emboss=True,depress=False,icon_value=108)
                row.prop(bpy.context.scene,'s_3',icon_value=0,text=r"",emboss=True,)
            else:
                pass
            if bpy.context.scene.i_count > 3:
                row = col.row(align=True)
                row.enabled = True
                row.alert = False
                row.scale_x = 2.0
                row.scale_y = 1.0
                op = row.operator("sna.saveselected4",text=r"",emboss=True,depress=False,icon_value=70)
                op = row.operator("sna.restoreselected4",text=r"",emboss=True,depress=False,icon_value=108)
                row.prop(bpy.context.scene,'s_4',icon_value=0,text=r"",emboss=True,)
            else:
                pass
            if bpy.context.scene.i_count > 4:
                row = col.row(align=True)
                row.enabled = True
                row.alert = False
                row.scale_x = 2.0
                row.scale_y = 1.0
                op = row.operator("sna.saveselected5",text=r"",emboss=True,depress=False,icon_value=70)
                op = row.operator("sna.restoreselected5",text=r"",emboss=True,depress=False,icon_value=108)
                row.prop(bpy.context.scene,'s_5',icon_value=0,text=r"",emboss=True,)
            else:
                pass
            if bpy.context.scene.i_count > 5:
                row = col.row(align=True)
                row.enabled = True
                row.alert = False
                row.scale_x = 2.0
                row.scale_y = 1.0
                op = row.operator("sna.saveselected6",text=r"",emboss=True,depress=False,icon_value=70)
                op = row.operator("sna.restoreselected6",text=r"",emboss=True,depress=False,icon_value=108)
                row.prop(bpy.context.scene,'s_6',icon_value=0,text=r"",emboss=True,)
            else:
                pass
        except Exception as exc:
            print(str(exc) + " | Error in Selection Sets panel")


class SNA_OT_Restoreselected2(bpy.types.Operator):
    bl_idname = "sna.restoreselected2"
    bl_label = "RestoreSelected2"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in execute function of RestoreSelected2")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            for_node_181A8 = 0
            for_node_index_181A8 = 0
            for for_node_index_181A8, for_node_181A8 in enumerate(selection_sets["selection_02"]):
                run_function_on_4A941 = sn_cast_blend_data(for_node_181A8).select_set(state=True, view_layer=None, )
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of RestoreSelected2")
        return self.execute(context)


class SNA_OT_Saveselected2(bpy.types.Operator):
    bl_idname = "sna.saveselected2"
    bl_label = "SaveSelected2"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in execute function of SaveSelected2")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            selection_sets["selection_02"] = sn_cast_list(bpy.context.selected_objects)
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of SaveSelected2")
        return self.execute(context)


class SNA_OT_Saveselected3(bpy.types.Operator):
    bl_idname = "sna.saveselected3"
    bl_label = "SaveSelected3"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in execute function of SaveSelected3")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            selection_sets["selection_03"] = sn_cast_list(bpy.context.selected_objects)
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of SaveSelected3")
        return self.execute(context)


class SNA_OT_Restoreselected3(bpy.types.Operator):
    bl_idname = "sna.restoreselected3"
    bl_label = "RestoreSelected3"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in execute function of RestoreSelected3")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            for_node_DD47E = 0
            for_node_index_DD47E = 0
            for for_node_index_DD47E, for_node_DD47E in enumerate(selection_sets["selection_03"]):
                run_function_on_9849B = sn_cast_blend_data(for_node_DD47E).select_set(state=True, view_layer=None, )
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of RestoreSelected3")
        return self.execute(context)


class SNA_OT_Restoreselected1(bpy.types.Operator):
    bl_idname = "sna.restoreselected1"
    bl_label = "RestoreSelected1"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in execute function of RestoreSelected1")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            for_node_64BD0 = 0
            for_node_index_64BD0 = 0
            for for_node_index_64BD0, for_node_64BD0 in enumerate(selection_sets["selection_01"]):
                run_function_on_8FEC2 = sn_cast_blend_data(for_node_64BD0).select_set(state=True, view_layer=None, )
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of RestoreSelected1")
        return self.execute(context)


class SNA_OT_Saveselected1(bpy.types.Operator):
    bl_idname = "sna.saveselected1"
    bl_label = "SaveSelected1"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in execute function of SaveSelected1")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            selection_sets["selection_01"] = sn_cast_list(bpy.context.selected_objects)
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of SaveSelected1")
        return self.execute(context)


class SNA_OT_Restoreselected5(bpy.types.Operator):
    bl_idname = "sna.restoreselected5"
    bl_label = "RestoreSelected5"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in execute function of RestoreSelected5")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            for_node_6D189 = 0
            for_node_index_6D189 = 0
            for for_node_index_6D189, for_node_6D189 in enumerate(selection_sets["selection_05"]):
                run_function_on_F21F0 = sn_cast_blend_data(for_node_6D189).select_set(state=True, view_layer=None, )
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of RestoreSelected5")
        return self.execute(context)


class SNA_OT_Saveselected5(bpy.types.Operator):
    bl_idname = "sna.saveselected5"
    bl_label = "SaveSelected5"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in execute function of SaveSelected5")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            selection_sets["selection_05"] = sn_cast_list(bpy.context.selected_objects)
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of SaveSelected5")
        return self.execute(context)


class SNA_OT_Saveselected6(bpy.types.Operator):
    bl_idname = "sna.saveselected6"
    bl_label = "SaveSelected6"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in execute function of SaveSelected6")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            selection_sets["selection_06"] = sn_cast_list(bpy.context.selected_objects)
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of SaveSelected6")
        return self.execute(context)


class SNA_OT_Restoreselected6(bpy.types.Operator):
    bl_idname = "sna.restoreselected6"
    bl_label = "RestoreSelected6"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in execute function of RestoreSelected6")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            for_node_C87A2 = 0
            for_node_index_C87A2 = 0
            for for_node_index_C87A2, for_node_C87A2 in enumerate(selection_sets["selection_06"]):
                run_function_on_4739D = sn_cast_blend_data(for_node_C87A2).select_set(state=True, view_layer=None, )
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of RestoreSelected6")
        return self.execute(context)


class SNA_OT_Restoreselected4(bpy.types.Operator):
    bl_idname = "sna.restoreselected4"
    bl_label = "RestoreSelected4"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in execute function of RestoreSelected4")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            for_node_4C532 = 0
            for_node_index_4C532 = 0
            for for_node_index_4C532, for_node_4C532 in enumerate(selection_sets["selection_04"]):
                run_function_on_68B73 = sn_cast_blend_data(for_node_4C532).select_set(state=True, view_layer=None, )
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of RestoreSelected4")
        return self.execute(context)


class SNA_OT_Saveselected4(bpy.types.Operator):
    bl_idname = "sna.saveselected4"
    bl_label = "SaveSelected4"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in execute function of SaveSelected4")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            selection_sets["selection_04"] = sn_cast_list(bpy.context.selected_objects)
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of SaveSelected4")
        return self.execute(context)


###############   REGISTER ICONS
def sn_register_icons():
    icons = []
    bpy.types.Scene.selection_sets_icons = bpy.utils.previews.new()
    icons_dir = os.path.join( os.path.dirname( __file__ ), "icons" )
    for icon in icons:
        bpy.types.Scene.selection_sets_icons.load( icon, os.path.join( icons_dir, icon + ".png" ), 'IMAGE' )

def sn_unregister_icons():
    bpy.utils.previews.remove( bpy.types.Scene.selection_sets_icons )


###############   REGISTER PROPERTIES
def sn_register_properties():
    bpy.types.Scene.i_count = bpy.props.IntProperty(name='I_Count',description='',subtype='NONE',options=set(),default=0,min=1,max=6)
    bpy.types.Scene.s_1 = bpy.props.StringProperty(name='S_1',description='',subtype='NONE',options=set(),default='')
    bpy.types.Scene.s_2 = bpy.props.StringProperty(name='S_2',description='',subtype='NONE',options=set(),default='')
    bpy.types.Scene.s_3 = bpy.props.StringProperty(name='S_3',description='',subtype='NONE',options=set(),default='')
    bpy.types.Scene.s_4 = bpy.props.StringProperty(name='S_4',description='',subtype='NONE',options=set(),default='')
    bpy.types.Scene.s_5 = bpy.props.StringProperty(name='S_5',description='',subtype='NONE',options=set(),default='')
    bpy.types.Scene.s_6 = bpy.props.StringProperty(name='S_6',description='',subtype='NONE',options=set(),default='')

def sn_unregister_properties():
    del bpy.types.Scene.i_count
    del bpy.types.Scene.s_1
    del bpy.types.Scene.s_2
    del bpy.types.Scene.s_3
    del bpy.types.Scene.s_4
    del bpy.types.Scene.s_5
    del bpy.types.Scene.s_6


###############   REGISTER ADDON
def register():
    sn_register_icons()
    sn_register_properties()
    bpy.utils.register_class(SNA_PT_Selection_Sets_9CF98)
    bpy.utils.register_class(SNA_OT_Restoreselected2)
    bpy.utils.register_class(SNA_OT_Saveselected2)
    bpy.utils.register_class(SNA_OT_Saveselected3)
    bpy.utils.register_class(SNA_OT_Restoreselected3)
    bpy.utils.register_class(SNA_OT_Restoreselected1)
    bpy.utils.register_class(SNA_OT_Saveselected1)
    bpy.utils.register_class(SNA_OT_Restoreselected5)
    bpy.utils.register_class(SNA_OT_Saveselected5)
    bpy.utils.register_class(SNA_OT_Saveselected6)
    bpy.utils.register_class(SNA_OT_Restoreselected6)
    bpy.utils.register_class(SNA_OT_Restoreselected4)
    bpy.utils.register_class(SNA_OT_Saveselected4)


###############   UNREGISTER ADDON
def unregister():
    sn_unregister_icons()
    sn_unregister_properties()
    bpy.utils.unregister_class(SNA_OT_Saveselected4)
    bpy.utils.unregister_class(SNA_OT_Restoreselected4)
    bpy.utils.unregister_class(SNA_OT_Restoreselected6)
    bpy.utils.unregister_class(SNA_OT_Saveselected6)
    bpy.utils.unregister_class(SNA_OT_Saveselected5)
    bpy.utils.unregister_class(SNA_OT_Restoreselected5)
    bpy.utils.unregister_class(SNA_OT_Saveselected1)
    bpy.utils.unregister_class(SNA_OT_Restoreselected1)
    bpy.utils.unregister_class(SNA_OT_Restoreselected3)
    bpy.utils.unregister_class(SNA_OT_Saveselected3)
    bpy.utils.unregister_class(SNA_OT_Saveselected2)
    bpy.utils.unregister_class(SNA_OT_Restoreselected2)
    bpy.utils.unregister_class(SNA_PT_Selection_Sets_9CF98)